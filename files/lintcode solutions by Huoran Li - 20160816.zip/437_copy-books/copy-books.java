/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/copy-books
@Language: Java
@Datetime: 15-09-17 05:45
*/

public class Solution
{
    /**
     * @param pages: an array of integers
     * @param k: an integer
     * @return: an integer
     */

    public int copyBooks( int[] pages , int k )
    {
        // write your code here
    	int n = pages.length;
    	int[] a = new int[n + 1];
    	int[] s = new int[n + 1];
    	s[0] = 0;
    	for( int i = 1 ; i <= n ; i ++ )
    	{
    		a[i] = pages[i - 1];
    		s[i] = a[i] + s[i - 1];
    	}
        
        int[][] f = new int[n + 1][k + 1];
        for( int i = 0 ; i <= n ; i ++ )
        for( int j = 1 ; j <= k ; j ++ )
        {
            if( i == 0 ) f[i][j] = 0;
            else if( i == 1 ) f[i][j] = a[i];
            else if( j == 1 ) f[i][j] = f[i - 1][j] + a[i];
            else
            {
                f[i][j] = 2147483647;
                for( int p = 1 ; p < i ; p ++ )
                {
                    f[i][j] = min( f[i][j] , max( f[p][j - 1] , s[i] - s[p] ) );
                }
            }
            
            // System.out.println( i + " " + j + " " + f[i][j] );
        }
        
        return f[n][k];
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
}
