/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/wiggle-sort
@Language: Java
@Datetime: 16-03-04 05:59
*/

public class Solution {
	public void wiggleSort(int[] nums) {
		// Write your code here
		int[] a = nums;
		int n = a.length;
		if (n <= 1) {
			return;
		}

		// System.out.println(getVal(a, 0, n - 1, (n + 1) / 2));

		int val = getVal(a, 0, n - 1, (n + 1) / 2);
		reorder(a, val);
		int t = (n + 1) / 2;
		
		for (int i = 0; i < n; i += 1) {
			if (i % 2 == 0) {
				continue;
			}
			swap(a, i, t);
			t += 1;
		}
	}
	
	private void reorder(int[] a, int val) {
		int t = 0;
		for (int i = 0; i < a.length; i += 1) {
			if (a[i] < val) {
				swap(a, i, t);
				t += 1;
			}
		}
	}

	private int getVal(int[] a, int l, int r, int rank) {
		if (l == r) {
			return a[l];
		}

		int t = l;
		for (int i = l + 1; i <= r; i += 1) {
			if (a[i] < a[l]) {
				t += 1;
				swap(a, t, i);
			}
		}
		swap(a, t, l);

		if (t == rank) {
			return a[t];
		} else if (t < rank) {
			return getVal(a, t + 1, r, rank);
		} else {
			return getVal(a, l, t - 1, rank);
		}
	}

	private void swap(int[] a, int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}
}