# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-words-in-a-string
@Language: Python
@Datetime: 15-09-05 16:29
'''

class Solution:
    # @param s : A string
    # @return : A string
    def reverseWords( self , s ):
        # write your code here
        s = s.strip()
        if len( s ) == 0:
            return ''
        
        a = s.split( ' ' )
        n = len( a )
        r = ''
        for i in range( n ):
            j = n - i - 1
            r += '%s ' % a[j]
        return r[:-1]
