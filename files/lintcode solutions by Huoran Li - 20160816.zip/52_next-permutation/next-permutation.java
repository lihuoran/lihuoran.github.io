/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/next-permutation
@Language: Java
@Datetime: 16-02-07 16:03
*/

public class Solution {
    /**
     * @param nums: an array of integers
     * @return: return nothing (void), do not return anything, modify nums in-place instead
     */
    public int[] nextPermutation(int[] nums) {
        // write your code here
        next(nums);
        return nums;
    }
    
    private void next(int[] a) {
		int idx = -1;
		int n = a.length;
		for (int i = n - 1; i >= 1; i -= 1) {
			if (a[i] > a[i - 1]) {
				idx = i - 1;
				break;
			}
		}
		
		if (idx == -1) {
			Qsort.sort(a, 0, n - 1);
		} else {
			int cur = -1;
			for (int i = idx + 1; i < n; i += 1) {
				if (a[i] > a[idx] && (cur == -1 || a[cur] > a[i])) {
					cur = i;
				}
			}
			Qsort.swap(a, cur, idx);
			Qsort.sort(a, idx + 1, n - 1);
		}
	}
}

class Qsort {
	public static void sort(int[] a, int l, int r) {
		if (l >= r) {
			return;
		}
		
		int x = partition(a, l, r);
		sort(a, l, x - 1);
		sort(a, x + 1, r);
	}
	
	public static int partition(int[] a, int l, int r) {
		int t = l;
		for (int i = l + 1; i <= r; i += 1) {
			if (a[i] < a[l]) {
				t += 1;
				swap(a, i, t);
			}
		}
		swap(a, l, t);
		return t;
	}
	
	public static void swap(int[] a, int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}
}