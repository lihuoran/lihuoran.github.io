# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/previous-permutation
@Language: Python
@Datetime: 15-09-28 07:18
'''

class Solution:
    # @param num :  a list of integer
    # @return : a list of integer
    def previousPermuation(self, num):
        # write your code here
        a = num
        n = len( a )
        t = n - 1
        while t != 0 and a[t] >= a[t - 1]:
            t -= 1
        t -= 1
        
        if t == -1:
            a.sort()
            a.reverse()
            return a
        else:
            idx = t + 1
            for i in range( t + 2 , n ):
                if a[i] >= a[t]:
                    continue
                if a[i] > a[idx]:
                    idx = i
            temp = a[t]
            a[t] = a[idx]
            a[idx] = temp
            b = a[t + 1:]
            b.sort()
            b.reverse()
            a[t + 1:] = b
            return a