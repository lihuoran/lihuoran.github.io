/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reorder-list
@Language: Java
@Datetime: 15-08-08 07:06
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The head of linked list.
     * @return: void
     */
    public void reorderList( ListNode head )
    {  
        // write your code here
    	if( head == null ) return ;
    	int n = len( head );
    	if( n == 1 ) return ;
    	
    	ListNode ret = head , tail = ret;
    	ListNode p = head.next;
    	head.next = null;
    	
    	for( int i = 1 ; i < n ; i ++ )
    	{
    		if( i % 2 == 0 )
    		{
    			tail.next = p;
    			p = p.next;
    			tail = tail.next;
    			tail.next = null;
    		}
    		else
    		{
    			if( p.next == null )
    			{
    				tail.next = p;
    				p = p.next;
    				tail = tail.next;
    				tail.next = null;
    			}
    			else
    			{
    				ListNode q = p;
    				while( q.next.next != null ) q = q.next;
    				tail.next = q.next;
    				q.next = null;
    				tail = tail.next;
    				tail.next = null;
    			}
    		}
    	}
    	
    	head = ret;
    }
    
    private int len( ListNode head )
    {
    	if( head == null ) return 0;
    	int cnt = 1;
    	while( head.next != null )
    	{
    		cnt ++;
    		head = head.next;
    	}
    	return cnt;
    }
}