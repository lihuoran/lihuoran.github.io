/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/minimum-subarray
@Language: Java
@Datetime: 15-11-15 01:11
*/

public class Solution {
    /**
     * @param nums: a list of integers
     * @return: A integer indicate the sum of minimum subarray
     */
    public int minSubArray(ArrayList<Integer> nums) {
        // write your code
        int n = nums.size();
        int[] sum = new int[n];
        
        sum[0] = nums.get(0);
        for (int i = 1; i < n; i += 1) {
            sum[i] = sum[i - 1] + nums.get(i);
        }
        
        int ans = 2147483647;
        for (int i = 0; i < n; i += 1) {
            for (int j = i; j < n; j += 1) {
                int cur;
                if (i == 0) {
                    cur = sum[j];
                } else {
                    cur = sum[j] - sum[i - 1];
                }
                
                if (cur < ans) {
                    ans = cur;
                }
            }
        }
        
        return ans;
    }
}

