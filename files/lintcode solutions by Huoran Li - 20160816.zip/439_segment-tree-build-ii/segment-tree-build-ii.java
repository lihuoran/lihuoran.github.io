/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/segment-tree-build-ii
@Language: Java
@Datetime: 15-09-06 07:53
*/

/**
 * Definition of SegmentTreeNode:
 * public class SegmentTreeNode {
 *     public int start, end, max;
 *     public SegmentTreeNode left, right;
 *     public SegmentTreeNode(int start, int end, int max) {
 *         this.start = start;
 *         this.end = end;
 *         this.max = max
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     *@param A: a list of integer
     *@return: The root of Segment Tree
     */
    private int[] a;
    private int n;
    
    public SegmentTreeNode build( int[] A )
    {
        // write your code here
        a = A;
        n = a.length;
        if( n == 0 ) return null;
        
        return make( 0 , n - 1 );
    }
    
    private SegmentTreeNode make( int l , int r )
    {
        if( l > r ) return null;
        
        if( l == r )
        {
            SegmentTreeNode node = new SegmentTreeNode( l , r , a[l] );
            return node;
        }
        
        int m = ( l + r ) / 2;
        SegmentTreeNode lson = make( l , m );
        SegmentTreeNode rson = make( m + 1 , r );
        int val = max( lson.max , rson.max );
        SegmentTreeNode node = new SegmentTreeNode( l , r , val );
        node.left = lson;
        node.right = rson;
        return node;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
