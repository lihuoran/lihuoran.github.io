/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/anagrams
@Language: Java
@Datetime: 15-05-09 13:40
*/

public class Solution
{
    /**
     * @param strs: A list of strings
     * @return: A list of strings
     */
    private int n;
    private MyString[] a;

    public List<String> anagrams( String[] strs )
    {
        // write your code here
        n = strs.length;
        a = new MyString[n];
        for( int i = 0 ; i < n ; i ++ )
            a[i] = new MyString( strs[i] );

        LinkedList<String> ret = new LinkedList<String>();
        for( int i = 0 ; i < n ; i ++ )
        for( int j = 0 ; j < n ; j ++ )
            if( i != j && a[i].sort.equals( a[j].sort ) )
            {
                ret.add( a[i].ori );
                break;
            }

        return ret;
    }

    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
}

class MyString
{
    public String ori;
    public String sort;
    public int len;

    public MyString( String s )
    {
        ori = new String( s );
        len = ori.length();

        char[] temp = new char[len];
        for( int i = 0 ; i < len ; i ++ )
            temp[i] = ori.charAt( i );
        for( int i = 0 ; i < len ; i ++ )
        for( int j = i + 1 ; j < len ; j ++ )
            if( temp[i] > temp[j] )
            {
                char c = temp[i] ; temp[i] = temp[j] ; temp[j] = c;
            }
        sort = new String();
        for( int i = 0 ; i < len ; i ++ )
            sort += temp[i];
    }

    public MyString( MyString s )
    {
        ori = new String( s.ori );
        sort = new String( s.sort );
        len = s.len;
    }

    public char charAt( int idx )
    {
        return sort.charAt( idx );
    }
}
