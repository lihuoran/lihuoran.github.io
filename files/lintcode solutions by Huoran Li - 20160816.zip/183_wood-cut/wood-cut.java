/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/wood-cut
@Language: Java
@Datetime: 15-05-21 11:49
*/

public class Solution
{
    /** 
     *@param L: Given n pieces of wood with length L[i]
     *@param k: An integer
     *return: The maximum length of the small pieces.
     */
    private int[] a;
    private int k;
    private int n;
    
    public int woodCut( int[] L , int k )
    {
        // write your code here
        a = L;
        this.k = k;
        n = a.length;
        
        if( !valid( 1 ) ) return 0;
        
        int m = a[0];
        for( int i = 1 ; i < n ; i ++ )
            m = ( m > a[i] ? m : a[i] );
        
        long l = 2 , r = m;
        while( l <= r )
        {
            long mid = ( l + r ) / 2;
            if( valid( mid ) ) l = mid + 1;
            else r = mid - 1;
        }
        return ( int )( l - 1 );
    }
    
    private boolean valid( long x )
    {
        long cnt = 0;
        for( int i = 0 ; i < n ; i ++ )
        {
            cnt += a[i] / x;
            if( cnt >= k ) return true;
        }
        return false;
    }
}
