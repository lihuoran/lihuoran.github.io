/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/decode-ways
@Language: Java
@Datetime: 16-03-15 04:10
*/

public class Solution {
    /**
     * @param s a string,  encoded message
     * @return an integer, the number of ways decoding
     */
    public int numDecodings(String s) {
        // Write your code here
        if (s == null || s.length() == 0) {
            return 0;
        }
        if (s.equals("0")) {
            return 0;
        }
        
        int n = s.length();
        s = '@' + s;
        int[] f = new int[n + 1];
        f[0] = f[1] = 1;
        for (int i = 2; i <= n; i += 1) {
            if (s.charAt(i) != '0') {
                f[i] = f[i - 1];
            } else {
                f[i] = 0;
            }
            int val = Integer.parseInt(s.substring(i - 1, i + 1));
            if (val >= 10 && val <= 26) {
                f[i] += f[i - 2];
            }
        }
        
        return f[n];
    }
}