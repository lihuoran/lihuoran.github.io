# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-product-subarray
@Language: Python
@Datetime: 15-09-02 17:50
'''

class Solution:
    # @param nums: an integer[]
    # @return: an integer
    def maxProduct( self , nums ):
        # write your code here
        a = nums
        n = len( a )
        
        if n == 0:
            return -1
        if n == 1:
            return a[0]
        
        zidx = -1
        for i in range( n ):
            if nums[i] == 0:
                zidx = i
                break
        
        if zidx == -1:
            fpos = []
            fneg = []
            
            if a[0] > 0:
                fpos.append( a[0] )
                fneg.append( -1 )
            else:
                fpos.append( -1 )
                fneg.append( a[0] * -1 )
            
            for i in range( 1 , n ):
                if a[i] > 0:
                    if fpos[i - 1] != -1:
                        cpos = fpos[i - 1] * a[i]
                    else:
                        cpos = a[i]
                    if fneg[i - 1] != -1:
                        cneg = fneg[i - 1] * a[i]
                    else:
                        cneg = -1
                    fpos.append( cpos )
                    fneg.append( cneg )
                else:
                    if fpos[i - 1] != -1:
                        cneg = fpos[i - 1] * a[i] * -1
                    else:
                        cneg = a[i] * -1
                    if fneg[i - 1] != -1:
                        cpos = fneg[i - 1] * a[i] * -1
                    else:
                        cpos = -1
                    fpos.append( cpos )
                    fneg.append( cneg )

            ans = 0
            for i in range( n ):
                ans = max( ans , fpos[i] )
            return ans
                        
        else:
            ans = 0
            ans = max( ans , self.maxProduct( nums[:zidx] ) )
            ans = max( ans , self.maxProduct( nums[zidx + 1:] ) )
            return ans