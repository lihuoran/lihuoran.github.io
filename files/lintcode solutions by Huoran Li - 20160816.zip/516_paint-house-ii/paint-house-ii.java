/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/paint-house-ii
@Language: Java
@Datetime: 16-03-27 08:55
*/

public class Solution {
	public int minCostII(int[][] costs) {
		// Write your code here
		try {
			int n = costs.length;
			int k = costs[0].length;
			int[][] f = new int[n][k];
			
			for (int i = 0; i < n; i += 1) {
				for (int j = 0; j < k; j += 1) {
					if (i == 0) {
						f[i][j] = costs[i][j];
					} else {
						f[i][j] = Integer.MAX_VALUE;
						for (int t = 0; t < k; t += 1) {
							if (t != j) {
								f[i][j] = Math.min(f[i][j], f[i - 1][t]);
							}
						}
						f[i][j] += costs[i][j];
					}
					// System.out.println(i + " " + j + " " + f[i][j]);
				}
			}
			
			int ans = Integer.MAX_VALUE;
			for (int i = 0; i < k; i += 1) {
				ans = Math.min(ans, f[n - 1][i]);
			}
			return ans;
		} catch (Exception e) {
			return 0;
		}
	}
}