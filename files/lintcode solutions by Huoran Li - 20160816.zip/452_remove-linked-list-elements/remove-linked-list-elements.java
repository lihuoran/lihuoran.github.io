/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/remove-linked-list-elements
@Language: Java
@Datetime: 15-10-20 06:34
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @param val an integer
     * @return a ListNode
     */
    public ListNode removeElements(ListNode head, int val) {
        // Write your code here
        ListNode cur = new ListNode( 0 );
        ListNode p = cur;
        ListNode q = head;
        while( q != null )
        {
            ListNode t = q;
            q = q.next;
            t.next = null;
            if( t.val != val )
            {
                p.next = t;
                p = t;
            }
        }
        return cur.next;
    }
}
