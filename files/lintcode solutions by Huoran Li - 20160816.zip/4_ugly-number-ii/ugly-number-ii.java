/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/ugly-number-ii
@Language: Java
@Datetime: 16-02-06 12:13
*/

class Solution {
    /**
     * @param k: The number k.
     * @return: The kth prime number as description.
     */
    public long kthPrimeNumber(int k) {
		// write your code here
		ArrayList<Long> a = new ArrayList<Long>();
		a.add((long) (3));
		a.add((long) (5));
		a.add((long) (7));
		int t3, t5, t7;
		long m = 7;
		t3 = t5 = t7 = 0;
		for (int i = 3; i < k; i++) {
			while (a.get(t3) * 3 <= m) {
				t3 += 1;
			}
			while (a.get(t5) * 5 <= m) {
				t5 += 1;
			}
			while (a.get(t7) * 7 <= m) {
				t7 += 1;
			}
			long a3 = a.get(t3) * 3;
			long a5 = a.get(t5) * 5;
			long a7 = a.get(t7) * 7;
			m = min(a3, a5, a7);
			a.add(m);
		}

		return a.get(k - 1);
	}

	private long min(long a, long b, long c) {
		return min(a, min(b, c));
	}
	
	private long min(long a, long b) {
	    return (a < b ? a : b);
	}
};
