/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/distinct-subsequences
@Language: Java
@Datetime: 15-09-02 17:31
*/

public class Solution {
    /**
     * @param S, T: Two string.
     * @return: Count the number of distinct subsequences
     */
    public int numDistinct(String S, String T) {
        // write your code here
        String s = "^" + S;
        String t = "^" + T;
        int n = s.length();
        int m = t.length();
        
        int[][] f = new int[n][m];
        for( int i = 0 ; i < n ; i ++ )
        for( int j = 0 ; j < m ; j ++ )
        {
            if( i == 0 && j == 0 ) f[i][j] = 1;
            else if( j == 0 ) f[i][j] = 1;
            else if( i == 0 || j > i ) f[i][j] = 0;
            else
            {
                f[i][j] = f[i - 1][j];
                if( s.charAt( i ) == t.charAt( j ) )
                    f[i][j] += f[i - 1][j - 1];
            }
            
        //    System.out.println( s.substring( 0 , i + 1 ) + " " + t.substring( 0 , j + 1 ) + " " + f[i][j] );
        }
        
        return f[n - 1][m - 1];
    }
}