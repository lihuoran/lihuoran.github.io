/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/swap-two-nodes-in-linked-list
@Language: Java
@Datetime: 16-03-15 06:00
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @oaram v1 an integer
     * @param v2 an integer
     * @return a new head of singly-linked list
     */
    public ListNode swapNodes(ListNode head, int v1, int v2) {
        // Write your code here
        ListNode p = null;
        ListNode q = null;
        ListNode fake = new ListNode(0);
        fake.next = head;
        
        ListNode t = fake;
        while (t.next != null) {
            if (t.next.val == v1 || t.next.val == v2) {
                if (p == null) {
                    p = t;
                } else {
                    q = t;
                }
            }
            t = t.next;
        }
        
        if (p != null && q != null) {
            if (p.next == q) {
                ListNode x = q.next;
                ListNode y = x.next;
                q.next = y;
                x.next = q;
                p.next = x;
            } else {
                ListNode x = p.next.next;
                ListNode y = q.next.next;
                ListNode r = p.next;
                ListNode s = q.next;
                r.next = y;
                q.next = r;
                s.next = x;
                p.next = s;
            }
        }
        
        return fake.next;
    }
}