/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock
@Language: Java
@Datetime: 15-05-10 16:48
*/

public class Solution
{
    /**
     * @param prices: Given an integer array
     * @return: Maximum profit
     */
    public int maxProfit( int[] prices )
    {
        // write your code here
        int[] p = prices;
        int n = p.length;
        if( n == 0 ) return 0;
        
        int ans = 0;
        int[] low = new int[n];
        
        low[0] = p[0];
        
        for( int i = 1 ; i < n ; i ++ )
        {
            ans = max( ans , p[i] - low[i - 1] );
            low[i] = min( low[i - 1] , p[i] );
        }
        
        return ans;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
}
