/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/merge-sorted-array
@Language: Java
@Datetime: 15-05-07 11:30
*/

class Solution
{
    /**
     * @param A: sorted integer array A which has m elements, 
     *           but size of A is m+n
     * @param B: sorted integer array B which has n elements
     * @return: void
     */
    public void mergeSortedArray( int[] A , int m , int[] B , int n )
    {
        // write your code here
        int[] a = A;
        int[] b = B;
        
        int t = m + n;
        for( int i = t - 1 ; i >= 0 ; i -- )
        {
            if( m <= 0 || ( m > 0 && n > 0 && a[m - 1] < b[n - 1] ) )
            {
                a[i] = b[-- n];
            }
            else
            {
                a[i] = a[-- m];
            }
        }
    }
}
