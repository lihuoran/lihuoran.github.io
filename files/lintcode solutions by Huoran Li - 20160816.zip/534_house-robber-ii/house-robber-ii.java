/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/house-robber-ii
@Language: Java
@Datetime: 16-04-28 08:09
*/

public class Solution {
    /**
     * @param nums: An array of non-negative integers.
     * return: The maximum amount of money you can rob tonight
     */
    public int houseRobber2(int[] nums) {
        // write your code here
        if (nums == null || nums.length == 0) {
            return 0;
        }
        
        int n = nums.length;
        if (n == 1) {
            return nums[0];
        }
        if (n == 2) {
            return Math.max(nums[0], nums[1]);
        }
        
        int ra = calc(nums, 1, n - 1);
        int rb = calc(nums, 2, n - 2) + nums[0];
        return Math.max(ra, rb);
    }
    
    private int calc(int[] a, int l, int r) {
        if (l > r) {
            return 0;
        }
        int x = a[l];
        int y = 0;
        
        for (int i = l + 1; i <= r; i += 1) {
            int p, q;
            p = y + a[i];
            q = Math.max(x, y);
            x = p;
            y = q;
        }
        return Math.max(x, y);
    }
}