# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/intersection-of-two-arrays-ii
@Language: Python
@Datetime: 16-06-20 15:08
'''

class Solution:
    # @param {int[]} nums1 an integer array
    # @param {int[]} nums2 an integer array
    # @return {int[]} an integer array
    def intersection(self, nums1, nums2):
        # Write your code here
        ret = []
        m = {}
        for e in nums1:
            m[e] = m.get(e, 0) + 1
        
        for e in nums2:
            if m.get(e, 0) != 0:
                m[e] -= 1
                ret.append(e)
        
        return ret