/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-increasing-continuous-subsequence
@Language: Java
@Datetime: 15-07-09 02:41
*/

public class Solution
{
    /**
     * @param A an array of Integer
     * @return  an integer
     */
    public int longestIncreasingContinuousSubsequence( int[] A )
    {
        // Write your code here
        int[] a = A;
        int n = a.length;
        if( n == 0 ) return 0;
        if( n == 1 ) return 1;
        
        int ret = 1;
        int[] f = new int[n];
        //
        for( int i = 0 ; i < n ; i ++ )
            f[i] = 1;
        for( int i = 1 ; i < n ; i ++ )
        {
            if( a[i] > a[i - 1] ) f[i] = f[i - 1] + 1;
            ret = max( ret , f[i] );
        }
        //
        for( int i = 0 ; i < n ; i ++ )
            f[i] = 1;
        for( int i = n - 2 ; i >= 0 ; i -- )
        {
            if( a[i] > a[i + 1] ) f[i] = f[i + 1] + 1;
            ret = max( ret , f[i] );
        }
        
        return ret;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
