/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-tree-serialization
@Language: Java
@Datetime: 15-07-11 08:26
*/

class Solution
{
    /**
     * This method will be invoked first, you should design your own algorithm 
     * to serialize a binary tree which denote by a root node to a string which
     * can be easily deserialized by your own "deserialize" method later.
     */
    public String serialize( TreeNode root )
    {
        // write your code here
        if( root == null ) return "";
        
        LinkedList<TreeNode> q = new LinkedList<TreeNode>();
        String ret = "";
        q.add( root );
        while( q.size() != 0 )
        {
            TreeNode t = q.poll();
            if( t == null )
            {
                if( ret.length() == 0 ) ret += "#";
                else ret += ",#";
            }
            else
            {
                if( ret.length() == 0 ) ret += t.val;
                else ret += "," + t.val;
                
                q.add( t.left );
                q.add( t.right );
            }
        }
        return ret;
    }
    
    /**
     * This method will be invoked second, the argument data is what exactly
     * you serialized at method "serialize", that means the data is not given by
     * system, it's given by your own serialize method. So the format of data is
     * designed by yourself, and deserialize it here as you serialize it in 
     * "serialize" method.
     */
    public TreeNode deserialize( String data )
    {
        // write your code here
        if( data == "" ) return null;
        
        LinkedList<TreeNode> q = new LinkedList<TreeNode>();
        String[] a = data.split( "," );
        TreeNode ret = new TreeNode( Integer.parseInt( a[0] ) );
        int t = 1;
        
        q.add( ret );
        while( q.size() != 0 )
        {
            TreeNode node = q.poll();
            if( a[t].equals( "#" ) ) node.left = null;
            else
            {
                node.left = new TreeNode( Integer.parseInt( a[t] ) );
                q.add( node.left );
            }
            t ++;
            
            if( a[t].equals( "#" ) ) node.right = null;
            else
            {
                node.right = new TreeNode( Integer.parseInt( a[t] ) );
                q.add( node.right );
            }
            t ++;
        }
        
        return ret;
    }
}