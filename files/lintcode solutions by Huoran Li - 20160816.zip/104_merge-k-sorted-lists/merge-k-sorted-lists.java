/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/merge-k-sorted-lists
@Language: Java
@Datetime: 15-09-03 05:31
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param lists: a list of ListNode
     * @return: The head of one sorted list.
     */
    public ListNode mergeKLists( List<ListNode> lists )
    {  
        // write your code here
        ArrayList<ListNode> l = ( ArrayList<ListNode> ) lists;
        int n = l.size();
        ListNode[] a = new ListNode[n];
        for( int i = 0 ; i < n ; i ++ )
            a[i] = l.get( i );
        
        ListNode head = new ListNode( 0 );
        ListNode tail = head;
        while( true )
        {
            int idx = -1;
            ListNode cur = null;
            for( int i = 0 ; i < n ; i ++ )
            {
                if( a[i] == null ) continue;
                if( idx == -1 || a[idx].val > a[i].val )
                    idx = i;
            }
            if( idx == -1 )
                break;
                
            tail.next = a[idx];
            a[idx] = a[idx].next;
            tail = tail.next;
            tail.next = null;
        }
        
        return head.next;
    }
}

