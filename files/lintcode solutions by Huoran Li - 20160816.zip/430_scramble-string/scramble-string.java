/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/scramble-string
@Language: Java
@Datetime: 15-06-22 08:20
*/

public class Solution
{
    /**
     * @param s1 A string
     * @param s2 Another string
     * @return whether s2 is a scrambled string of s1
     */
    public boolean isScramble( String s1 , String s2 )
    {
        // Write your code here
        int m = s1.length();
        int n = s2.length();
        
        if( m != n ) return false;
        if( m == 0 ) return true;
        if( m == 1 ) return ( s1.charAt( 0 ) == s2.charAt( 0 ) );
        if( !contentCheck( s1 , s2 ) ) return false;
        
        for( int i = 1 ; i < m ; i ++ )
        {
            String l1 = s1.substring( 0 , i );
            String r1 = s1.substring( i , m );
            String a , b;
            
            // 1
            a = s2.substring( 0 , i );
            b = s2.substring( i , m );
            if( isScramble( l1 , a ) && isScramble( r1 , b ) ) return true;
            // 2
            b = s2.substring( 0 , m - i );
            a = s2.substring( m - i , m );
            if( isScramble( l1 , a ) && isScramble( r1 , b ) ) return true;
        }
        return false;
    }
    
    private boolean contentCheck( String s1 , String s2 )
    {
        int[] cnt = new int[256];
        int l = s1.length();
        for( int i = 0 ; i < 256 ; i ++ )
            cnt[i] = 0;
        for( int i = 0 ; i < l ; i ++ )
            cnt[( int )( s1.charAt( i ) )] ++;
        for( int i = 0 ; i < l ; i ++ )
            cnt[( int )( s2.charAt( i ) )] --;
        for( int i = 0 ; i < 256 ; i ++ )
            if( cnt[i] != 0 ) return false;
        return true;
    }
}
