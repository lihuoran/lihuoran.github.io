/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/two-strings-are-anagrams
@Language: Java
@Datetime: 15-05-05 07:15
*/

public class Solution
{
    /**
     * @param s: The first string
     * @param b: The second string
     * @return true or false
     */
    public boolean anagram( String s , String t )
    {
        // write your code here
        if( s.length() != t.length() ) return false;
        int n = s.length();
        
        char[] a = new char[n];
        char[] b = new char[n];
        for( int i = 0 ; i < n ; i ++ )
        {
            a[i] = s.charAt( i );
            b[i] = t.charAt( i );
        }
        
        for( int i = 0 ; i < n ; i ++ )
        for( int j = i + 1 ; j < n ; j ++ )
            if( a[i] > a[j] )
            {
                char temp = a[i] ; a[i] = a[j] ; a[j] = temp ;
            }
        for( int i = 0 ; i < n ; i ++ )
        for( int j = i + 1 ; j < n ; j ++ )
            if( b[i] > b[j] )
            {
                char temp = b[i] ; b[i] = b[j] ; b[j] = temp ;
            }
        for( int i = 0 ; i < n ; i ++ )
            if( a[i] != b[i] ) return false;
        return true;
    }
};
