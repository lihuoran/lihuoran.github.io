/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/backpack-vi
@Language: Java
@Datetime: 16-08-07 11:28
*/

public class Solution {
    /**
     * @param nums an integer array and all positive numbers, no duplicates
     * @param target an integer
     * @return an integer
     */
    private int[] a;
    private int n;
    private HashMap<Integer, Integer> map;
    
    public int backPackVI(int[] nums, int target) {
        // Write your code here
        a = nums;
        n = a.length;
        qsort(a, 0, n - 1);
        map = new HashMap<Integer, Integer>();
        map.put(0, 1);
        
        return calc(target);
    }
    
    private int calc(int target) {
        if (!map.containsKey(target)) {
            int ret = 0;
            for (int i = 0; i < n; i += 1) {
                if (a[i] > target) {
                    break;
                }
                ret += calc(target - a[i]);
            }
            map.put(target, ret);
        }

        return map.get(target);
    }
    
    private void qsort(int[] a, int l, int r) {
        if (l >= r) {
            return;
        }
        
        int x = partition(a, l, r);
        qsort(a, l, x - 1);
        qsort(a, x + 1, r);
    }
    
    private int partition(int[] a, int l, int r) {
        int t = l;
        for (int i = l + 1; i <= r; i += 1) {
            if (a[i] < a[l]) {
                t += 1;
                int temp = a[t];
                a[t] = a[i];
                a[i] = temp;
            }
        }
        int temp = a[t];
        a[t] = a[l];
        a[l] = temp;
        
        return t;
    }
}