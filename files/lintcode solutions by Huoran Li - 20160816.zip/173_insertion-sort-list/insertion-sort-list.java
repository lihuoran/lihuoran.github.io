/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/insertion-sort-list
@Language: Java
@Datetime: 15-09-26 16:51
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The first node of linked list.
     * @return: The head of linked list.
     */
    public ListNode insertionSortList( ListNode head )
    {
        // write your code here
        ListNode ret = new ListNode( 0 );
        ListNode t = head;
        while( t != null )
        {
            ListNode cur = ret;
            while( cur.next != null && cur.next.val < t.val )
                cur = cur.next;
            ListNode temp = t.next;
            
            t.next = cur.next;
            cur.next = t;
            
            t = temp;
        }
        return ret.next;
    }
}
