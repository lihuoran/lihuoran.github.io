/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/continuous-subarray-sum
@Language: Java
@Datetime: 15-09-08 11:40
*/

public class Solution {
    /**
     * @param A an integer array
     * @return  A list of integers includes the index of the first number and the index of the last number
     */
    public ArrayList<Integer> continuousSubarraySum( int[] A )
    {
        // Write your code here
        int[] a = A;
        int n = a.length;
        
        int cur = 0;
        int ans = 0;
        int l = -1 , r = -1;
        int bl = -1 , br = -1;
        
        ans = cur = a[0];
        bl = br = 0;
        l = r = 0;
        for( int i = 1 ; i < n ; i ++ )
        {
            if( cur < 0 )
            {
                l = i;
                cur = 0;
            }
            cur += a[i];
            if( cur > ans )
            {
                ans = cur;
                br = i;
                bl = l;
            }
        }
        
        ArrayList<Integer> ret = new ArrayList<Integer>();
        ret.add( bl );
        ret.add( br );
        
        return ret;
    }
}
