/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/building-outline
@Language: Java
@Datetime: 15-12-16 15:45
*/

import java.util.*;

public class Solution {
	public ArrayList<ArrayList<Integer>> buildingOutline(int[][] buildings) {
        // write your code here
		ArrayList<ArrayList<Integer>> ret = new ArrayList<ArrayList<Integer>>(); 
		
		if (buildings == null || buildings.length == 0) {
			return ret;
		}
		
		int n = buildings.length;
		ArrayList<int[]> plist = new ArrayList<int[]>();
		for (int i = 0; i < n; i += 1) {
			int[] b = buildings[i];
			int s = b[0];
			int e = b[1];
			int h = b[2];
			int[] a1 = {s, h * -1};
			int[] a2 = {e, h};
			plist.add(a1);
			plist.add(a2);
		}
		
		Collections.sort(plist, new Comparator<int[]>() {
			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub
				if (o1[0] != o2[0]) {
					return o1[0] - o2[0];
				}
				return o1[1] - o2[1];
			}
			
		});

		ArrayList<int[]> pointlist = new ArrayList<int[]>();
		PriorityQueue<Integer> q = new PriorityQueue<Integer>();
		q.add(0);
		int prev = 0;
		for (int i = 0; i < plist.size(); i += 1) {
			int[] curpoint = plist.get(i);
			if (curpoint[1] < 0) {
				q.add(curpoint[1]);
			} else {
				q.remove(curpoint[1] * -1);
			}
			
			int cur = q.peek() * -1;
			if (cur != prev) {
				int[] a = {curpoint[0], cur};
				pointlist.add(a);
				prev = cur;
			}
			
		}
		
		for (int i = 0; i < pointlist.size() - 1; i += 1) {
			int[] a = pointlist.get(i);
			int[] b = pointlist.get(i + 1);
			if (a[0] != b[0] && a[1] != 0) {
				ArrayList<Integer> temp = new ArrayList<Integer>();
				temp.add(a[0]);
				temp.add(b[0]);
				temp.add(a[1]);
				ret.add(temp);
			}
		}
		
		return ret;
    }
}