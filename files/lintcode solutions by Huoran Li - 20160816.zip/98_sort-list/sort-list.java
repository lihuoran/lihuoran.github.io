/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sort-list
@Language: Java
@Datetime: 15-08-08 06:37
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The head of linked list.
     * @return: You should return the head of the sorted linked list,
                    using constant space complexity.
     */
    public ListNode sortList( ListNode head )
    {  
        // write your code here
    	if( head == null ) return null;
    	
    	int n = len( head );
    	if( n == 1 ) return head;
    	
    	int cnt = 1;
    	ListNode p = head;
    	while( cnt < n / 2 )
    	{
    		cnt ++;
    		p = p.next;
    	}
    	
    	ListNode q = p.next;
    	p.next = null;
    	
    	ListNode s = sortList( head );
    	ListNode t = sortList( q );
    	ListNode ret = null;
    	ListNode tail = ret;
    	while( s != null || t != null )
    	{
    		ListNode cur = null;
    		if( s == null ) { cur = t ; t = t.next ; }
    		else if( t == null ) { cur = s ; s = s.next ; }
    		else
    		{
    			if( s.val < t.val ) { cur = s ; s = s.next ; }
    			else { cur = t ; t = t.next ; }
    		}
    		cur.next = null;
    		if( ret == null )
    		{
    			ret = cur;
    			tail = ret;
    		}
    		else
    		{
    			tail.next = cur;
    			tail = tail.next;
    		}
    	}
    	
    	return ret;
    }
    
    private int len( ListNode head )
    {
    	if( head == null ) return 0;
    	int cnt = 1;
    	while( head.next != null )
    	{
    		head = head.next;
    		cnt ++;
    	}
    	return cnt;
    }
}
