/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/spiral-matrix-ii
@Language: Java
@Datetime: 15-12-13 15:15
*/

public class Solution {
    /**
     * @param n an integer
     * @return a square matrix
     */
    public int[][] generateMatrix(int n) {
        // Write your code here
        if (n == 0) {
            return null;
        }
        
        int[][] ret = new int[n][n];
        for (int i = 0; i < n; i += 1) {
            for (int j = 0; j < n; j += 1) {
                ret[i][j] = 0;
            }
        }
        int[] movex = new int[4];
        int[] movey = new int[4];
        
        movex[0] = 0; movex[1] = 1; movex[2] = 0; movex[3] = -1; 
        movey[0] = 1; movey[1] = 0; movey[2] = -1; movey[3] = 0; 
        
        int x = 0;
        int y = 0;
        int d = 0;
        for (int i = 1; i < n * n; i += 1) {
            ret[x][y] = i;
            int tx = x + movex[d];
            int ty = y + movey[d];
            while (tx < 0 || tx >= n || ty < 0 || ty >= n || ret[tx][ty] != 0) {
                d = (d + 1) % 4;
                tx = x + movex[d];
                ty = y + movey[d];
            }
            x = tx;
            y = ty;
        }
        ret[x][y] = n * n;
        
        return ret;
    }
}