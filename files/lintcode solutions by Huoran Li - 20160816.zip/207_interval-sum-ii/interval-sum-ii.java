/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/interval-sum-ii
@Language: Java
@Datetime: 15-05-21 11:33
*/

public class Solution
{
    /* you may need to use some attributes here */
    private int[] a;
    private Node root;

    /**
     * @param A: An integer array
     */
    public Solution( int[] A )
    {
        // write your code here
        a = A;
        root = build( 0 , a.length - 1 );
    }

    private Node build( int l , int r )
    {
        if( l > r ) return null;
    	Node root = new Node( l , r );
    	if( l == r )
    	{
    		root.sum = a[l];
    	}
    	else
    	{
    		int m = ( l + r ) / 2;
    		root.lson = build( l , m );
    		root.rson = build( m + 1 , r );
    		root.sum = root.lson.sum + root.rson.sum;
    	}
    	return root;
    }
    
    /**
     * @param start, end: Indices
     * @return: The sum from start to end
     */
    public long query( int start , int end )
    {
        // write your code here
        return getsum( root , start , end );
    }

    private long getsum( Node cur , int l , int r )
    {
        if( cur == null ) return -1;
    	if( cur.l == l && cur.r == r ) return cur.sum;
    	int m = ( cur.l + cur.r ) / 2;
    	if( r <= m ) return getsum( cur.lson , l , r );
    	else if( l > m ) return getsum( cur.rson , l , r );
    	else return getsum( cur.lson , l , m ) + getsum( cur.rson , m + 1 , r );
    }
    
    /**
     * @param index, value: modify A[index] to value.
     */
    public void modify( int index , int value )
    {
        // write your code here
        change( root , index , value );
        a[index] = value;
    }

    private void change( Node cur , int idx , int val )
    {
        if( cur == null ) return ;
    	if( cur.l != cur.r )
    	{
    		int m = ( cur.l + cur.r ) / 2;
    		if( idx <= m ) change( cur.lson , idx , val );
    		else change( cur.rson , idx , val );
    	}
    	cur.sum += ( val - a[idx] );
    }
}

class Node
{
	public int l , r;
	public Node lson , rson;
	public int sum;

	public Node( int l , int r )
	{
		this.l = l;
		this.r = r;
		lson = null;
		rson = null;
		sum = 0;
	}
}













