/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/rotate-string
@Language: Java
@Datetime: 15-05-12 06:24
*/

public class Solution
{
    /*
     * param A: A string
     * param offset: Rotate string with offset.
     * return: Rotated string.
     */
    public char[] rotateString( char[] A , int offset )
    {
        // wirte your code here
        int n = A.length;
        char[] ret = new char[n];
        for( int i = 0 ; i < n ; i ++ )
            ret[( i + offset ) % n] = A[i];
        return ret;
    }
};
