/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/singleton
@Language: Java
@Datetime: 15-06-22 08:08
*/

class Solution
{
    /**
     * @return: The same instance of this class every time
     */
    private static Solution uniqueInstance = new Solution();
    
    public Solution()
    {
        
    }

    public static Solution getInstance()
    {
        return uniqueInstance ;
    }
};
