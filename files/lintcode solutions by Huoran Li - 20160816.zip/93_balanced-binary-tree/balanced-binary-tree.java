/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/balanced-binary-tree
@Language: Java
@Datetime: 15-08-08 07:35
*/

public class Solution
{
    /**
     * @param root: The root of binary tree.
     * @return: True if this Binary tree is Balanced, or false.
     */
    private HashMap<TreeNode,Integer> map;
	
	public boolean isBalanced( TreeNode root )
    {
        // write your code here
    	if( root == null ) return true;
    	
    	map = new HashMap<TreeNode,Integer>();
    	calc_depth( root );
    	return check( root );
    }
	
	private boolean check( TreeNode root )
	{
		if( root == null ) return true;
		if( root.left == null && root.right == null ) return true;
		if( root.left == null )
		{
			if( check( root.right ) == false ) return false;
			if( map.get( root.right ) > 1 ) return false;
			return true;
		}
		if( root.right == null )
		{
			if( check( root.left ) == false ) return false;
			if( map.get( root.left ) > 1 ) return false;
			return true;
		}
		else
		{
			if( check( root.left ) == false ) return false;
			if( check( root.right ) == false ) return false;
			if( abs( map.get( root.left ) - map.get( root.right ) ) > 1 ) return false;
			return true;
		}
	}
	
	private void calc_depth( TreeNode root )
	{
		if( root == null ) return ;
		calc_depth( root.left );
		calc_depth( root.right );
		if( root.left == null && root.right == null ) map.put( root , 1 );
		else if( root.left == null ) map.put( root , map.get( root.right ) + 1 );
		else if( root.right == null ) map.put( root , map.get( root.left ) + 1 );
		else map.put( root , max( map.get( root.left ) , map.get( root.right ) ) + 1 );
	}
	
	private int max( int a , int b )
	{
		return ( a > b ? a : b );
	}
	
	private int abs( int x )
	{
		return ( x < 0 ? x * -1 : x );
	}
}
