# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/gray-code
@Language: Python
@Datetime: 15-11-14 05:45
'''

class Solution:
    # @param {int} n a number
    # @return {int[]} Gray code
    def grayCode(self, n):
        # Write your code here
        if n == 0:
            return [0]
        elif n == 1:
            return [0, 1]
        else:
            a = self.grayCode(n - 1)
            b = list(a)
            b.reverse()
            
            p = 1
            for i in range(n - 1):
                p *= 2
            for i in range(len(b)):
                b[i] += p
            a.extend(b)
            
            return a
                