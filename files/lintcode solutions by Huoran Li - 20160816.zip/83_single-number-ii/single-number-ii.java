/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/single-number-ii
@Language: Java
@Datetime: 15-05-24 03:34
*/

public class Solution
{
	/**
	 * @param A : An integer array
	 * @return : An integer 
	 */
    public int singleNumberII( int[] A )
    {
        // write your code here
        int[] a = A;
        int[] c = new int[32];
        
        for( int i = 0 ; i < 32 ; i ++ )
            c[i] = 0;
        for( int j = 0 ; j < a.length ; j ++ )
        {
            int t = a[j];
            for( int i = 0 ; i < 32 ; i ++ )
            {
                if( ( t & ( 1 << i ) ) != 0 ) c[i] ++;
            }
        }
        
        int ret = 0;
        for( int i = 0 ; i < 32 ; i ++ )
            if( c[i] % 3 != 0 ) ret += ( 1 << i );
        return ret;
    }
}
