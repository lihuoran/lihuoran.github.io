# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning
@Language: Python
@Datetime: 15-10-20 06:32
'''

class Solution:
    # @param s, a string
    # @return a list of lists of string
    def legal( self , a ):
        n = len( a )
        p = 0
        q = n - 1
        while p < q:
            if a[p] != a[q]:
                return False
            p += 1
            q -= 1
        return True
    
    def partition(self, s):
        # write your code here
        ret = []
        n = len( s )
        for i in range( n ):
            cur = s[:i + 1]
            if self.legal( cur ) == False:
                continue
            if i == n - 1:
                ret.append( [cur] )
            else:
                next = self.partition( s[i + 1:] )
                if len( next ) != 0:
                    for e in next:
                        temp = [cur]
                        temp.extend( e )
                        ret.append( temp )
        return ret
