# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-tree-zigzag-level-order-traversal
@Language: Python
@Datetime: 15-09-06 07:07
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""


class Solution:
    """
    @param root: The root of binary tree.
    @return: A list of list of integer include 
             the zig zag level order traversal of its nodes' values
    """
    def zigzagLevelOrder( self , root ):
        # write your code here
        if root == None:
            return []
        
        a = []
        a.append( [root] )
        
        while len( a[-1] ) > 0:
            p = a[-1]
            q = []
            for e in p:
                if e.left != None:
                    q.append( e.left )
                if e.right != None:
                    q.append( e.right )
            a.append( q )
        
        ret = []
        for i in range( len( a ) ):
            e = a[i]
            if i % 2 == 1:
                e.reverse()
            cur = []
            for p in e:
                cur.append( p.val )
            ret.append( cur )
        return ret[:-1]