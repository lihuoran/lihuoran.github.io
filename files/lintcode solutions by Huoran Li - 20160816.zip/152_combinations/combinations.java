/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/combinations
@Language: Java
@Datetime: 15-05-11 15:51
*/

public class Solution
{
    /**
     * @param n: Given the range of numbers
     * @param k: Given the numbers of combinations
     * @return: All the combinations of k numbers out of 1..n
     */
    private ArrayList<List<Integer>> ret;
    private int n , k;
    private int[] arr;
    
    public List<List<Integer>> combine( int n , int k )
    {
		// write your code here
		ret = new ArrayList<List<Integer>>();
		arr = new int[k];
		this.n = n;
		this.k = k;
		dfs( 0 , 0 );
		
		return ret;
    }
    
    private void dfs( int pos , int have )
    {
        if( pos == n && have == k )
        {
            ArrayList<Integer> temp = new ArrayList<Integer>();
            for( int i = 0 ; i < k ; i ++ )
                temp.add( arr[i] );
            ret.add( temp );
        }
        
        if( have > k ) return ;
        if( have + ( n - pos ) < k ) return ;
        dfs( pos + 1 , have );
        if( have == k ) return ;
        
        arr[have] = pos + 1;
        dfs( pos + 1 , have + 1 );
    }
}
