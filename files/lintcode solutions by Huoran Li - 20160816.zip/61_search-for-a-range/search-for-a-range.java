/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-for-a-range
@Language: Java
@Datetime: 15-06-07 06:41
*/

public class Solution
{
    /** 
     *@param A : an integer sorted array
     *@param target :  an integer to be inserted
     *return : a list of length 2, [index1, index2]
     */
    public ArrayList<Integer> searchRange( ArrayList<Integer> A, int target )
    {
        // write your code here
        ArrayList<Integer> ret = new ArrayList<Integer>();
        ArrayList<Integer> a = A;
        int n = a.size();
        int l , r;
        
        boolean find = false;
        l = 0;
            r = n - 1;
        while( l <= r )
        {
            int m = ( l + r ) / 2;
            if( target == a.get( m ) ) { find = true ; break ; }
            if( target < a.get( m ) ) r = m - 1;
            else l = m + 1;
        }
        
        if( !find )
        {
            ret.add( -1 );
            ret.add( -1 );
        }
        else
        {
            l = 0;
            r = n - 1;
            while( l < r )
            {
                int m = ( l + r ) / 2;
                if( target <= a.get( m ) ) r = m;
                else l = m + 1;
            }
            ret.add( r );
            
            l = 0;
            r = n - 1;
            while( l < r )
            {
                int m = ( l + r + 1 ) / 2;
                if( target >= a.get( m ) ) l = m;
                else r = m - 1;
            }
            ret.add( r );
        }
        
        return ret;
    }
}

