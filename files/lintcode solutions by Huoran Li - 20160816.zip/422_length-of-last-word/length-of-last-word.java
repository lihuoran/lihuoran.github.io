/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/length-of-last-word
@Language: Java
@Datetime: 15-06-09 05:31
*/

public class Solution
{
    /**
     * @param s A string
     * @return the length of last word
     */
    public int lengthOfLastWord( String s )
    {
        // Write your code here
        s = s.trim();
        int n = s.length();
        int t = s.lastIndexOf( ' ' );
        
        if( n == 0 ) return 0;
        else if( t == -1 ) return n;
        else return ( n - t - 1 );
    }
}
