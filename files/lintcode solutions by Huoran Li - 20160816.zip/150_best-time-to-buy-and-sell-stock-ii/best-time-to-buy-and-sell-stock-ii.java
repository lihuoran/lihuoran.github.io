/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock-ii
@Language: Java
@Datetime: 15-11-24 07:38
*/

class Solution {
    /**
     * @param prices: Given an integer array
     * @return: Maximum profit
     */
    public int maxProfit(int[] prices) {
        // write your code here
        int n = prices.length;
        if (n <= 1) {
            return 0;
        }
        
        int[] p = new int[n + 2];
        for (int i = 1; i <= n; i += 1) {
            p[i] = prices[i - 1];
        }
        p[0] = Integer.MAX_VALUE;
        p[n + 1] = Integer.MIN_VALUE;
        
        int ret = 0;
        int last = Integer.MAX_VALUE;
        for (int i = 1; i <= n; i += 1) {
            if (p[i] > last) {
                ret += p[i] - last;
            }
            if (p[i] < p[i + 1]) {
                last = p[i];
            } else {
                last = Integer.MAX_VALUE;
            }
        }
        
        return ret;
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
};
