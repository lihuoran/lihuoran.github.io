/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/count-of-smaller-number-before-itself
@Language: Java
@Datetime: 15-12-11 12:53
*/

public class Solution {
	private int[] a;
	private int n;
	private ArrayList<Integer> ret;
	private Node root;
	
	public ArrayList<Integer> countOfSmallerNumberII(int[] A) {
		// write your code here
		ret = new ArrayList<Integer>();
		if (A == null || A.length == 0) {
			return ret;
		}
		
		a = A;
		n = a.length;
		root = build(0, 20000);
		
		for (int i = 0; i < n; i += 1) {
			int val = a[i];
			ret.add(query(root, val));
			modify(root, val);
		}

		return ret;
	}
	
	private void modify(Node root, int val) {
		if (root == null || val < root.l || val > root.r) {
			return;
		}
		
		if (root.l == root.r) {
			root.cnt += 1;
			return;
		}
		
		modify(root.lson, val);
		modify(root.rson, val);
		
		root.cnt = root.lson.cnt + root.rson.cnt;
	}
	
	private int query(Node root, int val) {
		if (root == null) {
			return 0;
		}
		if (root.r < val) {
			return root.cnt;
		}
		if (root.l >= val) {
			return 0;
		}
		
		return query(root.lson, val) + query(root.rson, val);
	}
	
	private Node build(int x, int y) {
		Node ret = new Node(x, y);
		
		if (x < y) {
			int m = (x + y) / 2;
			ret.lson = build(x, m);
			ret.rson = build(m + 1, y);
		}
		
		return ret;
	}
}

class Node {
	public int l, r;
	public Node lson, rson;
	public int cnt;
	
	Node(int x, int y) {
		l = x;
		r = y;
		lson = null;
		rson = null;
		cnt = 0;
	}
}