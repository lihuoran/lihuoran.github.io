/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/house-robber
@Language: Java
@Datetime: 15-07-09 02:52
*/

public class Solution
{
    /**
     * @param A: An array of non-negative integers.
     * return: The maximum amount of money you can rob tonight
     */
    public long houseRobber( int[] A )
    {
        // write your code here
        int[] a = A;
        int n = a.length;
        
        if( n == 0 ) return 0;
        if( n == 1 ) return ( long )( a[0] );
        
        long x = a[0];
        long y = 0;
        for( int i = 1 ; i < n ; i ++ )
        {
            long p , q;
            p = y + a[i];
            q = ( x > y ? x : y );
            x = p;
            y = q;
        }
        
        return ( x > y ? x : y );
    }
}
