# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/cosine-similarity
@Language: Python
@Datetime: 15-09-26 16:46
'''

from math import sqrt

class Solution:
    """
    @param A: An integer array.
    @param B: An integer array.
    @return: Cosine similarity.
    """
    def cosineSimilarity(self, A, B):
        # write your code here
        a = A
        b = B
        if len( a ) != len( b ):
            return 2.0000
        n = len( a )
        if n == 0:
            return 2.0000
        
        u = 0.0
        for i in range( n ):
            u += float( a[i] ) * float( b[i] )
        x = 0.0
        y = 0.0
        for i in range( n ):
            x += float( a[i] ) * float( a[i] )
            y += float( b[i] ) * float( b[i] )
        d = sqrt( x ) * sqrt( y )
        if d == 0:
            return 2.0000
        else:
            return u / d