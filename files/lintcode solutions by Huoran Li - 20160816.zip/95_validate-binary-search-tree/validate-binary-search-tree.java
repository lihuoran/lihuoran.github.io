/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/validate-binary-search-tree
@Language: Java
@Datetime: 15-05-13 05:26
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param root: The root of binary tree.
     * @return: True if the binary tree is BST, or false
     */
    public boolean isValidBST( TreeNode root )
    {
        // write your code here
        if( root == null ) return true;
        
        if( root.left != null )
        {
            if( isValidBST( root.left ) == false ) return false;
            if( root.val <= root.left.val ) return false;
        }
        if( root.right != null )
        {
            if( isValidBST( root.right ) == false ) return false;
            if( root.val >= root.right.val ) return false;
        }
        return true;
    }
}
