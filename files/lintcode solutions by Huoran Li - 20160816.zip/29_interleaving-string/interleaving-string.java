/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/interleaving-string
@Language: Java
@Datetime: 15-09-01 11:28
*/

public class Solution {
    /**
     * Determine whether s3 is formed by interleaving of s1 and s2.
     * @param s1, s2, s3: As description.
     * @return: true or false.
     */
    public boolean isInterleave(String s1, String s2, String s3) {
        // write your code here
    	int l1 = s1.length();
    	int l2 = s2.length();
    	int l3 = s3.length();

    	if( l1 + l2 != l3 ) return false;
    	if( l3 == 0 ) return true;

    	boolean[][] f = new boolean[l3 + 1][l1 + 1];
    	for( int i = 1 ; i <= l3 ; i ++ )
    	for( int j = 0 ; j <= l1 && j <= i  ; j ++ )
    	{
    		if( i - j > l2 )
    		{
    			f[i][j] = false;
    			continue;
    		}

    		if( j == 0 )
    		{
    			String a = s3.substring( 0 , i );
    			String b = s2.substring( 0 , i );
    			f[i][j] = a.equals( b );
    			continue;
    		}

    		if( i == j )
    		{
    			String a = s3.substring( 0 , i );
    			String b = s1.substring( 0 , i );
    			f[i][j] = a.equals( b );
    			continue;
    		}

    		int k = i - j;
    		f[i][j] = false;
    		if( f[i - 1][j - 1] == true && s1.charAt( j - 1 ) == s3.charAt( i - 1 ) ) f[i][j] = true;
    		if( f[i - 1][j] == true && s2.charAt( k - 1 ) == s3.charAt( i - 1 ) ) f[i][j] = true;
    	}

        return f[l3][l1];
    }
}
