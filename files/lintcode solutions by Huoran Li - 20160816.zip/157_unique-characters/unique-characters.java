/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/unique-characters
@Language: Java
@Datetime: 15-05-05 08:07
*/

public class Solution
{
    /**
     * @param str: a string
     * @return: a boolean
     */
    public boolean isUnique( String str ){
        // write your code here
        int[] cnt = new int[256];
        for( int i = 0 ; i < 256 ; i ++ )
            cnt[i] = 0;
            
        for( int i = 0 ; i < str.length() ; i ++ )
        {
            int a = ( int )( str.charAt( i ) );
            if( cnt[a] != 0 ) return false;
            cnt[a] ++;
        }
        
        return true;
    }
}
