/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sort-letters-by-case
@Language: Java
@Datetime: 16-02-07 15:56
*/

class Solution {
    /** 
     *@param chars: The letter array you should sort by Case
     *@return: void
     */
    public void sortLetters(char[] chars) {
        //write your code here
        int n = chars.length;
        int x = 0, y = n - 1;
        
        while (x <= y) {
            while (x <= y && isUpper(chars[x]) == false)
                x ++;
            while (x <= y && isUpper(chars[y]) == true)
                y --;
            if (x <= y) {
                char temp = chars[x];
                chars[x] = chars[y];
                chars[y] = temp;
                x += 1;
                y -= 1;
            }
        }
    }
    
    private boolean isUpper(char c) {
        return (c >= 'A' && c <= 'Z');
    }
}
