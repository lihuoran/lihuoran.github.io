/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/trailing-zeros
@Language: Java
@Datetime: 16-02-06 11:59
*/

class Solution
{
    /*
     * param n: As desciption
     * return: An integer, denote the number of trailing zeros in n!
     */
    public long trailingZeros( long n )
    {
        // write your code here
    	long nZeros = 0;
    	long base = 5;
    	
    	while (true) {
    		nZeros += n / base;
    		if (n / base < 5) {
    			break;
    		} else {
    			base *= 5;
    		}
    	}
    	
    	return nZeros;
    }
};
