/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-linked-list-ii
@Language: Java
@Datetime: 15-11-14 16:16
*/

/**
 * Definition for ListNode public class ListNode { int val; ListNode next;
 * ListNode(int x) { val = x; next = null; } }
 */
public class Solution {
	/**
	 * @param ListNode
	 *            head is the head of the linked list
	 * @oaram m and n
	 * @return: The head of the reversed ListNode
	 */
	public ListNode reverseBetween(ListNode head, int m, int n) {
		// write your code
		Stack<ListNode> s = new Stack<ListNode>();
		ListNode fakehead = new ListNode(0);
		fakehead.next = head;
		ListNode cur = fakehead;
		ListNode tail = null;

		for (int i = 1; i < m; i += 1) {
			cur = cur.next;
		}
		tail = cur;
		cur = cur.next;
		for (int i = m; i <= n; i += 1) {
			ListNode temp = cur;
			cur = cur.next;
			temp.next = null;
			s.push(temp);
		}

		while (s.isEmpty() == false) {
			tail.next = s.pop();
			tail = tail.next;
		}
		tail.next = cur;

		return fakehead.next;
	}
}