/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/minimum-depth-of-binary-tree
@Language: Java
@Datetime: 15-05-06 05:52
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param root: The root of binary tree.
     * @return: An integer.
     */
    public int minDepth( TreeNode root )
    {
        // write your code here
        if( root == null ) return 0;
        
        int a = minDepth( root.left );
        int b = minDepth( root.right );
        if( a == 0 && b == 0 ) return 1;
        if( a == 0 || b == 0 ) return a + b + 1;
        return min( a , b ) + 1;
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
}
