/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/convert-expression-to-reverse-polish-notation
@Language: Java
@Datetime: 15-05-12 05:58
*/

public class Solution
{
    /**
     * @param expression: A string array
     * @return: The Reverse Polish notation of this expression
     */
    public ArrayList<String> convertToRPN( String[] expression )
    {
        // write your code here
        ArrayList<String> ret = new ArrayList<String>();
        String[] e = expression;
        int n = e.length;
        Stack<String> s = new Stack<String>();
        
        for( int i = 0 ; i < n ; i ++ )
            if( e[i].equals( "(" ) )
            {
                s.push( e[i] );
            }
            else if( e[i].equals( ")" ) )
            {
                while( s.peek().equals( "(" ) == false )
                    ret.add( s.pop() );
                s.pop();
            }
            else if( isOpr( e[i] ) )
            {
                while( !s.empty() && level( s.peek() ) >= level( e[i] ) )
                    ret.add( s.pop() );
                s.push( e[i] );
            }
            else ret.add( e[i] );
        while( !s.empty() ) ret.add( s.pop() );
        
        return ret;
    }
    
    private int level( String s )
    {
        if( s.equals( "+" ) ) return 1;
        if( s.equals( "-" ) ) return 1;
        if( s.equals( "*" ) ) return 2;
        if( s.equals( "/" ) ) return 2;
        return -1;
    }
    
    private boolean isOpr( String s )
    {
        if( s.equals( "+" ) ) return true;
        if( s.equals( "-" ) ) return true;
        if( s.equals( "*" ) ) return true;
        if( s.equals( "/" ) ) return true;
        return false;
    }
}

