/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/unique-binary-search-trees-ii
@Language: Java
@Datetime: 15-05-11 15:36
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @paramn n: An integer
     * @return: A list of root
     */
    private MyList[][] repo;
    private int n;
     
    public List<TreeNode> generateTrees( int n )
    {
        // write your code here
        this.n = n;
        repo = new MyList[n + 1][n + 1];
        for( int i = 1 ; i <= n ; i ++ )
        for( int j = i ; j <= n ; j ++ )
            repo[i][j] = null;
        
        return build( 1 , n );
    }
    
    private ArrayList<TreeNode> build( int l , int r )
    {
        ArrayList<TreeNode> ret = new ArrayList<TreeNode>();
        if( l > n || r < 1 || l > r )
        {
            ret.add( null );
            return ret;
        }
        else
        {
            if( repo[l][r] != null ) return repo[l][r].list;
            for( int i = l ; i <= r ; i ++ )
            {
                ArrayList<TreeNode> llist = build( l , i - 1 );
                ArrayList<TreeNode> rlist = build( i + 1 , r );
                for( TreeNode lson : llist )
                for( TreeNode rson : rlist )
                {
                    TreeNode temp = new TreeNode( i );
                    temp.left = lson;
                    temp.right = rson;
                    ret.add( temp );
                }
            }
        }
        
        repo[l][r] = new MyList();
        repo[l][r].list = ret;
        return ret;
    }
}

class MyList
{
    public ArrayList<TreeNode> list;
    
    public MyList()
    {
        list = new ArrayList<TreeNode>();
    }
}

























