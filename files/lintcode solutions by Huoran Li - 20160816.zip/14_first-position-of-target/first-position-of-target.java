/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/first-position-of-target
@Language: Java
@Datetime: 15-05-06 05:48
*/

class Solution
{
    /**
     * @param nums: The integer array.
     * @param target: Target to find.
     * @return: The first position of target. Position starts from 0.
     */
    public int binarySearch( int[] nums , int target )
    {
        //write your code here
        int n = nums.length;
        int l = 0 , r = n - 1;
        while( l <= r )
        {
            if( l == r )
            {
                if( target == nums[l] ) return l;
                return -1;
            }
            
            int mid = ( l + r ) / 2;
            if( target > nums[mid] ) l = mid + 1;
            else r = mid;
        }
        return -1;
    }
}
