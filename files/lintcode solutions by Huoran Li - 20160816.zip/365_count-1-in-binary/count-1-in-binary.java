/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/count-1-in-binary
@Language: Java
@Datetime: 15-05-24 03:04
*/

public class Solution {
    /**
     * @param num: an integer
     * @return: an integer, the number of ones in num
     */
    public int countOnes(int num)
    {
        // write your code here
        int ret = 0;
        while( num > 0 )
        {
            ret += ( num % 2 );
            num /= 2;
        }
        return ret;
    }
};
