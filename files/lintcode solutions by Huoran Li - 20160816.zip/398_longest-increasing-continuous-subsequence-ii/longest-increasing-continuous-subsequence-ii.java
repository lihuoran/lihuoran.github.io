/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-increasing-continuous-subsequence-ii
@Language: Java
@Datetime: 15-07-09 02:48
*/

public class Solution {
    /**
     * @param A an integer matrix
     * @return  an integer
     */
    private int[][] a;
    private int[][] f;
    private int r , c;
    
    private void walk( int x , int y )
    {
        f[x][y] = 1;
        if( x > 0 && a[x][y] > a[x - 1][y] )
        {
            if( f[x - 1][y] == 0 ) walk( x - 1 , y );
            f[x][y] = max( f[x][y] , f[x - 1][y] + 1 );
        }
        if( x < r - 1 && a[x][y] > a[x + 1][y] )
        {
            if( f[x + 1][y] == 0 ) walk( x + 1 , y );
            f[x][y] = max( f[x][y] , f[x + 1][y] + 1 );
        }
        if( y > 0 && a[x][y] > a[x][y - 1] )
        {
            if( f[x][y - 1] == 0 ) walk( x , y - 1 );
            f[x][y] = max( f[x][y] , f[x][y - 1] + 1 );
        }
        if( y < c - 1 && a[x][y] > a[x][y + 1] )
        {
            if( f[x][y + 1] == 0 ) walk( x , y + 1 );
            f[x][y] = max( f[x][y] , f[x][y + 1] + 1 );
        }
    }
    
    public int longestIncreasingContinuousSubsequenceII( int[][] A )
    {
        // Write your code here
        try
        {
            a = A;
            r = a.length;
            c = a[0].length;
            f = new int[r][c];
            for( int i = 0 ; i < r ; i ++ )
            for( int j = 0 ; j < c ; j ++ )
                f[i][j] = 0;
            
            int ret = 1;    
            for( int i = 0 ; i < r ; i ++ )
            for( int j = 0 ; j < c ; j ++ )
            {
                if( f[i][j] == 0 )
                {
                    walk( i , j );
                }
                ret = max( ret , f[i][j] );
            }
                
            return ret;
        }
        catch( Exception e )
        {
            return 0;
        }
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
