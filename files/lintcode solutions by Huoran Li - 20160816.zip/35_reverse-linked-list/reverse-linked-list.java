/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-linked-list
@Language: Java
@Datetime: 15-08-06 03:39
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The head of linked list.
     * @return: The new head of reversed linked list.
     */
    public ListNode reverse( ListNode head )
    {
        // write your code here
        if( head == null ) return null;
        if( head.next == null ) return head;

        ListNode p = reverse( head.next );
        ListNode q = p;
        while( q.next != null ) q = q.next;
        head.next = null;
        q.next = head;

        return p;
    }
}

