/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/number-of-islands-ii
@Language: Java
@Datetime: 15-07-02 06:40
*/

public class Solution
{
    /**
     * @param n an integer
     * @param m an integer
     * @param operators an array of point
     * @return an integer array
     */
    private int r , c;
    private ArrayList<Integer> ret;
    private boolean[][] map;
    private int[] father;
    private int tot;
    
    public List<Integer> numIslands2( int n , int m , Point[] operators )
    {
    	if( operators == null || operators.length == 0 ) return new ArrayList<Integer>();
    	
        // Write your code here
        ret = new ArrayList<Integer>();
        tot = n * m;
        r = n;
        c = m;
        map = new boolean[r][c];
        
        // union
        father = new int[tot];
        for( int i = 0 ; i < tot ; i ++ )
        	father[i] = i;
        
        int cnt = 0;
        for( Point p : operators )
        {
        	int x = p.x , y = p.y;
        	ArrayList<Point> templist = new ArrayList<Point>();
        	
        	map[x][y] = true;
        	if( x > 0 && map[x - 1][y] ) templist.add( new Point( x - 1 , y ) );
        	if( y > 0 && map[x][y - 1] ) templist.add( new Point( x , y - 1 ) );
        	if( x < r - 1 && map[x + 1][y] ) templist.add( new Point( x + 1 , y ) );
        	if( y < c - 1 && map[x][y + 1] ) templist.add( new Point( x , y + 1 ) );
        	
        	if( templist.size() == 0 ) cnt ++;
        	else
        	{
        		int a = templist.get( 0 ).x * c + templist.get( 0 ).y;
        		int b = x * c + y;
        		con( a , b );
        		for( int i = 1 ; i < templist.size() ; i ++ )
        		{
        			a = templist.get( i ).x * c + templist.get( i ).y;
        			if( root( a ) != root( b ) )
        			{
        				cnt --;
        				con( a , b );
        			}
        		}
        	}
        	
        	ret.add( cnt );
        }
        
        return ret;
    }
    
    private void con( int x , int y )
    {
    	father[root( x )] = root( y );
    }
    
    private int root( int x )
    {
    	if( x == father[x] ) return x;
    	father[x] = root( father[x] );
    	return father[x];
    }
}