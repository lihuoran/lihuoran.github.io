# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/lru-cache
@Language: Python
@Datetime: 15-11-14 15:35
'''

class LRUCache:

    # @param capacity, an integer
    def __init__(self, capacity):
        # write your code here
        self.n = capacity
        self.clock = 0
        self.dmap = {}
        self.cmap = {}

    # @return an integer
    def get(self, key):
        # write your code here
        self.clock += 1
        if key in self.dmap:
        	self.cmap[key] = self.clock
        	return self.dmap[key]
        else:
        	return -1
        
    # @param key, an integer
    # @param value, an integer
    # @return nothing
    def set(self, key, value):
        # write your code here
        self.clock += 1
        if key in self.dmap:
        	self.cmap[key] = self.clock
        	self.dmap[key] = value
        elif len(self.dmap) < self.n:
        	self.cmap[key] = self.clock
        	self.dmap[key] = value
        else:
        	find = False
        	fk = -1
        	for k in self.dmap:
        		if find == False or (self.cmap[k] < self.cmap[fk]):
        			fk = k
        			find = True
        	self.dmap.pop(fk)
        	self.cmap.pop(fk)
        	self.cmap[key] = self.clock
        	self.dmap[key] = value
