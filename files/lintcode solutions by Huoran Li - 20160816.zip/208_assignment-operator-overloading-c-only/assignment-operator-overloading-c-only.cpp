/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/assignment-operator-overloading-c-only
@Language: C++
@Datetime: 15-12-17 06:41
*/

class Solution {
public:
	char *m_pData;
	Solution() {
		this->m_pData = NULL;
	}
	Solution(char *pData) {
		this->m_pData = pData;
	}
	
	// Implement an assignment operator
	Solution operator=(const Solution &object) {
		// write your code here
		char* buff;
		int n;
		if (object.m_pData != NULL) {
    		n = strlen(object.m_pData);
    		buff = new char[n + 1];
    		copy(buff, object.m_pData);
		} else {
		    buff = NULL;
		}
		
		if (this->m_pData != NULL) {
			delete this->m_pData;
		}
		
		if (buff != NULL) {
		    this->m_pData = new char[n + 1];
		    copy(this->m_pData, buff);
		} else {
		    this->m_pData = NULL;
		    delete buff;
		}
		
		return *this;
	}
	
	void copy(char* a, char* b) {
		int n = strlen(b);
		for (int i = 0; i < n; i += 1) {
			a[i] = b[i];
		}
		a[n] = '\0';
	}
};