/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-subarray-ii
@Language: Java
@Datetime: 16-02-07 15:38
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: An integer denotes the sum of max two non-overlapping subarrays
     */
    public int maxTwoSubArrays(ArrayList<Integer> nums) {
        // write your code
        int n = nums.size();
        int[] l = new int[n];
        int[] r = new int[n];
        
        int cur;
        int global;
        
        l[0] = global = cur = nums.get(0);
        for (int i = 1; i < n; i += 1) {
            cur = max(nums.get(i), cur + nums.get(i));
            global = max(global, cur);
            l[i] = global;
        }
        
        r[n - 1] = global = cur = nums.get(n - 1);
        for (int i = n - 2; i >= 0; i -= 1) {
            cur = max(nums.get(i), cur + nums.get(i));
            global = max(global, cur);
            r[i] = global;
        }
        
        int ret = Integer.MIN_VALUE;
        for (int i = 0; i < n - 1; i += 1) {
            ret = max(ret, l[i] + r[i + 1]);
        }
        
        return ret;
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
}


