/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/candy
@Language: Java
@Datetime: 15-11-22 07:20
*/

public class Solution {
    /**
     * @param ratings Children's ratings
     * @return the minimum candies you must give
     */
    private int[] r;
    private int n;
    private int[] c;
    
    public int candy(int[] ratings) {
        // Write your code here
        n = ratings.length;
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        
        r = ratings;
        c = new int[n];
        for (int i = 0; i < n; i += 1) {
            c[i] = 0;
        }
        
        int ret = 0;
        for (int i = 0; i < n; i += 1) {
            assign(i);
            ret += c[i];
        }
        return ret;
    }
    
    private void assign(int x) {
        if (c[x] != 0) {
            return;
        }
        
        if (x == 0) {
            if (r[x] > r[x + 1]) {
                assign(x + 1);
                c[x] = c[x + 1] + 1;
            } else {
                c[x] = 1;
            }
        } else if (x == n - 1) {
            if (r[x] > r[x - 1]) {
                assign(x - 1);
                c[x] = c[x - 1] + 1;
            } else {
                c[x] = 1;
            }
        } else {
            c[x] = 1;
            if (r[x] > r[x - 1]) {
                assign(x - 1);
                c[x] = max(c[x], c[x - 1] + 1);
            }
            if (r[x] > r[x + 1]) {
                assign(x + 1);
                c[x] = max(c[x], c[x + 1] + 1);
            }
        }
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
}
