/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-the-missing-number
@Language: Java
@Datetime: 15-09-17 05:29
*/

public class Solution {
    /**    
     * @param nums: an array of integers
     * @return: an integer
     */
    public int findMissing( int[] nums )
    {
        // write your code here
        int[] a = nums;
        int n = a.length;
        int s = 0;
        for( int i = 0 ; i < n ; i ++ )
            s += a[i];
            
        return n * ( n + 1 ) / 2 - s;
    }
}
