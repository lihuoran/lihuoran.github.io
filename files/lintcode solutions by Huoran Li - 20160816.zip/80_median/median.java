/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/median
@Language: Java
@Datetime: 15-11-16 04:56
*/

public class Solution {
    /**
     * @param nums: A list of integers.
     * @return: An integer denotes the middle number of the array.
     */
    public int median(int[] nums) {
        // write your code here
        if (nums == null || nums.length == 0) {
            return -1;
        }
        
        qsort(nums, 0, nums.length - 1);
        return nums[(nums.length - 1) / 2];
    }
    
    private void qsort(int[] a, int l, int r) {
        if (l >= r) {
            return;
        }
        
        int x = partition(a, l, r);
        qsort(a, l, x - 1);
        qsort(a, x + 1, r);
    }
    
    private int partition(int[] a, int l, int r) {
        int t = l;
        int temp;
        for (int i = l + 1; i <= r; i += 1) {
            if (a[i] < a[l]) {
                t += 1;
                temp = a[t];
                a[t] = a[i];
                a[i] = temp;
            }
        }
        temp = a[t];
        a[t] = a[l];
        a[l] = temp;
        return t;
    }
}
