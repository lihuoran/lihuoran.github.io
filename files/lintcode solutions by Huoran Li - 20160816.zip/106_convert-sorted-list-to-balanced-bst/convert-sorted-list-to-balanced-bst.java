/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/convert-sorted-list-to-balanced-bst
@Language: Java
@Datetime: 15-05-24 03:24
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The first node of linked list.
     * @return: a tree node
     */
    public TreeNode sortedListToBST( ListNode head )
    {  
        // write your code here
        return build( head , len( head ) );
    }
    
    private TreeNode build( ListNode head , int n )
    {
        if( head == null || n == 0 ) return null;
        int idx;
        if( n % 2 == 1 ) idx = ( n + 1 ) / 2;
        else idx = n / 2;
        
        ListNode cur = head;
        for( int i = 1 ; i < idx ; i ++ )
            cur = cur.next;
        TreeNode ret = new TreeNode( cur.val );
        ret.left = build( head , idx - 1 );
        ret.right = build( cur.next , n - idx );
        
        return ret;
    }
    
    private int len( ListNode head )
    {
        int cnt = 0;
        while( head != null )
        {
            cnt ++;
            head = head.next;
        }
        return cnt;
    }
}

