# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/letter-combinations-of-a-phone-number
@Language: Python
@Datetime: 15-10-30 07:31
'''

class Solution:
    # @param {string} digits A digital string
    # @return {string[]} all posible letter combinations
    def letterCombinations(self, digits):
        # Write your code here
        self.ret = []
        self.key = {}
        self.key[2] = ['a' , 'b' , 'c']
        self.key[3] = ['d' , 'e' , 'f']
        self.key[4] = ['g' , 'h' , 'i']
        self.key[5] = ['j' , 'k' , 'l']
        self.key[6] = ['m' , 'n' , 'o']
        self.key[7] = ['p' , 'q' , 'r' , 's']
        self.key[8] = ['t' , 'u' , 'v']
        self.key[9] = ['w' , 'x' , 'y' , 'z']
        
        self.run( digits , '' )
        return self.ret
        
    def run( self , digits , cur ):
        if len( digits ) == 0:
            if len( cur ) > 0:
                self.ret.append( cur )
            return
        h = int( digits[0] )
        for e in self.key[h]:
            temp = '%s%s' % ( cur , e )
            self.run( digits[1:] , temp )
        return
        
