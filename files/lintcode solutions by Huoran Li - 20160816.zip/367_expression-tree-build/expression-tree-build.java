/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/expression-tree-build
@Language: Java
@Datetime: 15-05-05 14:02
*/

/**
 * Definition of ExpressionTreeNode:
 * public class ExpressionTreeNode {
 *     public String symbol;
 *     public ExpressionTreeNode left, right;
 *     public ExpressionTreeNode(String symbol) {
 *         this.symbol = symbol;
 *         this.left = this.right = null;
 *     }
 * }
 */

public class Solution
{
    /**
     * @param expression: A string array
     * @return: The root of expression tree
     */
    private String[] e;
    private int n;

    public ExpressionTreeNode build( String[] expression )
    {
        // write your code here
    	e = expression;
    	n = e.length;

    	return buildtree( 0 , n - 1 );
    }

    private ExpressionTreeNode buildtree( int l , int r )
    {
        if( l > r ) return null;
        
    	if( l == r )
    	{
    		ExpressionTreeNode root = new ExpressionTreeNode( e[l] );
    		return root;
    	}

    	int pos = -1;
    	int lev = -1;
    	int bra = 0;

    	for( int i = l ; i <= r ; i ++ )
    	{
    		if( e[i].equals( "(" ) ) bra ++;
    		else if( e[i].equals( ")" ) ) bra --;
    		else if( !isNumber( e[i] ) )
    		{
    			if( bra != 0 ) continue;
    			int cur = getLevel( e[i] );
    			if( lev == -1 || cur <= lev )
    			{
    				lev = cur;
    				pos = i;
    			}
    		}
    	}

    	if( pos == -1 ) return buildtree( l + 1 , r - 1 );

    	ExpressionTreeNode root = new ExpressionTreeNode( e[pos] );
    	root.left = buildtree( l , pos - 1 );
    	root.right = buildtree( pos + 1 , r );
    	
    	return root;
    }

    private boolean isNumber( String a )
    {
    	int n = a.length();
    	for( int i = 0 ; i < n ; i ++ )
    	{
    		char c = a.charAt( i );
    		if( c < '0' || c > '9' ) return false;
    	}
    	return true;
    }

    private int getLevel( String opr )
    {
    	if( opr.equals( "*" ) ) return 2;
    	if( opr.equals( "/" ) ) return 2;
    	if( opr.equals( "+" ) ) return 1;
    	if( opr.equals( "-" ) ) return 1;
    	return 0;
    }
}