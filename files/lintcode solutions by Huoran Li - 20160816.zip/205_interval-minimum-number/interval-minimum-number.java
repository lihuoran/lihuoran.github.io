/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/interval-minimum-number
@Language: Java
@Datetime: 15-05-21 08:22
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */
public class Solution
{
    /**
     *@param A, queries: Given an integer array and an query list
     *@return: The result list
     */
    private int[] a;
    private int n;
    private Node root;

    public ArrayList<Integer> intervalMinNumber( int[] A , ArrayList<Interval> queries )
    {
        // write your code here
        a = A;
        ArrayList<Integer> ret = new ArrayList<Integer>();
        n = a.length;

        root = buildtree( 0 , n - 1 );

        for( Interval itv : queries )
        {
            ret.add( query( root , itv.start , itv.end ) );
        }
        
        return ret;
    }

    private int query( Node cur , int l , int r )
    {
    	if( cur.l == l && cur.r == r ) return cur.val;

    	int m = ( cur.l + cur.r ) / 2;
    	if( r <= m ) return query( cur.lson , l , r );
    	else if( l > m ) return query( cur.rson , l , r );
    	else return min( query( cur.lson , l , m ) , query( cur.rson , m + 1 , r ) );
    }

    private Node buildtree( int l , int r )
    {
    	Node root = new Node( l , r );
    	if( l != r )
    	{
    		int m = ( l + r ) / 2;
    		root.lson = buildtree( l , m );
    		root.rson = buildtree( m + 1 , r );
    		root.val = min( root.lson.val , root.rson.val );
    	}
    	else
    	{
    		root.val = a[l];
    	}
    	return root;
    }

    private static int min( int a , int b )
	{
		if( a == -1 ) return b;
		if( b == -1 ) return a;
		return ( a < b ? a : b );
	}
}

class Node
{
	public int l , r;
	public Node lson , rson;
	public int val;

	public Node( int l , int r )
	{
		this.l = l;
		this.r = r;
		lson = null;
		rson = null;
		val = -1;
	}
}






















