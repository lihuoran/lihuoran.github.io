# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-gap
@Language: Python
@Datetime: 15-12-03 05:07
'''

class Solution:
     # @param nums: a list of integers
     # @return: the maximum difference
    def maximumGap(self, nums):
        # write your code here
        a = nums
        n = len(a)
        
        a.sort()
        val = 0
        for i in range(n - 1):
            val = max(val, a[i + 1] - a[i])
        return val
