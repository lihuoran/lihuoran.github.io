/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-common-subsequence
@Language: Java
@Datetime: 15-05-13 05:42
*/

public class Solution
{
    /**
     * @param A, B: Two strings.
     * @return: The length of longest common subsequence of A and B.
     */
    public int longestCommonSubsequence( String A, String B )
    {
        // write your code here
        String a = "." + A;
        String b = "." + B;
        int m = a.length();
        int n = b.length();
        int[][] f = new int[m][n];
        
        f[0][0] = 0;
        for( int i = 1 ; i < m ; i ++ )
        for( int j = 1 ; j < n ; j ++ )
            if( a.charAt( i ) == b.charAt( j ) )
                f[i][j] = f[i - 1][j - 1] + 1;
            else
                f[i][j] = max( f[i - 1][j] , f[i][j - 1] );
                
        return f[m - 1][n - 1];
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}

