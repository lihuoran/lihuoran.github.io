/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/n-queens-ii
@Language: Java
@Datetime: 15-05-24 03:18
*/

class Solution
{
    /**
     * Calculate the total number of distinct N-Queen solutions.
     * @param n: The number of queens.
     * @return: The total number of distinct solutions.
     */
    private int ret;
    private int lim;
   
    public int totalNQueens( int n )
    {
        //write your code here
        ret = 0;
        lim = ( 1 << n ) - 1;
        calc( 0 , 0 , 0 );
        return ret;
    }
    
    private void calc( int row , int ld , int rd )
    {
        if( row == lim ) ret ++;
        else
        {
            int pos = lim & ( ~( row | ld | rd ) );
            while( pos > 0 )
            {
                int p = pos & ( ~pos + 1 );
                pos -= p;
                calc( row | p , ( ld | p ) << 1 , ( rd | p ) >> 1 );
            }
        }
    }
};


