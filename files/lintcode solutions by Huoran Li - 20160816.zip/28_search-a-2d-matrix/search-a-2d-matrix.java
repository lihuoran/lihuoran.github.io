/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-a-2d-matrix
@Language: Java
@Datetime: 15-05-07 12:30
*/

public class Solution
{
    /**
     * @param matrix, a list of lists of integers
     * @param target, an integer
     * @return a boolean, indicate whether matrix contains target
     */
    public boolean searchMatrix( int[][] matrix , int target )
    {
        // write your code here
        try
        {
            int r = matrix.length;
            int c = matrix[0].length;
            
            int x = getR( matrix , target );
            if( x == -1 ) return false;
            int y = getC( matrix , x , target );
            if( y == -1 ) return false;
            
            return true;
        }
        catch( Exception e )
        {
            return false;
        }
    }
    
    private int getC( int[][] m , int x , int target )
    {
        int c = m[0].length;
        if( target > m[x][c - 1] ) return -1;
        int p = 0 , q = c - 1;
        while( p <= q )
        {
        	int mid = ( p + q ) / 2;
        	if( target == m[x][mid] ) return mid;
        	else if( target < m[x][mid] ) q = mid - 1;
        	else p = mid + 1;
        }
        return -1;
    }
    
    private int getR( int[][] m , int target )
    {
        int r = m.length;
        
        if( target < m[0][0] ) return -1;
        
        int x = 0 , y = r - 1;
        while( x < y - 1 )
        {
            int mid = ( x + y ) / 2;
            if( target >= m[mid][0] ) x = mid;
            else y = mid - 1;
        }
        if( target >= m[y][0] ) return y;
        return x;
    }
}