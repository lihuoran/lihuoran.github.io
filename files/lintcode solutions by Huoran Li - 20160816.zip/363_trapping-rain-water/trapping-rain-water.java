/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/trapping-rain-water
@Language: Java
@Datetime: 15-11-14 06:23
*/

public class Solution {
    public int trapRainWater(int[] heights) {
        // write your code here
    	int[] h = heights;
    	int n = h.length;
    	if (n <= 2) {
    		return 0;
    	}
    	
    	int secH = 0;
    	int left = 0;
    	int right = n - 1;
    	int area = 0;
    	while (left < right) {
    		if (h[left] < h[right]) {
    			secH = max(h[left], secH);
    			area += secH - h[left];
    			left += 1;
    		} else {
    			secH = max(h[right], secH);
    			area += secH - h[right];
    			right -= 1;
    		}
    	}
    	
    	return area;
    }
    
    private int max(int a, int b) {
    	return (a > b ? a : b);
    }
}