/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/perfect-squares
@Language: Java
@Datetime: 16-03-27 09:08
*/

public class Solution {
	private HashMap<Integer, Integer> ans;
	private HashSet<Integer> pset;
	
	public int numSquares(int n) {
		// Write your code here
		int[] f = new int[n + 1];
		for (int i = 1; i <= n; i += 1) {
			f[i] = Integer.MAX_VALUE;
		}
		for (int i = 1; i * i <= n; i += 1) {
			f[i * i] = 1;
		}
		
		for (int i = 1; i <= n; i += 1) {
			for (int j = 1; j <= 46340 && i + j * j <= n && i + j * j > 0; j += 1) {
				f[i + j * j] = Math.min(f[i] + 1, f[i + j * j]);
			}
		}
		
		return f[n];
	}
}