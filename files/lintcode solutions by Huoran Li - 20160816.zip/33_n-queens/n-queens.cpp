/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/n-queens
@Language: C++
@Datetime: 15-08-10 03:09
*/

class Solution {
public:
    vector<vector<string>> solution;
    
    void generate_solution(const vector<int>& queen)
    {
        vector<string> s;
        for(int i = 0; i < queen.size(); ++i)
        {
            string l(queen.size(), '.');
            l[queen[i]] = 'Q';
            s.emplace_back(move(l));     // avoid copy!
        }
        solution.emplace_back(move(s));
    }
    
    void traverse_solution_space(vector<int>& queen, int placed, int total)
    {
        if (placed == total)
        {
            generate_solution(queen);    
            return;
        }
        
        // try place the queens
        for(int i = 0; i < queen.size(); ++i)
        {
            bool valid = true;
            // verify the position
            for(int j = 0; j < placed; ++j)
            {
                if (i == queen[j] ||  // same column
                    abs(queen[j] - i) == placed - j) // diagonal attack
                {
                    valid = false;
                    break;
                }
            }
            
            if (valid)
            {
                queen[placed] = i;
                traverse_solution_space(queen, placed + 1, total);
            }
        }
    }

    vector<vector<string> > solveNQueens(int n) {
        solution.clear();
        vector<int> queen(n);
        
        traverse_solution_space(queen, 0, n);
        
        return solution;
    }
};