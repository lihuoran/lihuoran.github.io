/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/n-queens
@Language: Java
@Datetime: 16-02-06 16:07
*/

class Solution {
    /**
     * Get all distinct N-Queen solutions
     * @param n: The number of queens
     * @return: All distinct solutions
     * For example, A string '...Q' shows a queen on forth position
     */
	private ArrayList<ArrayList<String>> ret;
	
	private int n;
	private boolean[] col;
	private boolean[] ldiag;
	private boolean[] rdiag;
	
	ArrayList<ArrayList<String>> solveNQueens(int n) {
        // write your code here
		init(n);
		dfs(0, n, new ArrayList<String>());
    	return ret;
    }
	
	private void init(int n) {
		this.n = n;
		ret = new ArrayList<ArrayList<String>>();
		col = new boolean[n];
		ldiag = new boolean[n * 2 - 1];
		rdiag = new boolean[n * 2 - 1];
	}
	
	private void dfs(int curline, int n, ArrayList<String> board) {
		if (curline == n) {
			ret.add(board);
		} else {
			for (int i = 0; i < n; i += 1) {
				if (check(curline, i) == true) {
					put(curline, i);
					ArrayList<String> newBoard = new ArrayList<String>(board);
					newBoard.add(drawLine(i));
					dfs(curline + 1, n, newBoard);
					clear(curline, i);
				}
			}
		}
	}
	
	private String drawLine(int pos) {
		String line = "";
		for (int i = 0; i < n; i += 1) {
			if (i == pos) {
				line += "Q";
			} else {
				line += ".";
			}
		}
		return line;
	}
	
	private boolean check(int r, int c) {
		// check if (r, c) is available
		if (col[c] == true || ldiag[(r - c) + (n - 1)] == true || rdiag[(r + c)] == true) {
			return false;
		} else {
			return true;
		}
	}
	
	private void put(int r, int c) {
		col[c] = true;
		ldiag[(r - c) + (n - 1)] = true;
		rdiag[(r + c)] = true;
	}
	
	private void clear(int r, int c) {
		col[c] = false;
		ldiag[(r - c) + (n - 1)] = false;
		rdiag[(r + c)] = false;
	}
}