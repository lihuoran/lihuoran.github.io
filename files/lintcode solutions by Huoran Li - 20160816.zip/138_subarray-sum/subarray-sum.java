/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subarray-sum
@Language: Java
@Datetime: 15-05-07 11:40
*/

public class Solution
{
    /**
     * @param nums: A list of integers
     * @return: A list of integers includes the index of the first number 
     *          and the index of the last number
     */
    public ArrayList<Integer> subarraySum( int[] nums )
    {
        // write your code here
        int[] a = nums;
        int n = a.length;
        int[] sum = new int[n];
        for( int i = 0 ; i < n ; i ++ )
            if( i == 0 ) sum[i] = a[i];
            else sum[i] = a[i] + sum[i - 1];
            
        ArrayList<Integer> ret = new ArrayList<Integer>();
        for( int i = 0 ; i < n ; i ++ )
        for( int j = i ; j < n ; j ++ )
        {
            int temp = ( i == 0 ? sum[j] : sum[j] - sum[i - 1] );
            if( temp == 0 )
            {
                ret.add( i );
                ret.add( j );
                return ret;
            }
        }
        return ret;
    }
}
