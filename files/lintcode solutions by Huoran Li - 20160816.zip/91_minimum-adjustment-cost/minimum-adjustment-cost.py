# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/minimum-adjustment-cost
@Language: Python
@Datetime: 15-12-12 05:34
'''

class Solution:
	def MinAdjustmentCost(self, A, target):
		if len(A) <= 1:
			return 0

		a = A
		n = len(a)
		f = []
		for i in range(n):
			cur = []
			for j in range(200):
				cur.append(0)
			f.append(cur)

		for j in range(1, 101):
			f[0][j] = abs(a[0] - j)
		for i in range(1, n):
			for j in range(1, 101):
				this_cost = abs(a[i] - j)
				f[i][j] = 200 * n
				for k in range(j - target, j + target + 1):
					if k < 1 or k > 100:
						continue
					f[i][j] = min(f[i - 1][k], f[i][j])
				f[i][j] += this_cost

		ret = 200 * n
		for j in range(1, 101):
			ret = min(ret, f[n - 1][j])
		return ret