/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/graph-valid-tree
@Language: Java
@Datetime: 15-12-13 15:25
*/

public class Solution {
    public boolean validTree(int n, int[][] edges) {
        int m = edges.length;
        if (n != m + 1) {
            return false;
        }
        
        Union u = new Union(n);
        for (int i = 0; i < m; i += 1) {
            u.union(edges[i][0], edges[i][1]);
        }
        
        for (int i = 1; i < n; i += 1) {
            if (u.query(i) != u.query(0)) {
                return false;
            }
        }
        return true;
    }
}

class Union {
    private int[] father;
    
    public Union(int n) {
        father = new int[n];
        for (int i = 0; i < n; i += 1) {
            father[i] = i;
        }
    }
    
    public void union(int x, int y) {
        father[query(x)] = query(y);
    }
    
    public int query(int x) {
        if (x == father[x]) {
            return father[x];
        } else {
            father[x] = query(father[x]);
            return father[x];
        }
    }
}
