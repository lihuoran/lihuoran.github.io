/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/remove-nth-node-from-end-of-list
@Language: Java
@Datetime: 15-05-07 11:21
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The first node of linked list.
     * @param n: An integer.
     * @return: The head of linked list.
     */
    ListNode removeNthFromEnd( ListNode head , int n )
    {
        // write your code here
        int tot = 0;
        ListNode pt = head;
        while( pt != null )
        {
            tot ++;
            pt = pt.next;
        }
        
        int idx = 0;
        ListNode ret = null;
        ListNode tail = null;
        pt = head;
        while( pt != null )
        {
            if( idx != tot - n )
            {
                if( ret == null )
                {
                    ret = new ListNode( pt.val );
                    tail = ret;
                }
                else
                {
                    tail.next = new ListNode( pt.val );
                    tail = tail.next;
                }
            }
            idx ++;
            pt = pt.next;
        }
        
        return ret;
    }
}

