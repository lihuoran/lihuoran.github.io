# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/fast-power
@Language: Python
@Datetime: 15-08-03 10:48
'''

class Solution:
    """
    @param a, b, n: 32bit integers
    @return: An integer
    """
    def fastPower(self, a, b, n):
        # write your code here
        if b == 1:
            return 0
            
        t = [a % b]
        for i in range( 31 ):
            c = t[-1]
            t.append( ( c * c ) % b )
        ret = 1
        base = 4294967296
        for i in range( 32 ):
            j = 31 - i
            base /= 2
            if n >= base:
                n -= base
                ret = ( ret * t[j] ) % b;
        return ret