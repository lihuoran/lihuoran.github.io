/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/paint-house
@Language: Java
@Datetime: 16-03-27 08:48
*/

public class Solution {
	public int minCost(int[][] costs) {
		// Write your code here
		try {
			int n = costs.length;
			int[][] f = new int[n][3];
			
			for (int i = 0; i < n; i += 1) {
				for (int j = 0; j < 3; j += 1) {
					if (i == 0) {
						f[i][j] = costs[i][j];
					} else {
						f[i][j] = Integer.MAX_VALUE;
						for (int k = 0; k < 3; k += 1) {
							if (k != j) {
								f[i][j] = Math.min(f[i][j], f[i - 1][k]);
							}
						}
						f[i][j] += costs[i][j];
					}
				}
			}
			
			return Math.min(f[n - 1][0], Math.min(f[n - 1][1], f[n - 1][2]));
		} catch (Exception e) {
			return 0;
		}
	}

	private int col2num(char c) {
		switch (c) {
		case 'r':
			return 0;
		case 'b':
			return 1;
		default:
			return 2;
		}
	}
}