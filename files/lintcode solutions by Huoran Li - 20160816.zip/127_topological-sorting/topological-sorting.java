/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/topological-sorting
@Language: Java
@Datetime: 15-08-09 02:04
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) { label = x; neighbors = new ArrayList<DirectedGraphNode>(); }
 * };
 */
public class Solution
{
    /**
     * @param graph: A list of Directed graph node
     * @return: Any topological order for the given graph.
     */    
    public ArrayList<DirectedGraphNode> topSort( ArrayList<DirectedGraphNode> graph )
    {
        // write your code here
        int n = graph.size();
        ArrayList<DirectedGraphNode> ret = new ArrayList<DirectedGraphNode>();
        if( n == 0 ) return ret;
        
        HashMap<DirectedGraphNode,Integer> imap = new HashMap<DirectedGraphNode,Integer>();
        for( int i = 0 ; i < n ; i ++ )
            imap.put( graph.get( i ) , i );
            
        int[] cnt = new int[n];
        boolean[] mark = new boolean[n];
        for( int i = 0 ; i < n ; i ++ )
        {
            cnt[i] = 0;
            mark[i] = false;
        }
            
        for( int i = 0 ; i < n ; i ++ )
        {
            int k = graph.get( i ).neighbors.size();
            for( int j = 0 ; j < k ; j ++ )
            {
                DirectedGraphNode cur = graph.get( i ).neighbors.get( j );
                cnt[imap.get( cur )] ++;
            }
        }
        
        for( int i = 0 ; i < n ; i ++ )
        {
            for( int j = 0 ; j < n ; j ++ )
            {
                DirectedGraphNode cur = graph.get( j );
                if( cnt[imap.get( cur )] != 0 || mark[imap.get( cur )] == true ) continue;
                ret.add( cur );
                mark[imap.get( cur )] = true;
                for( DirectedGraphNode e : cur.neighbors )
                    cnt[imap.get( e )] --;
            }
        }
        
        return ret;
    }
}
