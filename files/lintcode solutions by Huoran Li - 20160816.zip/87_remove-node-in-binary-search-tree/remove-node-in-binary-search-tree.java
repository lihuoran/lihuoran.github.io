/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/remove-node-in-binary-search-tree
@Language: Java
@Datetime: 15-08-08 10:40
*/

public class Solution
{
    /**
     * @param root: The root of the binary search tree.
     * @param value: Remove the node with given value.
     * @return: The root of the binary search tree after removal.
     */
    public TreeNode removeNode( TreeNode root , int value )
    {
        // write your code here
    	TreeNode f = findNode( root , value );
    	if( f == null ) return root;
    	
    	TreeNode fakeroot = new TreeNode( -1 );
    	fakeroot.left = root;
    	
    	fakeroot.left = delete( fakeroot.left , f );
    	
    	return fakeroot.left;
    }
    
    private TreeNode delete( TreeNode node , TreeNode f )
    {
    	if( node == f )
    	{
    		if( node.left == null ) return node.right;
    		if( node.right == null ) return node.left;
    		
    		TreeNode p = null , q = null;
    		TreeNode t = null;
    		TreeNode ret;
    		ret = node.left;
    		p = node.left;
    		q = node.right;
    		t = p.right;
    		p.right = q;
    		while( t != null )
    		{
    			if( q == p.right )
    			{
    				p = q.left;
    				q.left = t;
    				TreeNode temp = p ; p = q ; q = t ; t = temp ;
    			}
    			else
    			{
    				p = q.right;
    				q.right = t;
    				TreeNode temp = p ; p = q ; q = t ; t = temp ;
    			}
    		}
    		return ret;
    	}
    	
    	if( node.val == -1 || node.val > f.val )
    	{
    		node.left = delete( node.left , f );
    		return node;
    	}
    	else
    	{
    		node.right = delete( node.right , f );
    		return node;
    	}
    }
    
    private TreeNode findNode( TreeNode root , int value )
    {
    	if( root == null ) return null;
    	if( value == root.val ) return root;
    	if( value < root.val ) return findNode( root.left , value );
    	return findNode( root.right , value );
    }
}
