/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sort-colors-ii
@Language: Java
@Datetime: 15-11-14 15:19
*/

class Solution {
    /**
     * @param colors: A list of integer
     * @param k: An integer
     * @return: nothing
     */
    public void sortColors2(int[] colors, int k) {
        // write your code here
        qsort(colors, 0, colors.length - 1);
    }
    
    private void qsort(int[] a, int l, int r) {
    	if (l >= r) {
    		return;
    	}
    	
    	int x = par(a, l, r);
    	qsort(a, l, x - 1);
    	qsort(a, x + 1, r);
    }
    
    private int par(int[] a, int l, int r) {
    	int t = l;
    	int temp;
    	for (int i = l + 1; i <= r; i += 1) {
    		if (a[i] < a[l]) {
    			t += 1;
    			temp = a[i];
    			a[i] = a[t];
    			a[t] = temp;
    		}
    	}
    	temp = a[t];
    	a[t] = a[l];
    	a[l] = temp;
    	
    	return t;
    }
}