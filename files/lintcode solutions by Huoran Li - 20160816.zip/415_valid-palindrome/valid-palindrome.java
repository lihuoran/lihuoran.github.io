/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/valid-palindrome
@Language: Java
@Datetime: 15-06-09 05:22
*/

public class Solution
{
    /**
     * @param s A string
     * @return Whether the string is a valid palindrome
     */
    public boolean isPalindrome( String s )
    {
        // Write your code here
        int n = s.length();
        String t = "";
        for( int i = 0 ; i < n ; i ++ )
        {
            char c = s.charAt( i );
            if( c >= 'A' && c <= 'Z' )
                t += ( char )( c - ( 'A' - 'a' ) );
            else if( c >= 'a' && c <= 'z' || c >= '0' && c <= '9' )
                t += c;
        }
        s = t;
        n = s.length();
        
        for( int i = 0 , j = n - 1 ; i < j ; i ++ , j -- )
            if( s.charAt( i ) != s.charAt( j ) ) return false;
        return true;
    }
}
