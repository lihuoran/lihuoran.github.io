/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/flatten-nested-list-iterator
@Language: Java
@Datetime: 16-04-15 15:09
*/

/**
 * // This is the interface that allows for creating nested lists.
 * // You should not implement it, or speculate about its implementation
 * public interface NestedInteger {
 *
 *     // @return true if this NestedInteger holds a single integer,
 *     // rather than a nested list.
 *     public boolean isInteger();
 *
 *     // @return the single integer that this NestedInteger holds,
 *     // if it holds a single integer
 *     // Return null if this NestedInteger holds a nested list
 *     public Integer getInteger();
 *
 *     // @return the nested list that this NestedInteger holds,
 *     // if it holds a nested list
 *     // Return null if this NestedInteger holds a single integer
 *     public List<NestedInteger> getList();
 * }
 */
import java.util.Iterator;

public class NestedIterator implements Iterator<Integer> {

    private ArrayList<Integer> data;
    private int t;

    public NestedIterator(List<NestedInteger> nestedList) {
        // Initialize your data structure here.
        data = convert(nestedList);
        t = 0;
    }
    
    private ArrayList<Integer> convert(List<NestedInteger> nestedList) {
        ArrayList<Integer> ret = new ArrayList<Integer>();
        ArrayList<NestedInteger> cur = (ArrayList<NestedInteger>) nestedList;
        for (int i = 0; i < cur.size(); i += 1) {
            if (cur.get(i).isInteger()) {
                ret.add(cur.get(i).getInteger());
            } else {
                ArrayList<Integer> temp = convert(cur.get(i).getList());
                for (int j = 0; j < temp.size(); j += 1) {
                    ret.add(temp.get(j));
                }
            }
        }
        return ret;
    }

    // @return {int} the next element in the iteration
    @Override
    public Integer next() {
        // Write your code here
        Integer ret = data.get(t);
        t += 1;
        return ret;
    }

    // @return {boolean} true if the iteration has more element or false
    @Override
    public boolean hasNext() {
        // Write your code here
        return (t < data.size());
    }

    @Override
    public void remove() {}
}

/**
 * Your NestedIterator object will be instantiated and called as such:
 * NestedIterator i = new NestedIterator(nestedList);
 * while (i.hasNext()) v.add(i.next());
 */