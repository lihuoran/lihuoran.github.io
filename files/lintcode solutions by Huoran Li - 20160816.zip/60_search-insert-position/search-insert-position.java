/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-insert-position
@Language: Java
@Datetime: 15-06-07 06:24
*/


public class Solution
{
    /** 
     * param A : an integer sorted array
     * param target :  an integer to be inserted
     * return : an integer
     */
    public int searchInsert( int[] A , int target )
    {
        // write your code here
    	int[] a = A;
    	int n = a.length;
    	int t = target;
    	
    	if( n == 0 ) return 0;
    	if( t > a[n - 1] ) return n;
    	if( t < a[0] ) return 0;
    	
    	int l = 0 , r = n - 1;
    	while( ( r - l ) >= 5 )
    	{
    		int m = ( r + l ) / 2;
    		if( t == a[m] ) return m;
    		if( t < a[m] ) r = m;
    		else l = m;
    	}
    	
    	for( int i = l ; i <= r ; i ++ )
    		if( t <= a[i] ) return i;
    	
    	return -1;
    }
}