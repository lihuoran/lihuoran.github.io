/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/interval-sum
@Language: Java
@Datetime: 15-05-21 08:29
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */
public class Solution
{
    /**
     *@param A, queries: Given an integer array and an query list
     *@return: The result list
     */
    private int[] a;

    public ArrayList<Long> intervalSum( int[] A , ArrayList<Interval> queries )
    {
        // warite your code here
        a = A;
        int n = a.length;

        Node root = buildtree( 0 , n - 1 );
        ArrayList<Long> ret = new ArrayList<Long>();
        for( Interval itv : queries )
        		ret.add( query( root , itv.start , itv.end ) );

        return ret;
    }

    private long query( Node cur , int l , int r )
    {
    	if( cur.l == l && cur.r == r ) return cur.sum;

    	int m = ( cur.l + cur.r ) / 2;
    	if( r <= m ) return query( cur.lson , l , r );
    	else if( l > m ) return query( cur.rson , l , r );
    	else return query( cur.lson , l , m ) + query( cur.rson , m + 1 , r );
    }

    private Node buildtree( int l , int r )
    {
    	Node root = new Node( l , r );
    	if( l == r )
    	{
    		root.sum = a[l];
    	}
    	else
    	{
    		int m = ( l + r ) / 2;
    		root.lson = buildtree( l , m );
    		root.rson = buildtree( m + 1 , r );
    		root.sum = root.lson.sum + root.rson.sum;
    	}

    	return root;
    }
}

class Node
{
	public int l , r;
	public Node lson , rson;
	public long sum;

	public Node( int l , int r )
	{
		this.l = l;
		this.r = r;
		lson = null;
		rson = null;
		sum = 0;
	}
}

















