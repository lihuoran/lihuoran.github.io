/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/single-number-iii
@Language: Java
@Datetime: 15-11-16 05:02
*/

public class Solution {
    /**
     * @param A : An integer array
     * @return : Two integers
     */
    public List<Integer> singleNumberIII(int[] A) {
        // write your code here
        int[] a = A;
        int n = a.length;
        
        int acc = 0;
        for (int i = 0; i < n; i += 1) {
            acc ^= a[i];
        }
        
        int val = 1;
        while ((val & acc) == 0) {
            val <<= 1;
        }
        
        int x = 0, y = 0;
        for (int i = 0; i < n; i += 1) {
            if ((a[i] & val) == 0) {
                x ^= a[i];
            } else {
                y ^= a[i];
            }
        }
        
        ArrayList<Integer> ret = new ArrayList<Integer>();
        ret.add(x);
        ret.add(y);
        return ret;
    }
}
