/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/fibonacci
@Language: Java
@Datetime: 15-05-24 03:03
*/

class Solution {
    /**
     * @param n: an integer
     * @return an integer f(n)
     */
    public int fibonacci(int n)
    {
        if( n == 1 ) return 0;
        if( n == 2 ) return 1;
        
        // write your code here
        int[] a = new int[n + 1];
        a[1] = 0;
        a[2] = 1;
        
        for( int i = 3 ; i <= n ; i ++ )
            a[i] = a[i - 1] + a[i - 2];
        return a[n];
    }
}


