/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/edit-distance
@Language: Java
@Datetime: 15-08-30 06:21
*/

public class Solution {
    /**
     * @param word1 & word2: Two string.
     * @return: The minimum number of steps.
     */
    public int minDistance(String word1, String word2) {
        // write your code here
        String a1 = '^' + word1;
        String a2 = '^' + word2;
        int n1 = a1.length();
        int n2 = a2.length();
        
        int[][] f = new int[n1][n2];
        for( int i = 0 ; i < n1 ; i ++ )
        for( int j = 0 ; j < n2 ; j ++ )
        {
            if( i == 0 || j == 0 )
                f[i][j] = i + j;
            else
            {
                char c1 = a1.charAt( i );
                char c2 = a2.charAt( j );
                if( c1 == c2 )
                    f[i][j] = f[i - 1][j - 1];
                else
                    f[i][j] = min( f[i - 1][j] , f[i][j - 1] , f[i - 1][j - 1] ) + 1;
            }
        }
        
        return f[n1 - 1][n2 - 1];
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
    
    private int min( int a , int b , int c )
    {
        return min( min( a , b ) , c );
    }
}
