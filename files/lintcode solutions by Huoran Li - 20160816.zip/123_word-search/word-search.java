/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/word-search
@Language: Java
@Datetime: 15-11-14 15:42
*/

public class Solution {
	/**
	 * @param board:
	 *            A list of lists of character
	 * @param word:
	 *            A string
	 * @return: A boolean
	 */
	private int r;
	private int c;
	private char[][] b;
	private boolean[][] mark;

	public boolean exist(char[][] board, String word) {
		// write your code here
		b = board;
		r = b.length;
		c = b[0].length;
		mark = new boolean[r][c];
		for (int i = 0; i < r; i += 1) {
			for (int j = 0; j < c; j += 1) {
				mark[i][j] = false;
			}
		}

		for (int i = 0; i < r; i += 1) {
			for (int j = 0; j < c; j += 1) {
				if (find(i, j, word)) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean find(int x, int y, String word) {
		if (word.length() == 0) {
			return true;
		}
		if (word.charAt(0) != b[x][y] || mark[x][y]) {
			return false;
		}
		
		mark[x][y] = true;
		if (x > 0 && find(x - 1, y, word.substring(1))) {
			return true;
		}
		if (x < r - 1 && find(x + 1, y, word.substring(1))) {
			return true;
		}
		if (y > 0 && find(x, y - 1, word.substring(1))) {
			return true;
		}
		if (y < c - 1 && find(x, y + 1, word.substring(1))) {
			return true;
		}
		mark[x][y] = false;
		return false;
	}
}