# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/largest-number
@Language: Python
@Datetime: 15-08-06 03:26
'''

import re

class Solution:	
    #@param num: A list of non negative integers
    #@return: A string
    def largestNumber( self , num ):
    	num.sort( self.cmp )
    	ret = ''
    	for e in num:
    		ret += '%d' % e

    	p = re.compile( '^0+' )
    	ret = p.sub( '' , ret )
    	if ret == '':
    		ret = '0'
    	return ret

    def cmp( self , a , b ):
    	a = str( a )
    	b = str( b )
    	n = min( len( a ) , len( b ) )
    	for i in range( n ):
    		if a[i] > b[i]:
    			return -1
    		if a[i] < b[i]:
    			return 1
    	if len( a ) > len( b ):
    		if a[n] > a[0]:
    			return -1
    		return 1
    	if len( a ) < len( b ):
    		if b[n] > a[0]:
    			return 1
    		return -1
    	return 0

