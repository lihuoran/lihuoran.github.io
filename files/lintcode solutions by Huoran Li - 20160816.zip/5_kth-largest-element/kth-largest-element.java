/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/kth-largest-element
@Language: Java
@Datetime: 16-02-06 12:33
*/

class Solution {
    /*
     * @param k : description of k
     * @param nums : array of nums
     * @return: description of return
     */
    public int kthLargestElement(int k, int[] nums) {
        // write your code here
        return find(k, nums, 0, nums.length - 1);
    }
    
    private int find(int k, int[] nums, int l, int r) {
		// Find kth number in nums[l] ~ nums[r]
		int idx = partition(nums, l, r);
		if (k == idx - l + 1) {
			return nums[idx];
		} else if (k < idx - l + 1) {
			return find(k, nums, l, idx - 1);
		} else {
			return find(k - (idx - l + 1), nums, idx + 1, r);
		}
	}

	private int partition(int[] nums, int l, int r) {
		/*
		 * Re-arrange the array and then return an index
		 * After the function returned, the array should be like this:
		 * 		nums[l ... t - 1] <= nums[t]
		 * 		nums[t + 1 ... r] >= nums[t]
		 *
		 * Just like what quick sort does
		 */
		int t = l;
		for (int i = l + 1; i <= r; i += 1) {
			if (nums[i] > nums[l]) {
				t += 1;
				swap(nums, t, i);
			}
		}
		swap(nums, t, l);

		return t;
	}

	private void swap(int[] nums, int a, int b) {
		// swap two elements in nums
		int temp = nums[a];
		nums[a] = nums[b];
		nums[b] = temp;
	}
};