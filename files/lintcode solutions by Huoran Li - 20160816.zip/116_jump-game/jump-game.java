/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/jump-game
@Language: Java
@Datetime: 15-05-11 16:29
*/

public class Solution
{
    /**
     * @param A: A list of integers
     * @return: The boolean answer
     */
    public boolean canJump( int[] A )
    {
        // wirte your code here
        int n = A.length;
        if( n == 0 ) return true;
        
        int p = 0;
        for( int i = 0 ; i < n ; i ++ )
            if( i <= p )
                p = max( p , i + A[i] );
            else break;
        if( p >= n - 1 ) return true;
        return false;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}

