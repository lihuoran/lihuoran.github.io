/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/expression-evaluation
@Language: Java
@Datetime: 15-11-14 06:10
*/

public class Solution {
	public int evaluateExpression(String[] expression) {
		// write your code here
		Stack<Integer> snum = new Stack<Integer>();
		Stack<Character> sopr = new Stack<Character>();
		String[] e = expression;
		int n = e.length;

		for (int i = 0; i < n; i += 1) {
			String s = e[i];
			if (isNum(s)) {
				snum.push(Integer.parseInt(s));
			} else {
				char c = s.charAt(0);
				if (c == '(') {
					sopr.push(c);
				} else if (c == ')') {
					while (sopr.peek() != '(') {
						char opr = sopr.pop();
						int b = snum.pop();
						int a = snum.pop();
						snum.push(calc(a, b, opr));
					}
					sopr.pop();
				} else {
					while(!sopr.isEmpty() && sopr.peek() != '(' && priority(sopr.peek()) >= priority(c)) {
						char opr = sopr.pop();
						int b = snum.pop();
						int a = snum.pop();
						snum.push(calc(a, b, opr));
					}
					sopr.push(c);
				}
			}
		}
		
		while(!sopr.isEmpty()) {
			char opr = sopr.pop();
			int b = snum.pop();
			int a = snum.pop();
			snum.push(calc(a, b, opr));
		}

		if (snum.isEmpty()) {
			return 0;
		} else {
			return snum.pop();
		}
	}

	private int calc(int a, int b, char opr) {
		switch (opr) {
		case '+':
			return a + b;
		case '-':
			return a - b;
		case '*':
			return a * b;
		case '/':
			return a / b;
		default:
			return -1;
		}
	}

	private int priority(char c) {
		if (c == '+' || c == '-') {
			return 1;
		} else if (c == '*' || c == '/') {
			return 2;
		}
		return -1;
	}

	private boolean isNum(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
};