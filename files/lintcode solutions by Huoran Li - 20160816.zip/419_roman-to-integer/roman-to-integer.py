# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/roman-to-integer
@Language: Python
@Datetime: 15-11-30 01:33
'''

class Solution:
	# @param {string} s Roman representation
	# @return {int} an integer
	def romanToInt(self, s):
		# Write your code here
		m = {}
		m['I'] = 1
		m['X'] = 10
		m['C'] = 100
		m['M'] = 1000
		m['V'] = 5
		m['L'] = 50
		m['D'] = 500
		
		n = len(s)
		
		arr = []
		cur = -1
		for i in range(n):
			if cur == -1:
				cur = m[s[i]]
			else:
				if s[i] == s[i - 1]:
					cur += m[s[i]]
				else:
					arr.append(cur)
					cur = m[s[i]]
		arr.append(cur)
		
		ret = 0
		t = 0
		n = len(arr)
		while t < n:
			if t == n - 1:
				ret += arr[t]
				t += 1
			else:
				if arr[t] < arr[t + 1]:
					ret += arr[t + 1] - arr[t]
					t += 2
				else:
					ret += arr[t]
					t += 1
		return ret