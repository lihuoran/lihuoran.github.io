# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/happy-number
@Language: Python
@Datetime: 15-12-12 05:01
'''

class Solution:
    # @param {int} n an integer
    # @return {boolean} true if this is a happy number or false
    def convert(self, n):
        ret = 0
        while n != 0:
            bit = n % 10
            ret += bit * bit
            n /= 10
        return ret
    
    def isHappy(self, n):
        # Write your code here
        if n == 1:
            return True
        s = set([])
        s.add(n)
        
        while True:
            n = self.convert(n)
            if n in s:
                return False
            if n == 1:
                return True
            s.add(n)