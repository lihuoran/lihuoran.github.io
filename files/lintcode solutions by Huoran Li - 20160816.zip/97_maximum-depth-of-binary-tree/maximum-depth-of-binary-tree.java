/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-depth-of-binary-tree
@Language: Java
@Datetime: 15-05-06 02:23
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param root: The root of binary tree.
     * @return: An integer.
     */
    public int maxDepth( TreeNode root )
    {
        // write your code here
        return calc( root );
    }
    
    private int calc( TreeNode root )
    {
        if( root == null ) return 0;
        int a = calc( root.left );
        int b = calc( root.right );
        return max( a , b ) + 1;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
