/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/digit-counts
@Language: Java
@Datetime: 16-02-06 12:03
*/

class Solution {
    /*
     * param k : As description.
     * param n : As description.
     * return: An integer denote the count of digit k in 1..n
     */
    public int digitCounts(int k, int n) {
        // write your code here
    	int cnt = 0;
    	for (int i = 0; i <= n; i += 1) {
    		cnt += extract(i, k);
    	}
    	
    	return cnt;
    }
    
    private int extract(int num, int k) {
    	// calculate the count of digit [k] in an integer [num]
    	if (num == 0) {
    		if (k == 0) {
    			return 1;
    		} else {
    			return 0;
    		}
    	}
    	
    	int cnt = 0;
    	while (num != 0) {
    		if (k == num % 10) {
    			cnt += 1;
    		}
    		num /= 10;
    	}
    	
    	return cnt;
    }
};