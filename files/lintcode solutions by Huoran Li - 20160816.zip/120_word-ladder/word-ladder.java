/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/word-ladder
@Language: Java
@Datetime: 15-08-08 11:01
*/

public class Solution
{
    /**
      * @param start, a string
      * @param end, a string
      * @param dict, a set of string
      * @return an integer
      */
    private HashSet<String> repo;
    private ArrayList<String> wordlist;
    private int[] ans;
    private int n;
	
	public int ladderLength( String start , String end , Set<String> dict )
    {
        // write your code here
		repo = ( HashSet<String> ) dict;
		new HashMap<String,Integer>();
		wordlist = new ArrayList<String>();
		
		wordlist.add( start );
		wordlist.add( end );
		Iterator<String> iter = repo.iterator();
		while( iter.hasNext() )
		{
			String temp = iter.next();
			wordlist.add( temp );
		}
		
		n = wordlist.size();
		ans = new int[n];
		for( int i = 0 ; i < n ; i ++ )
			ans[i] = -1;
		ans[0] = 0;
		
		LinkedList<Integer> q = new LinkedList<Integer>();
		HashSet<Integer> set = new HashSet<Integer>();
		q.add( 0 );
		set.add( 0 );
		while( !q.isEmpty() )
		{
			int cur = q.poll();
			set.remove( cur );
			for( int i = 0 ; i < n ; i ++ )
			{
				int d = calcDist( wordlist.get( cur ) , wordlist.get( i ) );
				if( d == -1 ) continue;
				if( ans[i] == -1 || ans[cur] + d < ans[i] )
				{
					ans[i] = ans[cur] + d;
					if( !set.contains( i ) )
					{
						q.add( i );
						set.add( i );
					}
				}
			}
		}
		
    	return ans[1] + 1;
    }
	
	private int calcDist( String a , String b )
	{
		if( a.equals( b ) ) return 0;
		if( a.length() != b.length() ) return -1;
		int n = a.length();
		int cnt = 0;
		for( int i = 0 ; i < n ; i ++ )
			if( a.charAt( i ) != b.charAt( i ) ) cnt ++;
		if( cnt == 1 ) return 1;
		return -1;
	}
}