# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/merge-intervals
@Language: Python
@Datetime: 15-09-08 11:45
'''



"""
Definition of Interval.
class Interval(object):
    def __init__(self, start, end):
        self.start = start
        self.end = end
"""

def cmp( a , b ):
    if a.start < b.start:
        return -1
    return 1

class Solution:
    # @param intervals, a list of Interval
    # @return a list of Interval
    def merge( self , intervals ):
        # write your code here
        a = intervals
        a.sort( cmp )
        
        if len( a ) == 0:
            return []
        
        ret = []
        cl = a[0].start
        cr = a[0].end
        for i in range( 1 , len( a ) ):
            e = a[i]
            if e.start <= cr:
                cr = max( cr , e.end )
            else:
                ret.append( [cl , cr] )
                cl = e.start
                cr = e.end
        ret.append( [cl , cr] )
        
        return ret
