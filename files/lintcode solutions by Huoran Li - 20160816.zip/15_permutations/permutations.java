/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/permutations
@Language: Java
@Datetime: 16-02-06 13:33
*/

class Solution {
    /**
     * @param nums: A list of integers.
     * @return: A list of permutations.
     */
    public ArrayList<ArrayList<Integer>> permute(ArrayList<Integer> nums) {
        // write your code here
    	if (nums == null || nums.size() == 0) {
    		return new ArrayList<ArrayList<Integer>>();
    	}
    	
    	ArrayList<ArrayList<Integer>> ret = new ArrayList<ArrayList<Integer>>();
    	int n = nums.size();
    	int[] a = new int[n];
    	for (int i = 0; i < n; i += 1) {
    		a[i] = nums.get(i);
    	}
    	Qsort.sort(a, 0, n - 1);
    	
    	do {
    		ret.add(arr2list(a));
    		next(a);
    	} while (isInOrder(a) == false);
    	
        return ret;
    }
    
    private ArrayList<Integer> arr2list(int[] a) {
    	ArrayList<Integer> list = new ArrayList<Integer>();
    	for (int i = 0; i < a.length; i += 1) {
    		list.add(a[i]);
    	}
    	return list;
    }
    
    private void next(int[] a) {
    	int idx = -1;
    	int n = a.length;
    	for (int i = n - 1; i >= 1; i -= 1) {
    		if (a[i] > a[i - 1]) {
    			idx = i - 1;
    			break;
    		}
    	}
    	
    	if (idx == -1) {
    		Qsort.sort(a, 0, n - 1);
    	} else {
    		int cur = -1;
    		for (int i = idx + 1; i < n; i += 1) {
    			if (a[i] > a[idx] && (cur == -1 || a[cur] > a[i])) {
    				cur = i;
    			}
    		}
    		Qsort.swap(a, cur, idx);
    		Qsort.sort(a, idx + 1, n - 1);
    	}
    }
    
    private boolean isInOrder(int[] a) {
    	for (int i = 0; i < a.length - 1; i += 1) {
    		if (a[i] > a[i + 1]) {
    			return false;
    		}
    	}
    	return true;
    }
}

class Qsort {
	public static void sort(int[] a, int l, int r) {
		if (l >= r) {
			return;
		}
		
		int x = partition(a, l, r);
		sort(a, l, x - 1);
		sort(a, x + 1, r);
	}
	
	public static int partition(int[] a, int l, int r) {
		int t = l;
		for (int i = l + 1; i <= r; i += 1) {
			if (a[i] < a[l]) {
				t += 1;
				swap(a, i, t);
			}
		}
		swap(a, l, t);
		return t;
	}
	
	public static void swap(int[] a, int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}
}