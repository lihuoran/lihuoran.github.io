# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/permutations
@Language: Python
@Datetime: 15-08-09 02:29
'''

class Solution:
    """
    @param nums: A list of Integers.
    @return: A list of permutations.
    """
    def permute( self , nums ):
        # write your code here
        if nums == None or len( nums ) == 0:
            return []
            
        a = list( nums )
        a.sort()
        n = len( a )
        
        ret = []
        while True:
        	ret.append( list( a ) )
        	idx = -1
        	for i in range( n - 1 , 0 , -1 ):
        		if a[i] > a[i - 1]:
        			idx = i - 1
        			break
        	if idx == -1:
        		break
        		
        	cur = -1
        	for i in range( idx + 1 , n ):
        		if a[i] <= a[idx]:
        			continue
        		if cur == -1 or a[i] < a[cur]:
        			cur = i
        	
        	temp = a[idx]
        	a[idx] = a[cur]
        	a[cur] = temp
        	
        	b = a[idx + 1:]
        	a = a[:idx + 1]
        	b.sort()
        	a.extend( b )
        
        return ret