/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/gas-station
@Language: Java
@Datetime: 15-05-05 08:05
*/

public class Solution
{
    /**
     * @param gas: an array of integers
     * @param cost: an array of integers
     * @return: an integer
     */
    public int canCompleteCircuit( int[] gas , int[] cost )
    {
        // write your code here
        int n = gas.length;
        for( int i = 0 ; i < n ; i ++ )
        {
            int cur = 0;
            boolean flag = true;
            for( int j = 0 ; j < n ; j ++ )
            {
                int pos = ( i + j ) % n;
                cur += gas[pos];
                if( cur < cost[pos] ) { flag = false ; break ; }
                cur -= cost[pos];
            }
            
            if( flag == true ) return i;
        }
        
        return -1;
    }
}
