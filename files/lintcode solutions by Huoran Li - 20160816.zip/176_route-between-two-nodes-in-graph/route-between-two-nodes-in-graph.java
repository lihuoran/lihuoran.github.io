/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/route-between-two-nodes-in-graph
@Language: Java
@Datetime: 15-05-27 07:48
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) {
 *         label = x;
 *         neighbors = new ArrayList<DirectedGraphNode>();
 *     }
 * };
 */
public class Solution {
   /**
     * @param graph: A list of Directed graph node
     * @param s: the starting Directed graph node
     * @param t: the terminal Directed graph node
     * @return: a boolean value
     */
    public boolean hasRoute(ArrayList<DirectedGraphNode> graph, 
                            DirectedGraphNode s, DirectedGraphNode t) {
        // write your code here
        HashSet<Integer> set = new HashSet<Integer>();
        LinkedList<DirectedGraphNode> q = new LinkedList<DirectedGraphNode>();
        
        q.push( s );
        set.add( s.label );
        while( q.size() > 0 )
        {
            DirectedGraphNode cur = q.poll();
            if( cur.label == t.label ) return true;
            for( DirectedGraphNode next : cur.neighbors )
            {
                if( !set.contains( next.label ) )
                {
                    set.add( next.label );
                    q.push( next );
                }
            }
        }
        return false;
    }
}
