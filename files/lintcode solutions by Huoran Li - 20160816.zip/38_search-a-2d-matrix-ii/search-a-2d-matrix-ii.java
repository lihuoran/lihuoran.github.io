/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-a-2d-matrix-ii
@Language: Java
@Datetime: 16-02-07 02:09
*/

public class Solution {
	/**
	 * @param matrix: A list of lists of integers
	 * @param: A number you want to search in the matrix
	 * @return: An integer indicate the occurrence of target in the given matrix
	 */
	public int searchMatrix(int[][] matrix, int target) {
		// write your code here
		if (matrix.length == 0) {
			return 0;
		}

		int count = 0;
		int nrow = matrix.length;
		int ncol = matrix[0].length;

		int curRow = 0;
		int curCol = ncol - 1;

		while (curRow < nrow && curCol >= 0) {
			if (matrix[curRow][curCol] > target) {
				curCol -= 1;
			} else if (matrix[curRow][curCol] < target) {
				curRow += 1;
			} else {
				count += 1;
				curCol -= 1;
			}
		}

		return count;
	}
}
