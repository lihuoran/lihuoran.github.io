/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-subarray
@Language: Java
@Datetime: 16-02-07 15:37
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: A integer indicate the sum of max subarray
     */
    public int maxSubArray(int[] nums) {
        // write your code
        int n = nums.length;
        if (n == 0) {
            return -1;
        }
        
        int ret = nums[0];
        int cur = nums[0];
        for (int i = 1; i < n; i += 1) {
            cur = (cur < 0 ? nums[i] : nums[i] + cur);
            ret = Math.max(cur, ret);
        }
        
        return ret;
    }
}