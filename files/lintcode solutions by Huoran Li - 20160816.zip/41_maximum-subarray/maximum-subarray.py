# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-subarray
@Language: Python
@Datetime: 15-08-30 06:10
'''

class Solution:
    """
    @param nums: A list of integers
    @return: An integer denote the sum of maximum subarray
    """
    def maxSubArray(self, nums):
        # write your code here
        idx = 0
        n = len( nums )
        for i in range( 1 , n ):
            if nums[idx] < nums[i]:
                idx = i
        if nums[idx] <= 0:
            return nums[idx]
        
        ret = 0
        cur = 0
        for e in nums:
            if cur < 0:
                cur = 0
            cur += e
            if cur > ret:
                ret = cur
        return ret
            
            
