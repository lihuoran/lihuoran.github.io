/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/update-bits
@Language: Java
@Datetime: 15-06-07 07:00
*/

class Solution
{
    /**
     *@param n, m: Two integer
     *@param i, j: Two bit positions
     *return: An integer
     */
    public int updateBits( int n , int m , int i , int j )
    {
        // write your code here
    	int ret = 0;
    	for( int p = 0 ; p < 32 ; p ++ )
    	{
    		if( i <= p && p <= j )
    		{
    			int c;
    			if( ( m & ( 1 << ( p - i ) ) ) == 0 ) c = 0;
    			else c = 1;
    			ret |= c << p;
    		}
    		else
    		{
    			int c;
    			if( ( n & ( 1 << p ) ) == 0 ) c = 0;
    			else c = 1;
    			ret |= c << p;
    		}
    	}
        
    		
    	return ret;
    }
}