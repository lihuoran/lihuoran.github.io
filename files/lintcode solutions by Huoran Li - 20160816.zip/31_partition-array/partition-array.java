/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/partition-array
@Language: Java
@Datetime: 16-02-06 15:55
*/

public class Solution {
    /** 
     *@param nums: The integer array you should partition
     *@param k: As description
     *return: The index after partition
     */
    public int partitionArray(int[] nums, int k) {
        //write your code here
        int n = nums.length;
        int t = -1;

        for(int i = 0 ; i < n ; i ++)
            if(nums[i] < k)
            {
                t ++;
                swap(nums, t, i);
            }
        
        return t + 1;
    }

    private void swap(int[] a, int x, int y) {
        int temp = a[x];
        a[x] = a[y];
        a[y] = temp;
    }
}
