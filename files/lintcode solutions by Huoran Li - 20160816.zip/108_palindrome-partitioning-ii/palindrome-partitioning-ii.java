/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning-ii
@Language: Java
@Datetime: 15-11-24 02:39
*/

public class Solution {
    /**
     * @param s a string
     * @return an integer
     */
    public int minCut(String s) {
        // write your code here
        int n = s.length();
        if (n <= 1) {
            return 0;
        }
        
        int[] f = new int[n];
        f[0] = 0;
        for (int i = 1; i < n; i += 1) {
            f[i] = 2147483647;
            for (int j = i - 1; j >= 0; j -= 1) {
                if (palin(s.substring(j + 1, i + 1)) == true) {
                    f[i] = min(f[i], f[j] + 1);
                }
            }
            if (palin(s.substring(0, i + 1)) == true) {
                f[i] = min(f[i], 0);
            }
        }
        
        return f[n - 1];
    }
    
    private boolean palin(String s) {
        int n = s.length();
        for (int i = 0, j = n - 1; i <= j; i += 1, j -= 1) {
            if (s.charAt(i) != s.charAt(j)) {
                return false;
            }
        }
        return true;
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
};
