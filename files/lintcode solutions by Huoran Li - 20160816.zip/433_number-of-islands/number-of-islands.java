/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/number-of-islands
@Language: Java
@Datetime: 15-06-30 03:09
*/

public class Solution
{
    /**
     * @param grid a boolean 2D matrix
     * @return an integer
     */
    private boolean[][] g;
    private int r , c;
    
    public int numIslands( boolean[][] grid )
    {
        // Write your code here
        try
        {
            g = grid;
            r = g.length;
            c = g[0].length;
            
            int ret = 0;
            for( int i = 0 ; i < r ; i ++ )
            for( int j = 0 ; j < c ; j ++ )
            {
                if( !g[i][j] ) continue;
                ret ++;
                clean( i , j );
            }
            
            return ret;
        }
        catch( Exception e )
        {
            return 0;
        }
    }
    
    private void clean( int x , int y )
    {
        if( x < 0 || x >= r ) return ;
        if( y < 0 || y >= c ) return ;
        if( !g[x][y] ) return ;
        g[x][y] = false;
        clean( x - 1 , y );
        clean( x + 1 , y );
        clean( x , y - 1 );
        clean( x , y + 1 );
    }
}
