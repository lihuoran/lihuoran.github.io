/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/burst-balloons
@Language: Java
@Datetime: 16-03-15 06:16
*/

public class Solution {
    /**
     * @param nums a list of integer
     * @return an integer, maximum coins
     */
    public int maxCoins(int[] nums) {
        // Write your code here
        int n = nums.length;
        int[] a = new int[n + 2];
        a[0] = a[n + 1] = 1;
        for (int i = 1; i <= n; i += 1) {
        	a[i] = nums[i - 1];
        }
        
        int[][] f = new int[n + 2][n + 2];
        for (int i = 2; i <= n + 1; i += 1) {
        	for (int j = 0; j + i <= n + 1; j += 1) {
        		int x = j;
        		int y = j + i;
        		if (i == 2) {
        			f[x][y] = a[x] * a[x + 1] * a[y];
        		} else {
        			f[x][y] = Integer.MIN_VALUE;
        			for (int k = x + 1; k < y; k += 1) {
        				f[x][y] = Math.max(f[x][y],
        						f[x][k] + f[k][y] + a[k] * a[x] * a[y]);
        			}
        		}
        	}
        }
        
        return f[0][n + 1];
    }
}