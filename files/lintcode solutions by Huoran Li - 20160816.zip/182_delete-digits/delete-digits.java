/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/delete-digits
@Language: Java
@Datetime: 15-05-21 11:40
*/

public class Solution
{
    /**
     *@param A: A positive integer which has N digits, A is a string.
     *@param k: Remove k digits.
     *@return: A string
     */
    public String DeleteDigits( String A , int k )
    {
        // write your code here
        String a = A;
        int n = a.length();
        
        char[] arr = new char[n + 1];
        for( int i = 0 ; i < n ; i ++ )
            arr[i] = a.charAt( i );
        int t = n;
        for( int i = 0 ; i < n && i < k ; i ++ )
        for( int j = 0 ; j < t ; j ++ )
            if( j == t - 1 || arr[j] > arr[j + 1] )
            {
                for( int p = j ; p < t - 1 ; p ++ )
                    arr[p] = arr[p + 1];
                t --;
                break;
            }
            
        String ret = new String();
        for( int i = 0 ; i < t ; i ++ )
        {
            if( ret.length() == 0 && arr[i] == '0' ) continue;
            ret += arr[i];
        }
            
        return ret;
    }
}
