/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-peak-element
@Language: Java
@Datetime: 15-06-07 06:45
*/

class Solution
{
    /**
     * @param A: An integers array.
     * @return: return any of peek positions.
     */
    public int findPeak( int[] A )
    {
        // write your code here
        int[] a = A;
        int n = a.length;
        
        int l = 0 , r = n - 1;
        while( l < r )
        {
            int m = ( l + r ) / 2;
            if( a[m] > a[m - 1] && a[m] > a[m + 1] ) return m;
            if( a[m] < a[m + 1] ) l = m;
            else r = m;
        }
        return -1;
    }
}

