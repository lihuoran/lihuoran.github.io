# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-tree-level-order-traversal-ii
@Language: Python
@Datetime: 15-09-28 07:02
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""


class Solution:
    """
    @param root: The root of binary tree.
    @return: buttom-up level order in a list of lists of integers
    """
    def levelOrderBottom(self, root):
        # write your code here
        if root == None:
            return []
        
        self.data = {}
        
        self.dfs( root , 0 )
        l = self.data.keys()
        l.sort()
        l.reverse()
        
        ret = []
        for e in l:
            ret.append( self.data[e] )
        return ret
    
    def dfs( self , node , level ):
        if node == None:
            return
        if not level in self.data:
            self.data[level] = []
        self.data[level].append( node.val )
        self.dfs( node.left , level + 1 )
        self.dfs( node.right , level + 1 )
