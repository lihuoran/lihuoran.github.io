# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/partition-array-by-odd-and-even
@Language: Python
@Datetime: 15-09-05 16:20
'''

class Solution:
    # @param nums: a list of integers
    # @return: nothing
    def partitionArray( self , nums ):
        # write your code here
        n = len( nums )
        x = 0
        y = n - 1
        while x <= y:
            while x <= y and nums[x] % 2 == 1:
                x += 1
            while x <= y and nums[y] % 2 == 0:
                y -= 1
            if x <= y:
                temp = nums[x]
                nums[x] = nums[y]
                nums[y] = temp
                
                
