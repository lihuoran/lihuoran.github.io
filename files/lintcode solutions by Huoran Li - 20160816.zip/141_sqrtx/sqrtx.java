/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sqrtx
@Language: Java
@Datetime: 15-05-05 06:48
*/

class Solution
{
    private double abs( double x )
    {
        if( x < 0 ) return x * -1.0;
        return x;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
    
    /**
     * @param x: An integer
     * @return: The sqrt of x
     */
    public int sqrt( int x )
    {
        // write your code here
        double a = 1.0;
        double b = ( double )( x );
        while( abs( a - b ) > 0.01 )
        {
            a = ( a + b ) / 2.0;
            b = ( double )( x ) / a;
        }
        
        return max( ( int )( Math.floor( a ) ) , ( int )( Math.floor( b ) ) );
    }
}
