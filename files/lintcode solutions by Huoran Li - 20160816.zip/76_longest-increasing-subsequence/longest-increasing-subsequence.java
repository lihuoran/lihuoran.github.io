/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-increasing-subsequence
@Language: Java
@Datetime: 15-09-28 06:59
*/

public class Solution {
    /**
     * @param nums: The integer array
     * @return: The length of LIS (longest increasing subsequence)
     */
    public int longestIncreasingSubsequence(int[] nums) {
        // write your code here
        int[] a = nums;
        int n = a.length;
        if( n <= 1 ) return n;
        
        int[] f = new int[n];
        int ret = -1;
        f[0] = 1;
        for( int i = 1 ; i < n ; i ++ )
        {
            f[i] = 1;
            for( int j = 0 ; j < i ; j ++ )
                if( a[j] <= a[i] )
                {
                    f[i] = max( f[i] , f[j] + 1 );
                }
            ret = max( f[i] , ret );
        }
        
        return ret;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}

