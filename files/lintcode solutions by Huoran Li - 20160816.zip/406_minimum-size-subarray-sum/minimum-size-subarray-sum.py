# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/minimum-size-subarray-sum
@Language: Python
@Datetime: 15-12-11 12:25
'''

class Solution:
  # @param {integer} s
  # @param {integer[]} nums
  # @return {integer}
  def minimumSize(self, nums, s):
    size = len(nums)
    start, end, sum = 0, 0, 0
    bestAns = size + 1
    while end < size:
      while end < size and sum < s:
        sum += nums[end]
        end += 1
      while start < end and sum >= s:
        if sum >= s:
          bestAns = min(bestAns, end - start)
        sum -= nums[start]
        start += 1
    return [-1, bestAns][bestAns <= size]