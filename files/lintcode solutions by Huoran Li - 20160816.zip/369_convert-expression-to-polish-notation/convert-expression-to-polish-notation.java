/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/convert-expression-to-polish-notation
@Language: Java
@Datetime: 15-05-12 06:09
*/

public class Solution
{
    /**
     * @param expression: A string array
     * @return: The Polish notation of this expression
     */
    private String[] e;
    private int n;
     
    public ArrayList<String> convertToPN( String[] expression )
    {
        // write your code here
        e = expression;
        n = e.length;
        return turn( 0 , n - 1 );
    }
    
    private ArrayList<String> turn( int l , int r )
    {
        ArrayList<String> ret = new ArrayList<String>();
        if( l == r )
        {
            ret.add( e[l] );
            return ret;
        }
        if( l > r )
        {
            return ret;
        }
        
        int bra = 0;
        int pos = -1;
        for( int i = l ; i <= r ; i ++ )
        {
            if( e[i].equals( "(" ) ) bra ++;
            else if( e[i].equals( ")" ) ) bra --;
            else if( level( e[i] ) != -1 && bra == 0 )
            {
                if( pos == -1 || level( e[i] ) <= level( e[pos] ) )
                    pos = i;
            }
        }
        if( pos == -1 ) return turn( l + 1 , r - 1 );
        ArrayList<String> llist = turn( l , pos - 1 );
        ArrayList<String> rlist = turn( pos + 1 , r );
        ret.add( e[pos] );
        for( String s : llist ) ret.add( s );
        for( String s : rlist ) ret.add( s );
        
        return ret;
    }
    
    private int level( String s )
    {
        if( s.equals( "+" ) ) return 1;
        if( s.equals( "-" ) ) return 1;
        if( s.equals( "*" ) ) return 2;
        if( s.equals( "/" ) ) return 2;
        return -1;
    }
}
