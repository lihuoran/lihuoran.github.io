/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-nodes-in-k-group
@Language: Java
@Datetime: 15-12-06 06:34
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @param k an integer
     * @return a ListNode
     */
    public ListNode reverseKGroup(ListNode head, int k) {
        // Write your code here
        if (check(head, k) == false) {
            return head;
        }
        
        ListNode cur = head;
        for (int i = 1; i < k; i += 1) {
            cur = cur.next;
        }
        
        
        ListNode next = reverseKGroup(cur.next, k);
        cur.next = null;
        
        head = reverse(head);
        cur = head;
        while (cur.next != null) {
            cur = cur.next;
        }
        cur.next = next;
        
        return head;
    }
    
    private ListNode reverse(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        
        ListNode ret = reverse(head.next);
        ListNode cur = ret;
        while (cur.next != null) {
            cur = cur.next;
        }
        cur.next = head;
        head.next = null;
        return ret;
    }
    
    private boolean check(ListNode head, int k) {
        int ret = 0;
        while (head != null && ret < k) {
            ret += 1;
            head = head.next;
        }
        
        return (ret >= k);
    }
}
