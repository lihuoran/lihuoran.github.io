/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-range-in-binary-search-tree
@Language: Java
@Datetime: 15-05-27 08:22
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param root: The root of the binary search tree.
     * @param k1 and k2: range k1 to k2.
     * @return: Return all keys that k1<=key<=k2 in ascending order.
     */
    private ArrayList<Integer> ret;
    private final int MMAX = 2147483647;
    private final int MMIN = -2147483648;
    
    public ArrayList<Integer> searchRange( TreeNode root , int k1 , int k2 )
    {
        // write your code here
        ret = new ArrayList<Integer>();
        if( root == null ) return ret;
        
        find( root , k1 , k2 );
        return ret;
    }
    
    private void find( TreeNode root , int k1 , int k2 )
    {
        if( root == null ) return ;
        
        if( root.val == k1 )
        {
            ret.add( root.val );
            find( root.right , MMIN , k2 );
        }
        else if( root.val == k2 )
        {
            find( root.left , k1 , MMAX );
            ret.add( root.val );
        }
        else if( root.val < k1 )
        {
            find( root.right , k1 , k2 );
        }
        else if( root.val > k2 )
        {
            find( root.left , k1 , k2 );
        }
        else
        {
            find( root.left , k1 , MMAX );
            ret.add( root.val );
            find( root.right , MMIN , k2 );
        }
    }
    
}














