/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/construct-binary-tree-from-inorder-and-postorder-traversal
@Language: Java
@Datetime: 15-11-15 07:43
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
 
 
public class Solution {
    /**
     *@param inorder : A list of integers that inorder traversal of a tree
     *@param postorder : A list of integers that postorder traversal of a tree
     *@return : Root of a tree
     */
    private HashMap<Integer, Integer> postmap;
    
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        // write your code here
        int n = inorder.length;
        if (n == 0) {
            return null;
        }
        
        postmap = new HashMap<Integer, Integer>();
        for (int i = 0; i < n; i += 1) {
            postmap.put(postorder[i], i);
        }
        
        return build(inorder, 0, n - 1);
    }
    
    private TreeNode build(int[] order, int l, int r) {
        if (l > r) {
            return null;
        }
        if (l == r) {
            return new TreeNode(order[l]);
        }
        
        int root = l;
        for (int i = l + 1; i <= r; i += 1) {
            if (postmap.get(order[i]) > postmap.get(order[root])) {
                root = i;
            }
        }
        
        TreeNode ret = new TreeNode(order[root]);
        ret.left = build(order, l, root - 1);
        ret.right = build(order, root + 1, r);
        return ret;
    }
}
