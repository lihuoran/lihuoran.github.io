/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/max-points-on-a-line
@Language: Java
@Datetime: 15-11-15 01:24
*/

public class Solution {
    /**
     * @param points an array of point
     * @return an integer
     */
    public int maxPoints(Point[] points) {
        // Write your code here
        if (points == null) {
            return 0;
        }
    	int n = points.length;
    	if (n <= 2) {
    		return n;
    	}
    	
    	int ans = 2;
    	for (int i = 0; i < n; i += 1) {
    		for (int j = i + 1; j < n; j += 1) {
    			int a = points[i].x , b = points[i].y;
    			int c = points[j].x , d = points[j].y;
    			int cur = 0;
    			if (a == c) {
    				for (int k = 0; k < n; k += 1) {
    					if (points[k].x == a) {
    						cur += 1;
    					}
    				}
    			} else {
    				double p = ((double)(b) - (double)(d)) / ((double)(a) - (double)(c));
    				double q = (double)(b) - (double)(p) * (double)(a);
    				for (int k = 0; k < n; k += 1) {
    					double x = points[k].x;
    					double y = points[k].y;
    					if (same(y, p * x + q)) {
    						cur += 1;
    					}
    				}
    			}
    			
    			ans = max(ans, cur);
    		}
    	}
    	
    	return ans;
    }
    
    private boolean same(double a, double b) {
    	double c = a - b;
    	if (c < 0) {
    		c *= -1;
    	}
    	return (c < 0.0001);
    }
    
    private int max(int a, int b) {
    	return (a > b ? a : b);
    }
}