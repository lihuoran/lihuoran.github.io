/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/number-of-airplanes-in-the-sky
@Language: Java
@Datetime: 15-05-11 12:50
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */

class Solution
{
    /**
     * @param intervals: An interval array
     * @return: Count of airplanes are in the sky.
     */
    public int countOfAirplanes( List<Interval> airplanes )
    { 
        // write your code here
    	HashSet<Integer> set = new HashSet<Integer>();
    	ArrayList<Integer> list = new ArrayList<Integer>();
    	for( Interval i : airplanes )
    	{
    		if( !set.contains( i.start ) ) { set.add( i.start ) ; list.add( i.start ) ; }
    		if( !set.contains( i.end ) ) { set.add( i.end ) ; list.add( i.end ) ; }
    	}
    	
    	int n = set.size();
    	int[] ts = new int[n];
    	for( int i = 0 ; i < n ; i ++ )
    		ts[i] = list.get( i );
    	qsort( ts , 0 , n - 1 );
    	
    	Action[] a = new Action[n];
    	for( int i = 0 ; i < n ; i ++ )
    		a[i] = new Action( ts[i] );
    	
    	HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
    	for( int i = 0 ; i < n ; i ++ )
    		map.put( a[i].time , i );
    	
    	for( Interval i : airplanes )
    	{
    		a[map.get( i.start )].up ++;
    		a[map.get( i.end )].down ++;
    	}
    	
    	int acc = 0;
    	int ans = 0;
    	for( int i = 0 ; i < n ; i ++ )
    	{
    		acc -= a[i].down;
    		acc += a[i].up;
    		if( ans < acc ) ans = acc;
    	}
    	
    	return ans;
    }
    
    private void qsort( int[] a , int l , int r )
    {
    	if( l >= r ) return ;
    	int x = partition( a , l , r );
    	qsort( a , x + 1 , r );
    	qsort( a , l , x - 1 );
    }
    
    private int partition( int[] a , int l , int r )
    {
    	int t = l;
    	int temp;
    	for( int i = l + 1 ; i <= r ; i ++ )
    		if( a[i] < a[l] )
    		{
    			t ++;
    			temp = a[t] ; a[t] = a[i] ; a[i] = temp ;
    		}
    	temp = a[t] ; a[t] = a[l] ; a[l] = temp ;
    	
    	return t;
    }
}

class Action
{
	public int time;
	public int up;
	public int down;
	
	public Action( int t )
	{
		time = t;
		up = down = 0;
	}
}
