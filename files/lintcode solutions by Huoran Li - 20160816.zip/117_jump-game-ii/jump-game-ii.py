# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/jump-game-ii
@Language: Python
@Datetime: 15-12-12 05:44
'''

class Solution:
	def jump(self, A):
		a = A
		n = len(a)
		if n <= 1:
			return 0
		
		last = -1
		cur = 0
		cnt = 0
		while cur < n - 1:
			next = cur + 1
			for i in range(last + 1, cur + 1):
				next = max(next, i + a[i])
			last = cur
			cur = next
			cnt += 1
		return cnt