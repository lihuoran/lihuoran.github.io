/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/the-smallest-difference
@Language: Java
@Datetime: 15-05-11 12:38
*/

public class Solution
{
    /**
     * @param A, B: Two integer arrays.
     * @return: Their smallest difference.
     */
    public int smallestDifference( int[] A , int[] B )
    {
        // write your code here
        int m = A.length;
        int n = B.length;
        if( m == 0 || n == 0 ) return 0;

        qsort( B , 0 , n - 1 );
        
        int ans = -1;
        for( int i = 0 ; i < m ; i ++ )
        {
        	int x = bisearch( B , A[i] );
        	if( x == -1 )
        		ans = min( ans , abs( A[i] - B[0] ) );
        	else if( x == n - 1 )
        		ans = min( ans , abs( A[i] - B[n - 1] ) );
        	else
        	{
        		int a = abs( A[i] - B[x] );
        		int b = abs( A[i] - B[x + 1] );
        		ans = min( ans , min( a , b ) );
        	}
        }

        return ans;
    }

    private int bisearch( int[] a , int val )
    {
    	int n = a.length;
    	if( val < a[0] ) return -1;
    	if( val >= a[n - 1] ) return n - 1;

    	int l = 0 , r = n - 1;
    	while( ( r - l ) >= 3 )
    	{
    		int m = ( l + r ) / 2;
    		if( val == a[m] ) return m;
    		if( val > a[m] ) l = m;
    		else r = m;
    	}

    	for( int i = l ; i < r ; i ++ )
    		if( val >= a[i] ) return i;
    	return r;
    }
    
    private int abs( int x )
    {
        return ( x < 0 ? x * -1 : x );
    }
    
    private int min( int a , int b )
    {
    	if( a == -1 ) return b;
    	if( b == -1 ) return a;
    	return ( a < b ? a : b );
    }

    private void qsort( int[] a , int l , int r )
    {
    	if( l >= r ) return ;
    	int x = partition( a , l , r );
    	qsort( a , l , x - 1 );
    	qsort( a , x + 1 , r );
    }

    private int partition( int[] a , int l , int r )
    {
    	int t = l;
    	int temp;
    	for( int i = l + 1 ; i <= r ; i ++ )
    		if( a[i] < a[l] )
    		{
    			t ++;
    			temp = a[t] ; a[t] = a[i] ; a[i] = temp;
    		}
    	temp = a[t] ; a[t] = a[l] ; a[l] = temp;

    	return t;
    }
}

