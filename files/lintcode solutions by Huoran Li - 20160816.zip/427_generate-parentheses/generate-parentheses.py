# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/generate-parentheses
@Language: Python
@Datetime: 15-12-03 05:02
'''

class Solution:
	# @param {int} n n pairs
	# @return {string[]} All combinations of well-formed parentheses
	
	def generateParenthesis(self, n):
		# Write your code here
		self.m = {}
		
		self.calc(n)
		ret = list(self.m[n])
		ret.sort(self.cmp)
		
		return ret
		
	def calc(self, n):
		if n in self.m:
			return self.m[n]
		
		ret = set([])
		if n == 0:
			ret.add('')
		else:
			for i in range(1, n):
				a = self.calc(i)
				b = self.calc(n - i)
				for p in a:
					for q in b:
						ret.add('%s%s' % (p, q))
			a = self.calc(n - 1)
			for e in a:
				ret.add('(%s)' % e)
		self.m[n] = ret
		return ret
		
	def cmp(self, a, b):
	    n = len(a)
	    for i in range(n):
	        if a[i] < b[i]:
	            return -1
	        if a[i] > b[i]:
	            return 1
	    return 0