/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-ii
@Language: Java
@Datetime: 15-11-22 07:05
*/

public class Solution {
    /**
     * @param values: an array of integers
     * @return: a boolean which equals to true if the first player will win
     */
    public boolean firstWillWin(int[] values) {
        // write your code here
        int[] v = values;
        int n = v.length;
        if (n == 0) {
            return false;
        } else if (n <= 2) {
            return true;
        }
        
        int[] s = new int[n];
        s[n - 1] = v[n - 1];
        for (int i = n - 2; i >= 0; i -= 1) {
            s[i] = v[i] + s[i + 1];
        }
        
        int[] f = new int[n];
        f[n - 1] = v[n - 1];
        f[n - 2] = v[n - 2] + v[n - 1];
        for (int i = n - 3; i >= 0; i -= 1) {
            int a, b;
            a = v[i] + (s[i + 1] - f[i + 1]);
            b = v[i] + v[i + 1] + (s[i + 2] - f[i + 2]);
            f[i] = (a > b ? a : b);
        }
        
        int x = f[0];
        int y = s[0] - f[0];
        return (x > y);
    }
}
