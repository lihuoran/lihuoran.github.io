/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-subarray-iii
@Language: Java
@Datetime: 15-12-02 01:31
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @param k: An integer denote to find k non-overlapping subarrays
     * @return: An integer denote the sum of max k non-overlapping subarrays
     */
    public int maxSubArray(ArrayList<Integer> nums, int k) {
        // write your code
        int n = nums.size();
        int[][] f = new int[n + 1][k + 1];
        
        for (int i = 0; i <= n; i += 1) {
            for (int j = 1; j <= min(i, k); j += 1) {
                if (i == 0) {
                    f[i][j] = 0;
                } else if (j == 1) {
                    f[i][j] = getOne(nums, 0, i - 1);
                } else {
                    f[i][j] = f[i - 1][j - 1] + nums.get(i - 1);
                    for (int p = i - 2; p >= j - 1; p -= 1) {
                        f[i][j] = max(f[i][j], f[p][j - 1] + getOne(nums, p, i - 1));
                    }
                }
            }
        }
        
        return f[n][k];
    }
    
    private int getOne(ArrayList<Integer> a, int l, int r) {
        int ret = a.get(l);
        int cur = a.get(l);
        for (int i = l + 1; i <= r; i += 1) {
            cur = max(cur + a.get(i), a.get(i));
            ret = max(cur, ret);
        }
        return ret;
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
}

