/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/lowest-common-ancestor
@Language: Java
@Datetime: 15-09-05 16:35
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: The root of the binary search tree.
     * @param A and B: two nodes in a Binary.
     * @return: Return the least common ancestor(LCA) of the two nodes.
     */
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode A, TreeNode B) {
        // write your code here
        if( root == null ) return null;
        if( cover( root.left , A ) && cover( root.left , B ) )
            return lowestCommonAncestor( root.left , A , B );
        if( cover( root.right , A ) && cover( root.right , B ) )
            return lowestCommonAncestor( root.right , A , B );
        return root;
    }
    
    private boolean cover( TreeNode root , TreeNode node )
    {
        if( root == null ) return false;
        if( root == node ) return true;
        return ( cover( root.left , node ) || cover( root.right , node ) );
    }
}
