/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/search-in-rotated-sorted-array
@Language: Java
@Datetime: 15-06-07 06:52
*/

public class Solution
{
    /** 
     *@param A : an integer rotated sorted array
     *@param target :  an integer to be searched
     *return : an integer
     */
    public int search( int[] A , int target )
    {
        // write your code here
        int[] a = A;
        int n = a.length;
        if( n == 0 ) return -1;
        
        int idx = findMin( a );
        int l = idx , r = l + n - 1;
        while( l <= r )
        {
            int m = ( l + r ) / 2;
            if( target == a[m % n] ) return m % n;
            if( target > a[m % n] ) l = m + 1;
            else r = m - 1;
        }
        return -1;
    }
    
    private int findMin( int[] num )
    {
        // write your code here
        int[] a = num;
        int n = a.length;
        int l = 0 , r = n - 1;
        
        if( a[l] < a[r] ) return 0;
        while( l < r - 1 )
        {
            int m = ( l + r ) / 2;
            if( a[m] < a[r] ) r = m;
            else l = m;
        }
        
        return r;
    }
}

