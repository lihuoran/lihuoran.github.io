/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximum-subarray-difference
@Language: Java
@Datetime: 15-12-11 03:43
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: An integer indicate the value of maximum difference between two
     *          Subarrays
     */
    public int maxDiffSubArrays(int[] nums) {
        // write your code
        if (nums.length <= 1) {
            return 0;
        }
        if (nums.length == 2) {
            return abs(nums[0] - nums[1]);
        }
        
        int n = nums.length;
        int[] a = nums;
        int[] b = new int[n];
        for (int i = 0; i < n; i += 1) {
            b[i] = a[i] * -1;
        }
        
        int[] lmax = new int[n];
        int[] lmin = new int[n];
        int[] rmax = new int[n];
        int[] rmin = new int[n];
        int x, y;
        
        lmax[0] = a[0];
        lmin[0] = b[0];
        x = a[0];
        y = b[0];
        for (int i = 1; i < n; i += 1) {
            x = max(x + a[i], a[i]);
            y = max(y + b[i], b[i]);
            lmax[i] = max(lmax[i - 1], x);
            lmin[i] = max(lmin[i - 1], y);
        }
        
        rmax[n - 1] = a[n - 1];
        rmin[n - 1] = b[n - 1];
        x = a[n - 1];
        y = b[n - 1];
        for (int i = n - 2; i >= 0; i -= 1) {
            x = max(x + a[i], a[i]);
            y = max(y + b[i], b[i]);
            rmax[i] = max(rmax[i + 1], x);
            rmin[i] = max(rmin[i + 1], y);
        }
        
        int ret = 0;
        for (int i = 0; i < n - 1; i += 1) {
            ret = max(ret, abs(lmax[i] - rmin[i + 1] * -1));
            ret = max(ret, abs(lmin[i] * -1 - rmax[i + 1]));
        }
        return ret;
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
    
    private int abs(int x) {
        return (x > 0 ? x : x * -1);
    }
}
