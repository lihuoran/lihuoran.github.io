# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/permutation-index
@Language: Python
@Datetime: 15-11-14 14:16
'''

class Solution:
    # @param {int[]} A an integer array
    # @return {long} a long integer
    def permutationIndex(self, A):
        # Write your code here
        n = len(A)
        a = A
        b = list(a)
        b.sort()
        
        fac = [1]
        for i in range(1, n):
            fac.append(fac[-1] * i)
            
        ret = 1
        for i in range(n):
            cnt = 0
            for j in range(n):
                if b[j] != -1:
                    cnt += 1
                if b[j] == a[i]:
                    b[j] = -1
                    break
            ret += (cnt - 1) * fac[n - i - 1]
            
        return ret
