/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/permutation-sequence
@Language: Java
@Datetime: 15-05-11 13:04
*/

class Solution
{
    /**
      * @param n: n
      * @param k: the kth permutation
      * @return: return the k-th permutation
      */
    public String getPermutation( int n , int k )
    {
    	if( k > fac( n ) ) return null;
    	
    	int[] l = new int[n + 1];
    	for( int i = 1 ; i <= n ; i ++ )
    		l[i] = i;
    	
    	String ret = "";
    	for( int i = n ; i >= 1 ; i -- )
    	{
    		int v = fac( i - 1 );
    		int p = ( k - 1 ) / v + 1;
    		
    		ret += l[p];
    		for( int j = p ; j < n ; j ++ ) l[j] = l[j + 1];
    		
    		k = ( k - 1 ) % v + 1;
    	}
    	
        return ret;
    }
    
    private int fac( int n )
    {
    	if( n <= 1 ) return 1;
    	return n * fac( n - 1 );
    }
}

