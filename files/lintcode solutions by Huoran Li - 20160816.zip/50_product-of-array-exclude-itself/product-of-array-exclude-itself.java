/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/product-of-array-exclude-itself
@Language: Java
@Datetime: 16-02-07 15:59
*/

class Solution
{
	/**
	 * @param A: Given an integers array A
	 * @return: A Long array B and B[i]= A[0] * ... * A[i-1] * A[i+1] * ... * A[n-1]
	 */
	public ArrayList<Long> productExcludeItself(ArrayList<Integer> A)
	{
		// write your code
		int n = A.size();
		ArrayList<Long> ret = new ArrayList<Long>();

		if (n == 0) {
			return ret;
		}
		if (n == 1) {
			ret.add((long) 1);
			return ret;
		}
		
		long[] a = new long[n];
		for(int i = 0; i < n; i ++)
			a[i] = A.get(i);
			
		long[] pre = new long[n];
		long[] aft = new long[n];
		pre[0] = a[0];
		for(int i = 1; i < n; i ++)
			pre[i] = a[i] * pre[i - 1];
		aft[n - 1] = a[n - 1];
		for(int i = n - 2; i >= 0; i --)
			aft[i] = a[i] * aft[i + 1];
		
		for(int i = 0; i < n; i ++)
			if(i == 0)
				ret.add(aft[i + 1]);
			else if(i == n - 1)
				ret.add(pre[i - 1]);
			else
				ret.add(pre[i - 1] * aft[i + 1]);
		return ret;
	}
}
