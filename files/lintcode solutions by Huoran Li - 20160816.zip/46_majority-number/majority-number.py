# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/majority-number
@Language: Python
@Datetime: 15-08-06 03:31
'''

class Solution:
    """
    @param nums: A list of integers
    @return: The majority number
    """
    def majorityNumber( self , nums ):
    	cnt = 0
    	x = -1
    	for e in nums:
    		if cnt == 0:
    			x = e
    			
    		if e == x:
    			cnt += 1
    		else:
    			cnt -= 1
    	return x
