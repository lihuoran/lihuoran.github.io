/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/majority-number
@Language: Java
@Datetime: 16-02-07 15:47
*/

public class Solution {
    /**
     * @param nums: a list of integers
     * @return: find a  majority number
     */
    public int majorityNumber(ArrayList<Integer> nums) {
        // write your code
        int cnt = 0;
        int val = 0;
        for (int i = 0; i < nums.size(); i += 1) {
            if (cnt == 0) {
                val = nums.get(i);
            }
            
            if (val == nums.get(i)) {
                cnt += 1;
            } else {
                cnt -= 1;
            }
        }
        
        return val;
    }
}
