/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/container-with-most-water
@Language: Java
@Datetime: 15-11-14 05:50
*/

public class Solution {
    /**
     * @param heights: an array of integers
     * @return: an integer
     */
    public int maxArea(int[] heights) {
        // write your code here
        int[] h = heights;
        int n = h.length;
        if (n == 0) {
            return 0;
        }
        
        int ans = -1;
        
        for (int i = 0; i < n; i += 1) {
            for (int j = i + 1; j < n; j ++) {
                int cur = min(h[i], h[j]) * (j - i);
                ans = max(ans, cur);
            }
        }
        
        return ans;
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
}
