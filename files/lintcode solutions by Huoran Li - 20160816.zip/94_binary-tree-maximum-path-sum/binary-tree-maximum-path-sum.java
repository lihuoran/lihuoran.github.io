/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-tree-maximum-path-sum
@Language: Java
@Datetime: 15-11-15 07:25
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: The root of binary tree.
     * @return: An integer.
     */
    private int ans;
    
    public int maxPathSum(TreeNode root) {
        // write your code here
        ans = -2147483648;
        calc(root);
        return ans;
        
    }
    
    private int calc(TreeNode root) {
        if (root == null) {
            return 0;
        }
        
        int l = calc(root.left);
        int r = calc(root.right);
        
        ans = max(ans, max(max(l, r) + root.val, root.val));
        ans = max(ans, l + r + root.val);
        return max(max(l, r) + root.val, root.val);
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
}