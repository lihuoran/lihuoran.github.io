# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/majority-number-iii
@Language: Python
@Datetime: 15-12-02 01:53
'''

class Solution:
    """
    @param nums: A list of integers
    @param k: As described
    @return: The majority number
    """
    def majorityNumber(self, nums, k):
        # write your code here
        cnt = {}
        for e in nums:
            if e in cnt:
                cnt[e] += 1
            else:
                if len(cnt) < k:
                    cnt[e] = 1
                else:
                    l = cnt.keys()
                    for t in l:
                        if cnt[t] == 1:
                            cnt.pop(t)
                        else:
                            cnt[t] -= 1
                            
        for t in cnt:
            cnt[t] = 0
        for e in nums:
            if e in cnt:
                cnt[e] += 1
        
        ret = None
        for t in cnt:
            if ret == None or cnt[t] > cnt[ret]:
                ret = t
        return ret