/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/backpack
@Language: Java
@Datetime: 15-05-06 02:25
*/

public class Solution {
    /**
     * @param m: An integer m denotes the size of a backpack
     * @param A: Given n items with size A[i]
     * @return: The maximum size
     */
    public int backPack( int m, int[] A )
    {
        // write your code here
        int[] a = A;
        int n = a.length;
        
        int[] dp = new int[m + 1];
        for( int i = 0 ; i <= m ; i ++ )
            dp[i] = 0;
            
        for( int i = 0 ; i < n ; i ++ )
        for( int j = m ; j >= a[i] ; j -- )
            dp[j] = max( dp[j] , dp[j - a[i]] + a[i] );
            
        return dp[m];
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
