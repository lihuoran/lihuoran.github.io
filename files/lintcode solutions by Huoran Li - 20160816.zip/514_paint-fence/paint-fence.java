/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/paint-fence
@Language: Java
@Datetime: 16-03-27 08:43
*/

public class Solution {
	public int numWays(int n, int k) {
		// Write your code here
		try {
			if (k == 1) {
				if (n <= 2) {
					return 1;
				}
				return 0;
			}
			
			int[][][] f = new int[n][k][k];
			int[] s = new int[n];
			for (int i = 0; i < n; i += 1) {
				s[i] = 0;
				for (int p = 0; p < k; p += 1) {
					for (int q = 0; q < k; q += 1) {
						if (i == 0) {
							s[i] = k;
							continue;
						} else if (i == 1) {
							f[i][p][q] = 1;
						} else if (i == 2) {
							if (p != q) {
								f[i][p][q] = k;
							} else {
								f[i][p][q] = k - 1;
							}
						} else {
							if (p != q) {
								f[i][p][q] = s[i - 2] - f[i - 2][p][p];
							} else {
								f[i][p][q] = s[i - 2] - f[i - 2][p][p] - f[i - 1][p][p];
							}
						}
						
						s[i] += f[i][p][q];
						// System.out.println(i + " " + p + " " + q + " " + f[i][p][q]);
					}
				}
			}
			
			return s[n - 1];
		} catch (Exception e) {
			return 0;			
		}
	}
}