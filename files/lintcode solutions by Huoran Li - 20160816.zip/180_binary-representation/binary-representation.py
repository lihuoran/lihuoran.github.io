# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-representation
@Language: Python
@Datetime: 15-08-03 11:21
'''

class Solution:
    #@param n: Given a decimal number that is passed in as a string
    #@return: A string
    def dual( self , s ):
        a = []
        for i in range( len( s ) ):
            a.append( int( s[i] ) )
        n = len( a )
        for i in range( n - 1 ):
            j = n - i - 1
            a[j] = a[j] * 2
        for i in range( n - 1 ):
            j = n - i - 1
            a[j - 1] += a[j] / 10
            a[j] = a[j] % 10
        ret = ''
        for i in range( n ):
            ret += ( '%d' % a[i] )

        m = len( ret ) - 1
        for i in range( len( ret ) ):
            if ret[i] != '0':
                m = i

        ret = ret[:m + 1]
        return ret

    def trans_a( self , n ):
        n = int( n )
        if n == 0:
            return ''
        s = self.trans_a( n / 2 )
        return s + '%d' % ( n % 2 )

    def trans_b( self , n ):
        if n == '0':
            return ''
        s = set( [] )
        n = '0' + n
        s.add( n[1:] )
        ret = ''
        cnt = 0
        while cnt < 10000:
            cnt += 1
            n = self.dual( n )
            p = n[0]
            n = '0' + n[1:]
            if n in s:
                return 'ERROR'
            else:
                s.add( n )
            ret += p
            if len( n ) == 1:
                return ret
        return 'ERROR'

    def protect( self , a ):
        if a == '':
            return '0'
        return a
    
    def binaryRepresentation(self, n):
        # write you code here
        if n.find( '.' ) == -1:
            return self.protect( self.trans_a( n ) )
        else:
            ( a , b ) = n.split( '.' )
            a = self.protect( self.trans_a( a ) )
            b = self.trans_b( b )
            if b == 'ERROR':
                return 'ERROR'
            elif b == '':
                return a
            else:
                return a + '.' + b
        pass