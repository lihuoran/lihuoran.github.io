# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/k-sum-ii
@Language: Python
@Datetime: 15-11-24 02:46
'''

class Solution:
	"""
	@param A: An integer array.
	@param k: A positive integer (k <= length(A))
	@param target: Integer
	@return a list of lists of integer 
	"""
	def kSumII(self, A, k, target):
		# write your code here

		self.a = A
		self.k = k
		self.target = target
		self.n = len(self.a)
		self.ret = []

		self.dfs(0, [])
		return self.ret

	def dfs(self, x, alr):
		if x == self.n:
			if sum(alr) == self.target and len(alr) == self.k:
				self.ret.append(alr)
			return
		
		self.dfs(x + 1, alr)
		if len(alr) < self.k and self.a[x] <= self.target - sum(alr):
			next = list(alr)
			next.append(self.a[x])
			self.dfs(x + 1, next)