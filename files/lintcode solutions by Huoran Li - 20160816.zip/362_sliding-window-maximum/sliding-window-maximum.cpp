/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sliding-window-maximum
@Language: C++
@Datetime: 15-09-06 07:45
*/

class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        vector<int> result;
        deque<int> buf;
        for (int i = 0; i < nums.size(); i++)
        {
            if (!buf.empty() && buf.front() <= i-k)
            {
                buf.pop_front();
            }

            while (!buf.empty() && nums[buf.back()] <= nums[i])
            {
                buf.pop_back();
            }

            buf.push_back(i);
        
            if (i >= k-1)
            {
                result.push_back(nums[buf.front()]);
            }
        }

        return result;
    }
};