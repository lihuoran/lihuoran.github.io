/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/add-binary
@Language: Java
@Datetime: 15-07-11 08:07
*/

public class Solution
{
    /**
     * @param a a number
     * @param b a number
     * @return the result
     */
    public String addBinary( String a , String b )
    {
        // Write your code here
        ArrayList<Integer> t = new ArrayList<Integer>();
        int p = a.length();
        int q = b.length();
        String c = ( p > q ? a : b );
        String d = ( p <= q ? a : b );
        
        for( int i = c.length() - 1 ; i >= 0 ; i -- )
            t.add( c.charAt( i ) == '1' ? 1 : 0 );
        int[] s = new int[t.size() + 1];
        for( int i = 0 ; i < t.size() ; i ++ )
            s[i] = t.get( i );
        s[t.size()] = 0;
            
        for( int i = d.length() - 1 ; i >= 0 ; i -- )
        {
            int j = d.length() - 1 - i;
            int v = ( d.charAt( i ) == '1' ? 1 : 0 );
            s[j] += v;
        }
        
        for( int i = 0 ; i < s.length - 1 ; i ++ )
        {
            s[i + 1] += s[i] / 2;
            s[i] %= 2;
        }
        
        boolean begin = false;
        String ret = new String();
        for( int i = s.length - 1 ; i >= 0 ; i -- )
        {
            if( s[i] == 0 && !begin ) continue;
            begin = true;
            ret += s[i];
        }
        
        if( ret.length() == 0 ) ret = "0";
        return ret;
    }
}
