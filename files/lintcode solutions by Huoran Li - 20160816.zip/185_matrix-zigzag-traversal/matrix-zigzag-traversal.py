# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/matrix-zigzag-traversal
@Language: Python
@Datetime: 15-11-15 06:39
'''

class Solution:
    # @param: a matrix of integers
    # @return: a list of integers
    def printZMatrix(self, matrix):
        # write your code here
        m = matrix
        r = len(m)
        c = len(m[0])
        
        ret = []
        x = 0
        y = 0
        d = 0 # 0 up, 1 down
        
        for i in range(r * c):
            ret.append(m[x][y])
            if d == 0:
                if y == c - 1:
                    x += 1
                    d = 1
                elif x == 0:
                    y += 1
                    d = 1
                else:
                    x -= 1
                    y += 1
                pass
            else:
                if x == r - 1:
                    y += 1
                    d = 0
                elif y == 0:
                    x += 1
                    d = 0
                else:
                    x += 1
                    y -= 1
                pass
        return ret
