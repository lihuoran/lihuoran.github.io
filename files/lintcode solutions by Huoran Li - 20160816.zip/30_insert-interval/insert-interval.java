/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/insert-interval
@Language: Java
@Datetime: 15-05-07 12:15
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */

class Solution
{
    /**
     * Insert newInterval into intervals.
     * @param intervals: Sorted interval list.
     * @param newInterval: A new interval.
     * @return: A new sorted interval list.
     */
    public ArrayList<Interval> insert( ArrayList<Interval> intervals , Interval newInterval )
    {
        ArrayList<Interval> result = new ArrayList<Interval>();
        // write your code here
        int n = intervals.size();
        Interval[] a = new Interval[n + 1];
        int t = 0;
        boolean mark = false;
        for( Interval i : intervals )
        {
            if( !mark && newInterval.start <= i.start )
            {
                mark = true;
                a[t ++] = new Interval( newInterval.start , newInterval.end );
            }
        	a[t ++] = new Interval( i.start , i.end );
        }
        if( !mark ) a[t ++] = new Interval( newInterval.start , newInterval.end );

        int cs , ce;
        cs = a[0].start;
        ce = a[0].end;
        for( int i = 1 ; i <= n ; i ++ )
        {
        	if( a[i].start <= ce ) ce = max( ce , a[i].end );
        	else
        	{
        		result.add( new Interval( cs , ce ) );
        		cs = a[i].start;
        		ce = a[i].end;
        	}
        }
        result.add( new Interval( cs , ce ) );


        return result;
    }

    private int max( int a , int b )
    {
    	return ( a > b ? a : b );
    }
}