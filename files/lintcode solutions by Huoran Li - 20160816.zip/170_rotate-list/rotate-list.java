/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/rotate-list
@Language: Java
@Datetime: 15-08-08 06:31
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param head: the List
     * @param k: rotate to the right k places
     * @return: the list after rotation
     */
    public ListNode rotateRight( ListNode head , int k )
    {
        // write your code here
    	if( head == null ) return null;
    	
    	int n = len( head );
    	k %= n;
    	if( k == 0 ) return head;
    	
    	ListNode p = head;
    	int cnt = 1;
    	while( cnt != n - k )
    	{
    		cnt ++;
    		p = p.next;
    	}
    	ListNode q = p.next;
    	ListNode t = q;
    	while( t.next != null ) t = t.next;
    	p.next = null;
    	t.next = head;
    	return q;
    }
    
    private int len( ListNode head )
    {
    	if( head == null ) return 0;
    	int cnt = 1;
    	while( head.next != null )
    	{
    		head = head.next;
    		cnt ++;
    	}
    	return cnt;
    }
}
