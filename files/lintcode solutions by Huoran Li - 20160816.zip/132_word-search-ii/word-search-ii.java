/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/word-search-ii
@Language: Java
@Datetime: 15-09-03 05:57
*/

public class Solution
{
    /**
     * @param board: A list of lists of character
     * @param words: A list of string
     * @return: A list of string
     */
    private char[][] b;
    private boolean[][] mark;
    private int r , c , n;
    private ArrayList<String> ret;
    private HashSet<String> set;
    private DictNode root;
    private int[] mx , my;
	
	public ArrayList<String> wordSearchII( char[][] board , ArrayList<String> words )
    {
        // write your code here
    	ret = new ArrayList<String>();
    	set = new HashSet<String>();
    	mx = new int[4];
		my = new int[4];
		mx[0] = -1 ; mx[1] = 1 ; mx[2] = 0 ; mx[3] = 0 ;
		my[0] = 0 ; my[1] = 0 ; my[2] = -1 ; my[3] = 1 ;
		
    	try
    	{
    		b = board;
	    	r = board.length;
	    	c = board[0].length;
	    	n = words.size();
	    	mark = new boolean[r][c];
	    	for( int i = 0 ; i < r ; i ++ )
	    	for( int j = 0 ; j < c ; j ++ )
	    		mark[i][j] = false;
	    	
	    	root = new DictNode( '@' );
	    	for( int i = 0 ; i < n ; i ++ )
	    	{
	    		String w = words.get( i );
	    		int len = w.length();
	    		DictNode curnode = root;
	    		for( int j = 0 ; j < len ; j ++ )
	    		{
	    			char val = w.charAt( j );
	    			if( curnode.get( val ) == null )
	    				curnode.set( val , new DictNode( val ) );
	    			curnode = curnode.get( val );
	    		}
	    		curnode.word = new String( w );
	    	}
	    	
	    	for( int i = 0 ; i < r ; i ++ )
	    	for( int j = 0 ; j < c ; j ++ )
	    	{
	    		if( root.get( b[i][j] ) != null )
	    			dfs( root.get( b[i][j] ) , i , j );
	    	}
    	}
    	catch( Exception e )
    	{
    	}
    	
    	return ret;
    }
	
	private void dfs( DictNode node , int x , int y )
	{
		mark[x][y] = true;
		
		if( node.word != null && !set.contains( node.word ) )
		{
			set.add( node.word );
			ret.add( node.word );
		}
		
		for( int i = 0 ; i < 4 ; i ++ )
		{
			int tx = x + mx[i];
			int ty = y + my[i];
			if( tx < 0 || tx >= r || ty < 0 || ty >= c ) continue;
			if( mark[tx][ty] ) continue;
			
			char val = b[tx][ty];
			if( node.get( val ) == null ) continue;
			dfs( node.get( val ) , tx , ty );
		}
		
		mark[x][y] = false;
	}
}

class DictNode
{
	private DictNode[] a;
	public char c;
	public String word;
	
	public DictNode( char val )
	{
		c = val;
		a = new DictNode[26];
		for( int i = 0 ; i < 26 ; i ++ )
			a[i] = null;
		word = null;
	}
	
	public DictNode get( char val )
	{
		return a[( int )( val - 'a' )];
	}
	
	public void set( char val , DictNode node )
	{
		a[( int )( val - 'a' )] = node;
	}
}