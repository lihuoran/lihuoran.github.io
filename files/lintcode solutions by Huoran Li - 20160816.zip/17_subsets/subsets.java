/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subsets
@Language: Java
@Datetime: 16-02-06 15:33
*/

class Solution {
	/**
	 * @param S: A set of numbers.
	 * @return: A list of lists. All valid subsets.
	 */
	public ArrayList<ArrayList<Integer>> subsets(int[] nums) {
		// write your code here
		ArrayList<ArrayList<Integer>> ret = new ArrayList<ArrayList<Integer>>();

		int n = nums.length;
		if (n == 0) {
			return ret;
		}

		Arrays.sort(nums);

		for (int t = 0; t < (1 << n); t += 1) {	// use bit operation!
			ArrayList<Integer> curSet = new ArrayList<Integer>();
			for (int i = 0; i < n; i += 1) {
				if ((t & (1 << i)) != 0) {
					curSet.add(nums[i]);
				}
			}
			ret.add(curSet);
		}

		return ret;
	}
}