# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subsets
@Language: Python
@Datetime: 15-08-09 02:35
'''

class Solution:
	"""
	@param S: The set of numbers.
	@return: A list of lists. See example.
	"""
	def subsets( self , S ):
		# write your code here
		self.m = {}
		self.s = S
		self.ret = []
		for e in self.s:
			self.m[e] = self.m.get( e , 0 ) + 1
		self.n = len( self.m )
		self.klist = self.m.keys()
		self.klist.sort()
		
		self.dfs( 0 , [] )
		
		return self.ret
	
	def dfs( self , idx , curlist ):
		if idx == self.n:
			self.ret.append( curlist )
			return
			
		val = self.klist[idx]
		amount = self.m[val]
		for i in range( amount + 1 ):
			newlist = list( curlist )
			for j in range( i ):
				newlist.append( val )
			self.dfs( idx + 1 , newlist )