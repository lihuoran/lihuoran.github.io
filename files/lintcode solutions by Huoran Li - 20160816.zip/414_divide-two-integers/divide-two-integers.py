# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/divide-two-integers
@Language: Python
@Datetime: 15-09-08 11:48
'''

class Solution:
    # @param {int} dividend the dividend
    # @param {int} divisor the divisor
    # @return {int} the result
    def divide(self, dividend, divisor):
        # Write your code here
        a = int( dividend )
        b = int( divisor )
        
        if a >= 0 and b >= 0:
            pos = 1
        elif a < 0 and b < 0:
            pos = 1
        else:
            pos = -1
            
        a = abs( a )
        b = abs( b )
        ans = a / b
        ans *= pos
        
        if ans > 2147483647 or ans < -2147483648:
            return 2147483647
        else:
            return ans
