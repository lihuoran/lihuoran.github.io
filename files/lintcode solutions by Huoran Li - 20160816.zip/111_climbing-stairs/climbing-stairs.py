# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/climbing-stairs
@Language: Python
@Datetime: 15-08-30 06:01
'''

class Solution:
    """
    @param n: An integer
    @return: An integer
    """
    def climbStairs(self, n):
        # write your code here
        a = [0]
        for i in range( 1 , n + 1 ):
            if i == 1:
                a.append( 1 )
            elif i == 2:
                a.append( 2 )
            else:
                a.append( a[-1] + a[-2] )
        return a[-1]

