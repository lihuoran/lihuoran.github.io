/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/sort-colors
@Language: Java
@Datetime: 15-11-14 15:04
*/

class Solution {
	private void show(int[] a, int p, int q, int t) {
		System.out.println("====================================");
		for (int i = 0; i < a.length; i += 1) {
			System.out.print(a[i] + " ");
		}
		System.out.println();
		
		for (int i = 0; i < p; i += 1) {
			System.out.print("  ");
		}
		System.out.println("p");
		
		for (int i = 0; i < q; i += 1) {
			System.out.print("  ");
		}
		System.out.println("q");
		
		for (int i = 0; i < t; i += 1) {
			System.out.print("  ");
		}
		System.out.println("i");
	}
	
    public void sortColors(int[] nums) {
        // write your code here
        int[] a = nums;
        int n = a.length;
        int p = 0, q = n - 1;
        
        int temp;
        for (int i = 0; i < n; i += 1) {
            while (true) {
            	// show(a, p, q, i);
            	
                if (a[i] == 1) {
                    break;
                } else if (a[i] == 0) {
                    if (p > i) {
                        break;
                    }
                    temp = a[i];
                    a[i] = a[p];
                    a[p] = temp;
                    p += 1;
                } else {
                    if (q < i) {
                        break;
                    }
                    temp = a[i];
                    a[i] = a[q];
                    a[q] = temp;
                    q -= 1;
                }
            }
        }
    }
}