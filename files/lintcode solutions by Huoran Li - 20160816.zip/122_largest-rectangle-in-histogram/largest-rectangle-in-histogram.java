/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/largest-rectangle-in-histogram
@Language: Java
@Datetime: 15-09-03 05:36
*/

public class Solution
{
    /**
     * @param height: A list of integer
     * @return: The area of largest rectangle in the histogram
     */
    public int largestRectangleArea( int[] height )
    {
        // write your code here
        int n = height.length;
        int[] h = new int[n + 2];
        int[] l = new int[n + 2];
        int[] r = new int[n + 2];
        
        for( int i = 0 ; i < n ; i ++ )
            h[i + 1] = height[i];
        h[0] = h[n + 1] = -1;
        
        l[1] = 0;
        for( int i = 2 ; i <= n ; i ++ )
        {
            l[i] = i - 1;
            while( h[l[i]] >= h[i] ) l[i] = l[l[i]];
        }
        
        r[n] = n + 1;
        for( int i = n - 1 ; i >= 1 ; i -- )
        {
            r[i] = i + 1;
            while( h[r[i]] >= h[i] ) r[i] = r[r[i]];
        }
        
        int ans = 0;
        for( int i = 1 ; i <= n ; i ++ )
            ans = max( ans , h[i] * ( r[i] - l[i] - 1 ) );
        return ans;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}

