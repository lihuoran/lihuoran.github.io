# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/spiral-matrix
@Language: Python
@Datetime: 15-12-11 13:01
'''

class Solution:
    # @param {int[][]} matrix a matrix of m x n elements
    # @return {int[]} an integer array
    def spiralOrder(self, matrix):
        # Write your code here
        ret = []
        try:
            turn = [[0, 1], [1, 0], [0, -1], [-1, 0]]
            r = len(matrix)
            c = len(matrix[0])
            
            mark = []
            for i in range(r):
                cur = []
                for i in range(c):
                    cur.append(1)
                mark.append(cur)
            
            
            
            x = 0
            y = 0
            d = 0
            for i in range(r * c - 1):
                ret.append(matrix[x][y])
                mark[x][y] = 0
                
                tx = x + turn[d][0]
                ty = y + turn[d][1]
                while (tx >= r or tx < 0 or ty >= c or ty < 0 or mark[tx][ty] == 0):
                    d = (d + 1) % 4
                    tx = x + turn[d][0]
                    ty = y + turn[d][1]
                x = tx
                y = ty
            ret.append(matrix[x][y])
        except:
            pass
        
        return ret
            