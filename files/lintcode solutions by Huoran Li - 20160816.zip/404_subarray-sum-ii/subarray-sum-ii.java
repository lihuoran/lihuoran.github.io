/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subarray-sum-ii
@Language: Java
@Datetime: 15-12-13 14:40
*/

public class Solution {
    /**
     * @param A an integer array
     * @param start an integer
     * @param end an integer
     * @return the number of possible answer
     */
    public int subarraySumII(int[] A, int start, int end) {
        // Write your code here
        int[] a = A;
        int n = a.length;
        if (n == 0) {
            return 0;
        }
        
        int[] s = new int[n];
        s[0] = a[0];
        for (int i = 1; i < n; i += 1) {
            s[i] = a[i] + s[i - 1];
        }
        
        int ret = 0;
        for (int i = 0; i < n; i += 1) {
            for (int j = i; j < n; j += 1) {
                int cur;
                if (i == 0) {
                    cur = s[j];
                } else {
                    cur = s[j] - s[i - 1];
                }
                
                if (cur >= start && cur <= end) {
                    ret += 1;
                }
            }
        }
        
        return ret;
    }
}