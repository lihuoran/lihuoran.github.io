/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-common-prefix
@Language: Java
@Datetime: 15-05-09 13:51
*/

public class Solution
{
    /**
     * @param strs: A list of strings
     * @return: The longest common prefix
     */
    public String longestCommonPrefix( String[] strs )
    {
        // write your code here
        String[] a = strs;
        int n = a.length;
        
        if( n == 0 ) return "";
        
        int m = -1;
        for( int i = 0 ; i < n ; i ++ )
            if( m == -1 || a[i].length() < m ) m = a[i].length();
        
        String ret = "";
        boolean flag = true;
        for( int i = 0 ; i < m ; i ++ )
        {
            ret += a[0].charAt( i );
            for( int j = 0 ; j < n ; j ++ )
                if( a[j].indexOf( ret ) != 0 )
                {
                    flag = false;
                    break;
                }
            if( !flag ) break;
        }
        if( !flag )
            ret = ret.substring( 0 , ret.length() - 1 );
        return ret;
    }
}
