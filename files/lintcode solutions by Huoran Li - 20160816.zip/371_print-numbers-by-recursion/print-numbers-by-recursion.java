/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/print-numbers-by-recursion
@Language: Java
@Datetime: 15-05-21 08:11
*/

public class Solution
{
    /**
     * @param n: An integer.
     * return : An array storing 1 to the largest number with n digits.
     */
    public List<Integer> numbersByRecursion( int n )
    {
        if( n == 0 ) return new ArrayList<Integer>();
        // write your code here
        ArrayList<Integer> ret = new ArrayList<Integer>();
        int s = pow( 10 , n - 1 );
        int t = pow( 10 , n );
        
        if( n != 1 )
        {
            ArrayList<Integer> temp = ( ArrayList<Integer> ) numbersByRecursion( n - 1 );
            for( int a : temp )
                ret.add( a );
        }
        for( int i = s ; i < t ; i ++ )
            ret.add( i );
        
        return ret;
    }
    
    private int pow( int a , int x )
    {
        int ret = 1;
        for( int i = 0 ; i < x ; i ++ )
            ret *= a;
        return ret;
    }
}
