/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/two-sum
@Language: Java
@Datetime: 15-05-10 16:30
*/

public class Solution
{
    /*
     * @param numbers : An array of Integer
     * @param target : target = numbers[index1] + numbers[index2]
     * @return : [index1 + 1, index2 + 1] (index1 < index2)
     */
    private int n;
    private Number[] a;

    public int[] twoSum( int[] numbers , int target )
    {
        // write your code here
        n = numbers.length;
        a = new Number[n];
        for( int i = 0 ; i < n ; i ++ )
            a[i] = new Number( i , numbers[i] );

        qsort( 0 , n - 1 );

        for( int i = 0 ; i < n && a[i].val * 2 <= target ; i ++ )
        {
            int t = target - a[i].val;
            int x = search( t );
            if( x != -1 )
            {
                int p = min( a[i].id , a[x].id );
                int q = max( a[i].id , a[x].id );
                int[] ret = new int[2];
                ret[0] = p + 1 ; ret[1] = q + 1 ;
                return ret;
            }
        }
        return null;
    }

    private int min( int p , int q )
    {
        return ( p < q ? p : q );
    }

    private int max( int p , int q )
    {
        return ( p > q ? p : q );
    }

    private int search( int t )
    {
        int l = 0 , r = n - 1;
        while( l != r )
        {
            int m = ( l + r ) / 2;
            if( t <= a[m].val ) r = m;
            else l = m + 1;
        }
        if( a[l].val == t ) return l;
        return -1;
    }

    private void qsort( int i , int j )
    {
        if( i >= j ) return ;
        int x = partition( i , j );
        qsort( i , x - 1 );
        qsort( x + 1 , j );
    }

    private int partition( int l , int r )
    {
        int t = l;
        for( int i = l + 1 ; i <= r ; i ++ )
        {
            if( a[i].val < a[l].val )
            {
                t ++;
                Number temp = new Number( a[t] ) ; a[t] = new Number( a[i] ) ; a[i] = new Number( temp ) ;
            }
        }
        Number temp = new Number( a[l] ) ; a[l] = new Number( a[t] ) ; a[t] = new Number( temp ) ;

        return t;
    }
}

class Number
{
    public int val;
    public int id;

    public Number( int i , int v )
    {
        val = v;
        id = i;
    }

    public Number( Number n )
    {
        val = n.val;
        id = n.id;
    }
}