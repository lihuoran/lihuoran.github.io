/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/remove-element
@Language: Java
@Datetime: 15-05-06 05:57
*/

public class Solution
{
    /** 
     *@param A: A list of integers
     *@param elem: An integer
     *@return: The new length after remove
     */
    public int removeElement( int[] A , int elem )
    {
        // write your code here
        int[] a = A;
        int n = a.length;
        int t = 0;
        
        for( int i = 0 ; i < n ; i ++ )
            if( a[i] != elem )
                a[t ++] = a[i];
        return t;
    }
}

