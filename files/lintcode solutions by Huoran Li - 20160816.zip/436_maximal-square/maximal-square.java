/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximal-square
@Language: Java
@Datetime: 15-07-11 07:43
*/

public class Solution
{
    /**
     * @param matrix: a matrix of 0 and 1
     * @return: an integer
     */
    private int[][] m;
    private int r , c;
    private int[][] u , d , s;
    
    public int maxSquare( int[][] matrix )
    {
        // write your code here
        try
        {
            m = matrix;
            r = m.length;
            c = m[0].length;
            
            u = new int[r][c];
            d = new int[r][c];
            s = new int[r][c];
            int ans = 0;
            for( int i = 0 ; i < r ; i ++ )
            for( int j = 0 ; j < c ; j ++ )
            {
                if( m[i][j] == 0 ) u[i][j] = d[i][j] = s[i][j] = 0;
                else
                {
                    u[i][j] = ( i == 0 ? 1 : u[i - 1][j] + 1 );
                    d[i][j] = ( j == 0 ? 1 : d[i][j - 1] + 1 );
                    
                    s[i][j] = ( i == 0 || j == 0 ? 1 : min( s[i - 1][j - 1] + 1 , u[i][j] , d[i][j] ) );
                }
                
                ans = max( ans , s[i][j] );
            }
            
            return ans * ans;
        }
        catch( Exception e )
        {
            return 0;
        }
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
    
    private int min( int a , int b , int c )
    {
        return min( a , min( b , c ) );
    }
}
