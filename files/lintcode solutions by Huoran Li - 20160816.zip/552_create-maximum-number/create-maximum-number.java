/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/create-maximum-number
@Language: Java
@Datetime: 16-07-06 08:12
*/

public class Solution {
	/**
	 * @param nums1
	 *            an integer array of length m with digits 0-9
	 * @param nums2
	 *            an integer array of length n with digits 0-9
	 * @param k
	 *            an integer and k <= m + n
	 * @return an integer array
	 */
	public int[] maxNumber(int[] nums1, int[] nums2, int k) {
		// Write your code here
		if (k == 0) {
			return new int[0];
		}
		if (nums1.length == 0) {
			return getMax(nums2, k);
		}
		if (nums2.length == 0) {
			return getMax(nums1, k);
		}
		
		int[] ret = null;
		
		for (int i = 0; i < k; i += 1) {
			int l1 = i;
			int l2 = k - i;
			if (l1 > nums1.length || l2 > nums2.length) {
				continue;
			}
			
			int[] temp1 = getMax(nums1, l1);
			int[] temp2 = getMax(nums2, l2);
			int[] res = merge(temp1, temp2);
			
			
//			show(temp1);
//			show(temp2);
//			show(res);
//			System.out.println();
			
			
			ret = update(ret, res);
		}
		
		return ret;
	}
	
	private int[] update(int[] ret, int[] res) {
		if (ret == null || cmp(ret, res) < 0) {
			return res;
		}
		return ret;
	}
	
	private int cmp(int[] a, int[] b) {
		int k = a.length;
		for (int i = 0; i < k; i += 1) {
			if (a[i] < b[i]) {
				return -1;
			}
			if (a[i] > b[i]) {
				return 1;
			}
		}
		return 0;
	}
	
	private int[] merge(int[] a, int[] b) {
		int m = a.length;
		int n = b.length;
		int k = m + n;
		int[] ret = new int[k];
		
		int p = 0, q = 0;
		
		for (int i = 0; i < k; i += 1) {
			if (p == m) {
				ret[i] = b[q];
				q += 1;
			} else if (q == n) {
				ret[i] = a[p];
				p += 1;
			} else if (a[p] < b[q]) {
				ret[i] = b[q];
				q += 1;
			} else if (a[p] > b[q]){
				ret[i] = a[p];
				p += 1;
			} else {
				int x = p, y = q;
				while (true) {
					if (x == m - 1) {
						ret[i] = b[q];
						q += 1;
						break;
					}
					if (y == n - 1) {
						ret[i] = a[p];
						p += 1;
						break;
					}
					if (a[x + 1] < b[y + 1]) {
						ret[i] = b[q];
						q += 1;
						break;
					}
					if (a[x + 1] > b[y + 1]) {
						ret[i] = a[p];
						p += 1;
						break;
					}
					x += 1;
					y += 1;
				}
			}
		}
		
		return ret;
	}
	
	private int[] getMax(int[] a, int k) {
		int n = a.length;
		int[] ret = new int[k];
		int l = n - k;
		int c = 0;
		
		for (int i = 0; i < k; i += 1) {
			int t = c;
			for (int j = c + 1; j <= c + l; j += 1) {
				if (a[j] > a[t]) {
					t = j;
				}
			}
			ret[i] = a[t];
			l -= t - c;
			c = t + 1;
		}
		
		return ret;
	}
	
	private void show(int[] a) {
		String buff = "";
		for (int i = 0; i < a.length; i += 1) {
			buff += a[i];
		}
		System.out.println(buff);
	}
}