/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/implement-trie
@Language: Java
@Datetime: 15-11-14 03:07
*/

/**
 * Your Trie object will be instantiated and called as such: Trie trie = new
 * Trie(); trie.insert("lintcode"); trie.search("lint"); will return false
 * trie.startsWith("lint"); will return true
 */
class TrieNode {
	public boolean isWord;
	public TrieNode[] son;
	public char letter;

	// Initialize your data structure here.
	public TrieNode() {
		letter = '@';
		isWord = false;
		son = new TrieNode[26];
		for (int i = 0; i < 26; i++) {
			son[i] = null;
		}
	}

	public TrieNode(char c) {
		letter = c;
		isWord = false;
		son = new TrieNode[26];
		for (int i = 0; i < 26; i++) {
			son[i] = null;
		}
	}

	public TrieNode get(char c) {
		return son[c - 'a'];
	}

	public void set(char c, TrieNode node) {
		son[c - 'a'] = node;
	}
}

public class Solution {
	private TrieNode root;

	public Solution() {
		root = new TrieNode();
	}

	// Inserts a word into the trie.
	public void insert(String word) {
		TrieNode cur = root;
		int len = word.length();
		for (int i = 0; i < len; i++) {
			char c = word.charAt(i);
			if (cur.get(c) == null) {
				cur.set(c, new TrieNode(c));
			}
			cur = cur.get(c);
		}
		cur.isWord = true;
	}

	// Returns if the word is in the trie.
	public boolean search(String word) {
		TrieNode cur = root;
		int len = word.length();
		for (int i = 0; i < len; i++) {
			char c = word.charAt(i);
			if (cur.get(c) == null)
				return false;
			cur = cur.get(c);
		}
		return cur.isWord;
	}

	// Returns if there is any word in the trie
	// that starts with the given prefix.
	public boolean startsWith(String prefix) {
		TrieNode cur = root;
		int len = prefix.length();
		for (int i = 0; i < len; i++) {
			char c = prefix.charAt(i);
			if (cur.get(c) == null)
				return false;
			cur = cur.get(c);
		}
		return true;
	}
}
