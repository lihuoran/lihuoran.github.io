/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/triangle
@Language: Java
@Datetime: 15-08-30 06:07
*/

public class Solution
{
    /**
     * @param triangle: a list of lists of integers.
     * @return: An integer, minimum path sum.
     */
    public int minimumTotal( ArrayList<ArrayList<Integer>> triangle )
    {
        // write your code here
        int n = triangle.size();
        if( n == 0 ) return 0;
        
        int[][] f = new int[n][n];
        for( int i = 0 ; i < n ; i ++ )
        for( int j = 0 ; j <= i ; j ++ )
        {
            int val = triangle.get( i ).get( j );
            if( i == 0 )
            {
                f[i][j] = val;
            }
            else if( j == 0 )
            {
                f[i][j] = f[i - 1][j] + val;
            }
            else if( i == j )
            {
                f[i][j] = f[i - 1][j - 1] + val;
            }
            else
            {
                f[i][j] = min( f[i - 1][j - 1] , f[i - 1][j] ) + val;
            }
        }
        
        int ret = -1;
        for( int i = 0 ; i < n ; i ++ )
            if( ret == -1 || ret > f[n - 1][i] )
                ret = f[n - 1][i];
        return ret;
    }
    
    private int min( int a , int b )
    {
        return ( a < b ? a : b );
    }
}

