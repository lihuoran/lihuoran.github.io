# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-substring-with-at-most-k-distinct-characters
@Language: Python
@Datetime: 15-12-11 12:32
'''

class Solution:
    # @param s : A string
    # @return : An integer
    def lengthOfLongestSubstringKDistinct(self, s, k):
        # write your code here
        if len(s) == 0 or k == 0:
            return 0
        
        m = {}
        t = 0
        ret = 1
        for i in range(len(s)):
            while not s[i] in m and len(m) >= k:
                m[s[t]] -= 1
                if m[s[t]] == 0:
                    m.pop(s[t])
                t += 1
            m[s[i]] = m.get(s[i], 0) + 1
            
            ret = max(ret, i - t + 1)
            
        return ret