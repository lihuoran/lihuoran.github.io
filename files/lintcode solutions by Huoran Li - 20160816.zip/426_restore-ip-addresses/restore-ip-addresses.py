# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/restore-ip-addresses
@Language: Python
@Datetime: 15-12-20 08:54
'''

class Solution:
    # @param {string} s the IP string
    # @return {string[]} All possible valid IP addresses
    def restoreIpAddresses(self, s):
        # Write your code here
        self.ret = []
        self.dfs([], s)
        return self.ret

    def test(self, a):
        for e in a:
            if eval(e) >= 256 or str(eval(e)) != e:
                return False
        return True
            


    def dfs(self, a, s):
        if len(a) == 4 and len(s) == 0:
            if self.test(a) == True:
                self.ret.append(self.arr2ip(a))
            return
        if len(a) == 4 and len(s) != 0:
            return
        if len(s) == 0 and len(a) != 4:
            return
        
        for i in range(min(3, len(s))):
            next = list(a)
            next.append(s[:i + 1])
            self.dfs(next, s[i + 1:])

    
    def arr2ip(self, a):
        ret = ''
        for e in a:
            ret += '%s.' % e
        return ret[:-1]