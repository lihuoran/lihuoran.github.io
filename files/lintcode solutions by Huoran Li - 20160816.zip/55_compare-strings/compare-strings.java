/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/compare-strings
@Language: Java
@Datetime: 15-05-06 02:32
*/

public class Solution
{
    /**
     * @param A : A string includes Upper Case letters
     * @param B : A string includes Upper Case letter
     * @return :  if string A contains all of the characters in B return true else return false
     */
    public boolean compareStrings( String A , String B )
    {
        // write your code here
        int[] mark = new int[26];
        for( int i = 0 ; i < 26 ; i ++ )
            mark[i] = 0;
        
        for( int i = 0 ; i < A.length() ; i ++ )
            mark[trans( A.charAt( i ) )] ++;
            
        for( int i = 0 ; i < B.length() ; i ++ )
            if( mark[trans( B.charAt( i ) )] == 0 )
                return false;
            else
                mark[trans( B.charAt( i ) )] --;
        return true;
    }
    
    private int trans( char c )
    {
        return ( int )( c - 'A' );
    }
}
