/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/min-stack
@Language: Java
@Datetime: 15-05-27 08:09
*/

public class Solution
{
    private Stack<Integer> s;
    private Stack<Integer> m;
    
    public Solution()
    {
        // do initialize if necessary
        s = new Stack<Integer>();
        m = new Stack<Integer>();
    }

    public void push( int number )
    {
        // write your code here
        s.push( number );
        if( m.empty() || m.peek() > number )
            m.push( number );
        else
            m.push( m.peek() );
    }

    public int pop()
    {
        // write your code here
        m.pop();
        return s.pop();
    }

    public int min()
    {
        // write your code here
        return m.peek();
    }
}

