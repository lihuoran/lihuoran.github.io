# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/string-to-integer-ii
@Language: Python
@Datetime: 15-09-05 16:51
'''

class Solution:
    # @param str: a string
    # @return an integer
    def atoi( self , str ):
        # write your code here
        str = str.strip()
        a = ''
        for i in range( len( str ) ):
            c = str[i]
            if ( c >= '0' and c <= '9' ) or ( c == '-' and len( a ) == 0 ) or c == '.' or ( c == '+' and len( a ) == 0 ):
                a += c
            else:
                break
        if a == '+' or a == '-':
            return 0
        if len( a ) == 0:
            return 0
        str = a
        
        if '.' in str:
            x = str.find( '.' )
            for i in range( x + 1 , len( str ) ):
                if str[i] != '0':
                    return 0
            str = str[:x]
            
        if str[0] == '-':
            a = int( str[1:] ) * -1
            if a < -2147483648:
                a = -2147483648
        else:
            a = int( str )
            if a > 2147483647:
                a = 2147483647
        return a
            
        
