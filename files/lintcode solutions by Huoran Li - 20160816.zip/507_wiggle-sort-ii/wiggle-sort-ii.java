/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/wiggle-sort-ii
@Language: Java
@Datetime: 16-03-04 06:08
*/

public class Solution {
	public void wiggleSort(int[] nums) {
		// Write your code here
		int[] a = nums;
		int n = a.length;
		if (n <= 1) {
			return;
		}

		int[] b = new int[n];
		for (int i = 0; i < n; i += 1) {
			b[i] = a[i];
		}
		qsort(b, 0, n - 1);
		
		int p = (n + 1) / 2 - 1, q = n - 1;
		for (int i = 0; i < n; i += 1) {
			if (i % 2 == 0) {
				a[i] = b[p];
				p -= 1;
			} else {
				a[i] = b[q];
				q -= 1;
			}
		}
	}
	
	private void qsort(int[] a, int l, int r) {
		if (l >= r) {
			return;
		}
		
		int x = partition(a, l, r);
		qsort(a, l, x - 1);
		qsort(a, x + 1, r);
	}
	
	private int partition(int[] a, int l, int r) {
		int t = l;
		for (int i = l + 1; i <= r; i += 1) {
			if (a[i] < a[l]) {
				t += 1;
				swap(a, t, i);
			}
		}
		swap(a, t, l);
		return t;
	}

	private void swap(int[] a, int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}
}