# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-peak-element-ii
@Language: Python
@Datetime: 15-12-13 14:53
'''

class Solution:
	def findPeakII(self, A):
		a = A
		n = len(a)
		m = len(a[0])

		l = 0
		r = n - 1
		while l <= r:
			m = (l + r) / 2
			c = self.peak(a[m])

			if a[m][c] < a[m + 1][c]:
				l = m + 1
			elif a[m][c] < a[m - 1][c]:
				r = m - 1
			else:
				return [m, c]

	def peak(self, a):
		ret = 0
		for i in range(1, len(a)):
			if a[i] > a[ret]:
				ret = i
		return ret
