/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/kth-smallest-number-in-sorted-matrix
@Language: Java
@Datetime: 15-12-03 05:40
*/

public class Solution {
    /**
     * @param matrix: a matrix of integers
     * @param k: an integer
     * @return: the kth smallest number in the matrix
     */
    private int n, m;
    private Heap heap;
    
    public int kthSmallest(int[][] matrix, int k) {
    	n = matrix.length;
        m = matrix[0].length;
        heap = new Heap(m);
        
        for (int i = 0; i < m; i += 1) {
            heap.input(new HeapNode(matrix[0][i], 0, i));
        }

        for (int i = 1; i < k; i += 1) {
            HeapNode cur = heap.pop();
            
            int r = cur.r;
            int c = cur.c;
            if (r < n - 1) {
            	heap.input(new HeapNode(matrix[r + 1][c], r + 1, c));
            } else {
            	heap.input(new HeapNode(2147483647, r + 1, c));
            }
        }
        
        return heap.pop().val;
    }
}

class Heap {
    private int size;
    private int cnt;
    private HeapNode[] a; 
    
    public void show() {
    	System.out.println("==============================");
    	for (int i = 0; i < cnt; i += 1) {
    		HeapNode cur = a[i];
    		System.out.println(cur.val + " " + cur.r + " " + cur.c);
    	}
    }
    
    public Heap(int n) {
        size = n;
        cnt = 0;
        a = new HeapNode[size];
    }
    
    public void input(HeapNode node) {
        a[cnt] = new HeapNode(node);
        cnt += 1;
        
        up(cnt - 1);
    }
    
    public HeapNode pop() {
        HeapNode ret = a[0];
        cnt -= 1;
        a[0] = new HeapNode(a[cnt]);
        
        down(0);
        return ret;
    }
    
    private void down(int x) {
        int lson = x * 2 + 1;
        int rson = x * 2 + 2;
        int son;
        if (lson >= cnt) {
            // pass
        } else {
            if (rson >= cnt || a[lson].val < a[rson].val) {
                son = lson;
            } else {
                son = rson;
            }
            
            if (a[x].val > a[son].val) {
                HeapNode temp = new HeapNode(a[x]);
                a[x] = new HeapNode(a[son]);
                a[son] = new HeapNode(temp);
                down(son);
            }
        }
    }
    
    private void up(int x) {
        if (x == 0) {
            return;
        }
        
        int father = (x - 1) / 2;
        if (a[x].val < a[father].val) {
            HeapNode temp = new HeapNode(a[x]);
            a[x] = new HeapNode(a[father]);
            a[father] = new HeapNode(temp);
            
            up(father);
        }
    }
}

class HeapNode {
    public int val;
    public int r;
    public int c;
    
    public HeapNode(int _val, int _r, int _c) {
        val = _val;
        r = _r;
        c = _c;
    }
    
    public HeapNode(HeapNode node) {
        val = node.val;
        r = node.r;
        c = node.c;
    }
}
