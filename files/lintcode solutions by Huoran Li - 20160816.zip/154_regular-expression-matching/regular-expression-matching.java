/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/regular-expression-matching
@Language: Java
@Datetime: 15-11-15 07:02
*/

public class Solution {
	private int ls, lp;
	private boolean[][] f;

	public boolean isMatch(String s, String p) {
		s = "@" + s;
		p = "@" + p;
		ls = s.length();
		lp = p.length();
		f = new boolean[ls][lp];

		for (int i = 0; i < ls; i += 1) {
			for (int j = 0; j < lp; j += 1) {
				//System.out.println(s.substring(0, i + 1) + " " + p.substring(0, j + 1));
				
				if (j == 0) {
					if (i == 0) {
						f[i][j] = true;
					} else {
						f[i][j] = false;
					}
				} else if (i == 0) {
					if (p.charAt(j) == '*' && j > 1 && f[i][j - 2]) {
						f[i][j] = true;
					} else {
						f[i][j] = false;
					}
				} else {
					switch (p.charAt(j)) {
					case '.':
						f[i][j] = f[i - 1][j - 1];
						break;
					case '*':
						if (p.charAt(j - 1) == '*' || p.charAt(j - 1) == '@') {
							f[i][j] = false;
						} else if (f[i][j - 2] == true) {
							f[i][j] = true;
						} else {
							char key = p.charAt(j - 1);
							int t = i;
							f[i][j] = false;
							while (t > 0 && (key == '.' || s.charAt(t) == key)) {
								if (f[t - 1][j - 2] == true) {
									f[i][j] = true;
									break;
								}
								t -= 1;
							}
						}

						break;
					default:
						if (s.charAt(i) == p.charAt(j)) {
							f[i][j] = f[i - 1][j - 1];
						} else {
							f[i][j] = false;
						}
					}
				}

			}
		}

		return f[ls - 1][lp - 1];
	}
}