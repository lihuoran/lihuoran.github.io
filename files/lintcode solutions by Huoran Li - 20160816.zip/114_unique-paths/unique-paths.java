/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/unique-paths
@Language: Java
@Datetime: 15-05-05 06:49
*/

public class Solution
{
    /**
     * @param n, m: positive integer (1 <= n ,m <= 100)
     * @return an integer
     */
    public int uniquePaths( int m , int n )
    {
        // write your code here 
        int[][] ans = new int[m][n];
        for( int i = 0 ; i < m ; i ++ )
        for( int j = 0 ; j < n ; j ++ )
        {
            if( i == 0 || j == 0 ) ans[i][j] = 1;
            else ans[i][j] = ans[i - 1][j] + ans[i][j - 1];
        }
        
        return ans[m - 1][n - 1];
    }
}

