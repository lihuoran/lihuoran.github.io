/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/maximal-rectangle
@Language: Java
@Datetime: 16-03-09 02:21
*/

public class Solution {
	public int maximalRectangle(boolean[][] matrix) {
		try {
			int r = matrix.length;
			int c = matrix[0].length;
			int[][] h = new int[r][c];
			for (int i = 0; i < r; i += 1) {
				for (int j = 0; j < c; j += 1) {
					if (matrix[i][j] == false) {
						h[i][j] = 0;
					} else if (i == 0) {
						h[i][j] = 1;
					} else {
						h[i][j] = h[i - 1][j] + 1;
					}
				}
			}
			
			int ret = Integer.MIN_VALUE;
			for (int i = 0; i < matrix.length; i += 1) {
				ret = Math.max(ret, calcHisto(h[i]));
			}
			return ret;
		} catch (Exception e) {
			return 0;
		}
	}
	
	private int calcHisto(int[] h) {
		int n = h.length;
		int[] a = new int[n + 2];
		a[0] = a[n + 1] = Integer.MIN_VALUE;
		for (int i = 0; i < n; i += 1) {
			a[i + 1] = h[i];
		}
		
		int[] l = new int[n + 1];
		int[] r = new int[n + 1];
		for (int i = 1; i <= n; i += 1) {
			int t = i - 1;
			while (a[i] <= a[t]) {
				t = l[t];
			}
			l[i] = t;
		}
		for (int i = n; i >= 1; i -= 1) {
			int t = i + 1;
			while (a[i] <= a[t]) {
				t = r[t];
			}
			r[i] = t;
		}
		
		int ret = Integer.MIN_VALUE;
		for (int i = 1; i <= n; i += 1) {
			ret = Math.max(ret, (r[i] - l[i] - 1) * a[i]);
		}
		
		return ret;
	} 
}