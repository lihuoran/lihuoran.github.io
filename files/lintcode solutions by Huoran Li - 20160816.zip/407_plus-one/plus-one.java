/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/plus-one
@Language: Java
@Datetime: 15-05-23 07:45
*/

public class Solution
{
    /**
     * @param digits a number represented as an array of digits
     * @return the result
     */
    public int[] plusOne( int[] digits )
    {
        // Write your code here
        int[] a = digits;
        int n = a.length;
        
        int[] s = new int[n];
        int h = 0;
        for( int i = 0 ; i < n ; i ++ ) s[i] = a[i];
        s[n - 1] ++;
        for( int i = n - 1 ; i >= 0 ; i -- )
            if( s[i] > 9 )
            {
                if( i == 0 ) h = 1;
                else s[i - 1] ++;
                s[i] -= 10;
            }
            else break;
            
        int[] ret;
        if( h == 1 )
        {
            ret = new int[n + 1];
            ret[0] = 1;
            for( int i = 1 ; i <= n ; i ++ )
                ret[i] = s[i - 1];
        }
        else
        {
            ret = new int[n];
            for( int i = 0 ; i < n ; i ++ )
                ret[i] = s[i];
        }
        return ret;
    }
}
