/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/house-robber-iii
@Language: Java
@Datetime: 16-04-28 08:40
*/

public class Solution {
	private HashMap<Integer, Integer> ans;
	private HashMap<Integer, Integer> lmap;
	private HashMap<Integer, Integer> rmap;
	
	public int houseRobber3(TreeNode root) {
	    if (root == null) {
	        return 0;
	    }
	    
		ans = new HashMap<Integer, Integer>();
		lmap = new HashMap<Integer, Integer>();
		rmap = new HashMap<Integer, Integer>();
		
		walk(root, 0);
		return calc(root, 0);
	}
	
	private int walk(TreeNode node, int no) {
		int ret = no;
		if (node.left != null) {
			lmap.put(no, ret + 1);
			ret = walk(node.left, ret + 1);
		} else {
			lmap.put(no, -1);
		}
		
		if (node.right != null) {
			rmap.put(no, ret + 1);
			ret = walk(node.right, ret + 1);
		} else {
			rmap.put(no, -1);
		}
		return ret;
	}
	
	private int calc(TreeNode node, int no) {
	    if (node == null) {
	        return 0;
	    }

		if (ans.containsKey(no) == false) {
			int ra = calc(node.left, lmap.get(no)) +
					calc(node.right, rmap.get(no));

			int rb = node.val;
			if (node.left != null) {
				rb += calc(node.left.left, lmap.get(lmap.get(no))) +
						calc(node.left.right, rmap.get(lmap.get(no)));
			}
			if (node.right != null) {
				rb += calc(node.right.left, lmap.get(rmap.get(no))) +
						calc(node.right.right, rmap.get(rmap.get(no)));
			}
			ans.put(no, Math.max(ra, rb));
		}
		return ans.get(no);
	}
}