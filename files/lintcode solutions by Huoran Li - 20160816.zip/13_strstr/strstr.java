/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/strstr
@Language: Java
@Datetime: 15-05-07 11:48
*/

class Solution
{
    /**
     * Returns a index to the first occurrence of target in source,
     * or -1  if target is not part of source.
     * @param source string to be scanned.
     * @param target string containing the sequence of characters to match.
     */
    public int strStr( String source , String target )
    {
        //write your code here
    	if( source == null || target == null ) return -1;
    	
    	int n = target.length();
    	if( n == 0 ) return 0;
    	
    	int[] p = new int[n];
    	int t = -1;
    	p[0] = -1;
    	for( int i = 1 ; i < n ; i ++ )
    	{
    		while( t > -1 && target.charAt( t + 1 ) != target.charAt( i ) )
    			t = p[t];
    		if( target.charAt( t + 1 ) == target.charAt( i ) )
    			t ++;
    		p[i] = t;
    	}
    	
    	t = -1;
    	int m = source.length();
    	for( int i = 0 ; i < m ; i ++ )
    	{
    		while( t > -1 && target.charAt( t + 1 ) != source.charAt( i ) )
    			t = p[t];
    		if( target.charAt( t + 1 ) == source.charAt( i ) )
    			t ++;
    		if( t == n - 1 ) return i - n + 1;
    	}
    	
        return -1;
    }
}
