/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-palindromic-substring
@Language: Java
@Datetime: 15-09-06 07:58
*/

public class Solution
{
    /**
     * @param s input string
     * @return the longest palindromic substring
     */
    public String longestPalindrome( String s )
    {
        // Write your code here
        int len = s.length();
        String ans = null;
        for( int i = 0 ; i < len ; i ++ )
        {
            int p = i;
            int q = i;
            while( p >= 0 && q < len && s.charAt( p ) == s.charAt( q ) )
            {
                p --;
                q ++;
            }
            
            String cur = s.substring( p + 1 , q );
            if( ans == null || cur.length() > ans.length() )
                ans = new String( cur );
        }
        for( int i = 0 ; i < len - 1 ; i ++ )
        {
            int p = i;
            int q = i + 1;
            while( p >= 0 && q < len && s.charAt( p ) == s.charAt( q ) )
            {
                p --;
                q ++;
            }
            
            String cur = s.substring( p + 1 , q );
            if( ans == null || cur.length() > ans.length() )
                ans = new String( cur );
        }
        return ans;
    }
}
