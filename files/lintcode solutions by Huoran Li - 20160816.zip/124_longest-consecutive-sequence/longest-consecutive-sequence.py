# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-consecutive-sequence
@Language: Python
@Datetime: 15-09-03 05:24
'''

class Solution:
    """
    @param num, a list of integer
    @return an integer
    """
    def longestConsecutive(self, num):
        # write your code here
        if len( num ) == 0:
            return 0
        
        s = set( num )
        ans = 1
        while len( s ) > 0:
            e = list( s )[0]
            s.remove( e )
            cur = 1
            p = e - 1
            q = e + 1
            while p in s:
                cur += 1
                s.remove( p )
                p -= 1
            while q in s:
                cur += 1
                s.remove( q )
                q += 1
            ans = max( ans , cur )
            
        return ans