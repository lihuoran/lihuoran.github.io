/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/k-sum
@Language: Java
@Datetime: 15-12-13 15:43
*/

public class Solution {
    /**
     * @param A: an integer array.
     * @param k: a positive integer (k <= length(A))
     * @param target: a integer
     * @return an integer
     */
    public int kSum(int A[], int k, int target) {
        int[][][] dp = new int[k + 1][A.length + 1][target + 1];

        for (int i = 1; i <= A.length; i++) {
            for (int j = i; j > 0; j--) {
                if (A[j - 1] <= target)
                    dp[1][i][A[j - 1]] = 1;
            }
        }

        for (int m = 2; m <= k; m++) {
            for (int n = m; n <= A.length; n++) {
                for (int l = 0; l <= target; l++) {
                    dp[m][n][l] = dp[m][n][l] + dp[m][n - 1][l];
                    if (l + A[n - 1] <= target)
                        dp[m][n][l + A[n - 1]] = dp[m][n][l + A[n - 1]] + dp[m - 1][n - 1][l];
                }
            }
        }

        return dp[k][A.length][target];
    }
}