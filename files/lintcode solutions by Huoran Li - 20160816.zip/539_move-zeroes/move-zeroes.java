/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/move-zeroes
@Language: Java
@Datetime: 16-05-30 04:37
*/

public class Solution {
    /**
     * @param nums an integer array
     * @return nothing, do this in-place
     */
    public void moveZeroes(int[] nums) {
        // Write your code here
        if (nums == null) {
            return;
        }
        
        int t = -1;
        int n = nums.length;
        for (int i = 0; i < n; i += 1) {
            if (nums[i] != 0) {
                t += 1;
                int temp = nums[t];
                nums[t] = nums[i];
                nums[i] = temp;
            }
        }
    }
}