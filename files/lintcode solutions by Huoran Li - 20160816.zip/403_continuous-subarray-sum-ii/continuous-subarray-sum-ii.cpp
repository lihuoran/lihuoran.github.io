/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/continuous-subarray-sum-ii
@Language: C++
@Datetime: 15-12-16 08:47
*/

class Solution {
public:
    /**
     * @param A an integer array
     * @return  A list of integers includes the index of 
     *          the first number and the index of the last number
     */
    vector<int> continuousSubarraySumII(vector<int>& A) {
        // Write your code here
        vector<int> result(2, 0);
        int n = A.size();
        if(n < 2) return result;
        
        vector<int> posMax(n, 0), posMaxIdx(n, 0), posMin(n, 0), posMinIdx(n, 0);
        posMax[0] = A[0];
        posMin[0] = A[0];
        posMaxIdx[0] = 0;
        posMinIdx[0] = 0;
        int sum = A[0], maxVal = A[0], minVal = A[0], 
            maxL = 0, maxR = 0, minL = 0, minR = 0;
    
        for(int i = 1;i < n;++i){
            sum += A[i];
            //max subArray
            if(posMax[i - 1] > 0){
                posMax[i] = posMax[i - 1] + A[i];
                posMaxIdx[i] = posMaxIdx[i - 1];
            }else{
                posMax[i] = A[i];
                posMaxIdx[i] = i;
            }
            //min subArray
            if(posMin[i - 1] < 0){
                posMin[i] = posMin[i - 1] + A[i];
                posMinIdx[i] = posMinIdx[i - 1];
            }else{
                posMin[i] = A[i];
                posMinIdx[i] = i;
            }
            
            if(posMax[i] > maxVal){
                maxVal = posMax[i];
                maxL = posMaxIdx[i];
                maxR = i;
            }
            if(posMin[i] < minVal){
                minVal = posMin[i];
                minL = posMinIdx[i];
                minR = i;
            }
        }
        
        int val = sum - minVal;
        if(val <= maxVal || (minL == 0 && minR == n - 1)){
            result[0] = maxL;
            result[1] = maxR;
        }else{
            result[0] = minR + 1;
            result[1] = minL - 1;
        }
        
        return result;
    }
};