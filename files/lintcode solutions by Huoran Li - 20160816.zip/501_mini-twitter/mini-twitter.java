/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/mini-twitter
@Language: Java
@Datetime: 16-04-24 13:42
*/

public class MiniTwitter {

	private int tweet_counter;
	private ArrayList<Tweet> tlist;
	private HashMap<Integer, HashSet<Integer>> fmap;
	
    public MiniTwitter() {
        // initialize your data structure here.
    	tweet_counter = 0;
    	tlist = new ArrayList<Tweet>();
    	fmap = new HashMap<Integer, HashSet<Integer>>();
    }

    // @param user_id an integer
    // @param tweet a string
    // return a tweet
    public Tweet postTweet(int user_id, String tweet_text) {
        //  Write your code here
    	Tweet newt = Tweet.create(user_id, tweet_text);
    	tweet_counter += 1;
    	newt.id = tweet_counter;
    	
    	tlist.add(newt);
    	return newt;
    }

    // @param user_id an integer
    // return a list of 10 new feeds recently
    // and sort by timeline
    public List<Tweet> getNewsFeed(int user_id) {
        // Write your code here
    	ArrayList<Tweet> ret = new ArrayList<Tweet>();
    	for (int i = tlist.size() - 1; i >= 0 && ret.size() < 10; i -= 1) {
    		if (tlist.get(i).user_id == user_id ||
    				(fmap.containsKey(user_id) &&
    				fmap.get(user_id).contains(tlist.get(i).user_id))) {
    			ret.add(tlist.get(i));
    		}
    	}
    	return ret;
    }
        
    // @param user_id an integer
    // return a list of 10 new posts recently
    // and sort by timeline
    public List<Tweet> getTimeline(int user_id) {
        // Write your code here
    	ArrayList<Tweet> ret = new ArrayList<Tweet>();
    	for (int i = tlist.size() - 1; i >= 0 && ret.size() < 10; i -= 1) {
    		if (tlist.get(i).user_id == user_id) {
    			ret.add(tlist.get(i));
    		}
    	}
    	return ret;
    }

    // @param from_user_id an integer
    // @param to_user_id an integer
    // from user_id follows to_user_id
    public void follow(int from_user_id, int to_user_id) {
        // Write your code here
    	if (fmap.containsKey(from_user_id) == false) {
    		fmap.put(from_user_id, new HashSet<Integer>());
    	}
    	fmap.get(from_user_id).add(to_user_id);
    }

    // @param from_user_id an integer
    // @param to_user_id an integer
    // from user_id unfollows to_user_id
    public void unfollow(int from_user_id, int to_user_id) {
        // Write your code here
    	fmap.get(from_user_id).remove(to_user_id);
    }
}