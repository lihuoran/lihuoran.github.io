/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/evaluate-reverse-polish-notation
@Language: Java
@Datetime: 15-06-09 05:50
*/

public class Solution
{
    /**
     * @param tokens The Reverse Polish Notation
     * @return the value
     */
    public int evalRPN( String[] tokens )
    {
        // Write your code here
        Stack<Integer> s = new Stack<Integer>();
        int n = tokens.length;
        
        for( int i = 0 ; i < n ; i ++ )
        {
            String t = tokens[i];
            if( isOpr( t ) )
            {
                int b = s.pop();
                int a = s.pop();
                s.push( calc( a , b , t ) );
            }
            else
            {
                s.push( Integer.parseInt( t ) );
            }
        }
        
        return s.pop();
    }
    
    private int calc( int a , int b , String t )
    {
        if( t.equals( "+" ) ) return a + b;
        if( t.equals( "-" ) ) return a - b;
        if( t.equals( "*" ) ) return a * b;
        if( t.equals( "/" ) ) return a / b;
        return -1;
    }
    
    private boolean isOpr( String t )
    {
        if( t.equals( "+" ) ) return true;
        if( t.equals( "-" ) ) return true;
        if( t.equals( "*" ) ) return true;
        if( t.equals( "/" ) ) return true;
        return false;
    }
}
