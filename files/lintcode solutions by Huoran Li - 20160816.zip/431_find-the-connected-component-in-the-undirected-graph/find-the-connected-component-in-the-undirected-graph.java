/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-the-connected-component-in-the-undirected-graph
@Language: Java
@Datetime: 15-07-23 02:10
*/


/**
 * Definition for Undirected graph.
 * class UndirectedGraphNode {
 *     int label;
 *     ArrayList<UndirectedGraphNode> neighbors;
 *     UndirectedGraphNode(int x) { label = x; neighbors = new ArrayList<UndirectedGraphNode>(); }
 * };
 */
public class Solution
{
    /**
     * @param nodes a array of Undirected graph node
     * @return a connected set of a Undirected graph
     */
    private HashSet<Integer> set;
    private ArrayList<List<Integer>> ret;
    private ArrayList<UndirectedGraphNode> data;

    private void dfs( ArrayList<Integer> curlist , UndirectedGraphNode e )
    {
    	if( set.contains( e.label ) ) return ;
    	set.add( e.label );
    	curlist.add( e.label );
    	for( UndirectedGraphNode v : e.neighbors )
    		dfs( curlist , v );
    }

    public List<List<Integer>> connectedSet( ArrayList<UndirectedGraphNode> nodes )
    {
        // Write your code here
    	set = new HashSet<Integer>();
    	ret = new ArrayList<List<Integer>>();
    	data = nodes;

        for( UndirectedGraphNode e : data )
        {
        	if( set.contains( e.label ) ) continue;
        	ArrayList<Integer> curlist = new ArrayList<Integer>();
        	dfs( curlist , e );
        	
        	Collections.sort( curlist , new SortByVal() );
        	
        	ret.add( curlist );
        }

        return ret;
    }
}

class SortByVal implements Comparator<Integer>
{
	public int compare( Integer o1 , Integer o2 )
	{
		if( o1 < o2 ) return -1;
		if( o1 > o2 ) return 1;
		return 0;
	}
}


