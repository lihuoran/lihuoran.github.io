/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/surrounded-regions
@Language: Java
@Datetime: 15-11-22 06:59
*/

public class Solution {
    /**
     * @param board a 2D board containing 'X' and 'O'
     * @return void
     */
    private char[][] b;
    private int r;
    private int c;
    
    public void surroundedRegions(char[][] board) {
        // Write your code here
        try {
            r = board.length;
            c = board[0].length;
            b = board;
            
            for (int i = 0; i < c; i += 1) {
                sur(0, i);
                sur(r - 1, i);
            }
            for (int i = 0; i < r; i += 1) {
                sur(i, 0);
                sur(i, c - 1);
            }
            
            for (int i = 0; i < r; i += 1) {
                for (int j = 0; j < c; j += 1) {
                    if (b[i][j] == '@') {
                        b[i][j] = 'O';
                    } else if (b[i][j] == 'O') {
                        b[i][j] = 'X';
                    }
                }
            }
        } catch (Exception e) {
        }
    }
    
    private void sur(int x, int y) {
        if (x < 0 || x >= r || y < 0 || y >= c) {
            return;
        }
        if (b[x][y] != 'O') {
            return;
        }
        
        b[x][y] = '@';
        sur(x - 1, y);
        sur(x + 1, y);
        sur(x, y - 1);
        sur(x, y + 1);
    }
}
