/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/submatrix-sum
@Language: Java
@Datetime: 15-11-15 01:33
*/

public class Solution {
    /**
     * @param matrix an integer matrix
     * @return the coordinate of the left-up and right-down number
     */
    public int[][] submatrixSum(int[][] matrix) {
        // Write your code here
        int[][] m = matrix;
        int r = m.length;
        int c = m[0].length;
        int[][] msum = new int[r][c];
        int[][] rsum = new int[r][c];
        
        for (int i = 0; i < r; i += 1) {
            for (int j = 0; j < c; j += 1) {
                if (j == 0) {
                    rsum[i][j] = m[i][j];
                } else {
                    rsum[i][j] = m[i][j] + rsum[i][j - 1];
                }
            }
        }
        
        for (int i = 0; i < r; i += 1) {
            for (int j = 0; j < c; j += 1) {
                if (i == 0) {
                    msum[i][j] = rsum[i][j];
                } else {
                    msum[i][j] = rsum[i][j] + msum[i - 1][j];
                }
            }
        }
        
        int[][] ans = new int[2][2];
        boolean find = false;
        for (int i = 0; i < r && !find; i += 1) {
            for (int j = 0; j < c && !find; j += 1) {
                for (int p = i; p < r && !find; p += 1) {
                    for (int q = j; q < c && !find; q += 1) {
                        int cur;
                        if (i == 0 && j == 0) {
                            cur = msum[p][q];
                        } else if (i == 0 && j != 0) {
                            cur = msum[p][q] - msum[p][j - 1];
                        } else if (i != 0 && j == 0) {
                            cur = msum[p][q] - msum[i - 1][q];
                        } else {
                            cur = msum[p][q] - msum[p][j - 1] - msum[i - 1][q] + msum[i - 1][j - 1];
                        }
                        
                        if (cur == 0) {
                            ans[0][0] = i; ans[0][1] = j;
                            ans[1][0] = p; ans[1][1] = q;
                            find = true;
                        }
                    }
                }
            }
        }
        
        return ans;
    }
}
