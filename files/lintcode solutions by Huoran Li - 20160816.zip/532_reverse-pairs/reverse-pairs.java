/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-pairs
@Language: Java
@Datetime: 16-04-23 12:56
*/

public class Solution {
	/**
	 * @param A
	 *            an array
	 * @return total of reverse pairs
	 */
	public long reversePairs(int[] A) {
		// Write your code here
		if (A == null || A.length <= 1) {
			return 0;
		}

		return calc(A, 0, A.length - 1);
	}

	public long calc(int[] a, int l, int r) {
		if (r <= l) {
			return 0;
		}

		int m = (l + r) / 2;
		long r1 = calc(a, l, m);
		long r2 = calc(a, m + 1, r);
		long ret = r1 + r2;

		int[] temp = new int[a.length];
		int p = l, q = m + 1;
		int t = l;
		while (p <= m || q <= r) {
			if (p > m) {
				temp[t] = a[q];
				q += 1;
			} else if (q > r) {
				// ret += r - m;
				temp[t] = a[p];
				p += 1;
			} else if (a[p] <= a[q]) {
				temp[t] = a[p];
				p += 1;
			} else {
				ret += m - p + 1;
				temp[t] = a[q];
				q += 1;
			}

			t += 1;
		}
		for (int i = l; i <= r; i += 1) {
			a[i] = temp[i];
		}

		// System.out.println(l + " " + r + " " + ret);
		return ret;
	}
}