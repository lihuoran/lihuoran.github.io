/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/valid-parentheses
@Language: Java
@Datetime: 15-06-09 05:29
*/

public class Solution
{
    /**
     * @param s A string
     * @return whether the string is a valid parentheses
     */
    public boolean isValidParentheses( String s )
    {
        // Write your code here
        Stack<Character> st = new Stack<Character>();
        int n = s.length();
        
        for( int i = 0 ; i < n ; i ++ )
        {
            char c = s.charAt( i );
            switch( c )
            {
            case '(':
            case '[':
            case '{':
                st.push( c );
                break;
            case ')':
            case ']':
            case '}':
                if( st.isEmpty() ) return false;
                if( !match( st.peek() , c ) ) return false;
                st.pop();
            }
        }
        return st.isEmpty();
    }
    
    private boolean match( char a , char b )
    {
        if( a == '(' && b == ')' ) return true;
        if( a == '[' && b == ']' ) return true;
        if( a == '{' && b == '}' ) return true;
        return false;
    }
}
