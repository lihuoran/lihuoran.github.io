/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock-iii
@Language: Java
@Datetime: 15-11-24 07:44
*/

class Solution {
    /**
     * @param prices: Given an integer array
     * @return: Maximum profit
     */
    private int[] p;
    private int n;
    
    public int maxProfit(int[] prices) {
        // write your code here
        n = prices.length;
        p = prices;
        
        int ret = calc(0, n - 1);
        for (int i = 1; i < n - 2; i += 1) {
            int temp = calc(0, i) + calc(i + 1, n - 1);
            ret = max(ret, temp);
        }
        
        return ret;
    }
    
    private int calc(int l, int r) {
        if (l >= r) {
            return 0;
        }
        int ret = 0;
        int low = p[l];
        for (int i = l + 1; i <= r; i += 1) {
            if (p[i] > low) {
                ret = max(ret, p[i] - low);
            }
            low = min(low, p[i]);
        }
        return ret;
    }
    
    private int max(int a, int b) {
        return (a > b ? a : b);
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
};
