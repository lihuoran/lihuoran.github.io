/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/construct-binary-tree-from-preorder-and-inorder-traversal
@Language: Java
@Datetime: 15-08-08 07:15
*/

public class Solution {
    /**
     *@param preorder : A list of integers that preorder traversal of a tree
     *@param inorder : A list of integers that inorder traversal of a tree
     *@return : Root of a tree
     */
	private HashMap<Integer,Integer> idxmap;
	private int n;
	
    public TreeNode buildTree( int[] preorder , int[] inorder )
    {
        // write your code here
    	idxmap = new HashMap<Integer,Integer>();
    	n = inorder.length;
    	for( int i = 0 ; i < n ; i ++ )
    		idxmap.put( preorder[i] , i );
    	
    	return build( inorder , 0 , n - 1 );
    }
    
    private TreeNode build( int[] in , int l , int r )
    {
    	if( l > r ) return null;
    	
    	int root = -1;
    	for( int i = l ; i <= r ; i ++ )
    	{
    		if( root == -1 || idxmap.get( in[i] ) < idxmap.get( in[root] ) )
    			root = i;
    	}
    	TreeNode ret = new TreeNode( in[root] );
    	ret.left = build( in , l , root - 1 );
    	ret.right = build( in , root + 1 , r );
    	
    	return ret;
    }
}