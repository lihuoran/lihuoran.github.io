/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/add-and-search-word
@Language: Java
@Datetime: 15-11-14 03:37
*/

public class WordDictionary {
	private class Node {
		public Node[] son;
		public boolean isWord;

		public Node() {
			isWord = false;
			son = new Node[26];
			for (int i = 0; i < 26; i++) {
				son[i] = null;
			}
		}

		public Node(char c) {
			isWord = false;
			son = new Node[26];
			for (int i = 0; i < 26; i++) {
				son[i] = null;
			}
		}

		public Node get(char c) {
			return son[c - 'a'];
		}

		public void set(char c, Node node) {
			son[c - 'a'] = node;
		}
	}

	private Node root;

	public WordDictionary() {
		root = new Node();
	}

	// Adds a word into the data structure.
	public void addWord(String word) {
		// Write your code here
		Node cur = root;
		int len = word.length();
		for (int i = 0; i < len; i++) {
			char c = word.charAt(i);
			if (cur.get(c) == null) {
				cur.set(c, new Node(c));
			}
			cur = cur.get(c);
		}
		cur.isWord = true;
	}

	// Returns if the word is in the data structure. A word could
	// contain the dot character '.' to represent any one letter.
	public boolean search(String word) {
		// Write your code here
		return find(root, word);
	}

	private boolean find(Node cur, String word) {
		if (word.length() == 0) {
			if (cur == null || cur.isWord == false) {
				return false;
			}
			return true;
		}

		char c = word.charAt(0);
		if (c == '.') {
			for (char i = 'a'; i <= 'z'; i++) {
				if (cur.get(i) != null
						&& find(cur.get(i), word.substring(1)) == true) {
					return true;
				}
			}
			return false;
		} else {
			if (cur.get(c) == null) {
				return false;
			}
			return find(cur.get(c), word.substring(1));
		}
	}
}