/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/space-replacement
@Language: C++
@Datetime: 15-09-05 16:09
*/

class Solution {
public:
    int replaceBlank(char s[], int length) {
        if(length == 0) return 0;
        int len = length;
        for(int i = 0; i < length; i++){
            if(s[i] == ' ')
                len = len + 2;
        }
        int res = len;
        s[len] = '\0';
        --len;
        for(int i = length - 1; i >= 0; i--){
            if(s[i] == ' '){
                s[len--] = '0';
                s[len--] = '2';
                s[len--] = '%';
            }
            else
                s[len--] = s[i];
        }
        return res;
    }
};