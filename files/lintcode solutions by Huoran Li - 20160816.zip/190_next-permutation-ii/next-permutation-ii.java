/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/next-permutation-ii
@Language: Java
@Datetime: 15-11-14 05:40
*/

public class Solution {
	private int partition(int[] a, int l, int r) {
		int t = l;
		int temp;
		for (int i = l + 1; i <= r; i += 1) {
			if (a[i] <= a[l]) {
				t += 1;
				temp = a[t];
				a[t] = a[i];
				a[i] = temp;
			}
		}
		temp = a[t];
		a[t] = a[l];
		a[l] = temp;

		return t;
	}

	private void qsort(int[] a, int l, int r) {
		if (l >= r) {
			return;
		}
		int p = partition(a, l, r);
		qsort(a, l, p - 1);
		qsort(a, p + 1, r);
	}

	public void nextPermutation(int[] nums) {
		// write your code here
		int n = nums.length;
		int t = n - 1;

		while (t > 0 && nums[t - 1] >= nums[t]) {
			t -= 1;
		}
		t -= 1;
		
		if (t == -1) {
			qsort(nums, 0, n - 1);
		} else {
			int idx = t + 1;
			for (int i = idx + 1; i < n; i += 1) {
				if (nums[i] > nums[t] && nums[t] < nums[idx]) {
					idx = i;
				}
			}
			int temp;
			temp = nums[t];
			nums[t] = nums[idx];
			nums[idx] = temp;
			qsort(nums, t + 1, n - 1);
		}
	}
}
