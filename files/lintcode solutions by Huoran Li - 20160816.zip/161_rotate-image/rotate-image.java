/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/rotate-image
@Language: Java
@Datetime: 15-05-11 15:46
*/

public class Solution
{
    /**
     * @param matrix: A list of lists of integers
     * @return: Void
     */
    public void rotate( int[][] matrix )
    {
        // write your code here
        try
        {
            int[][] m = matrix;
            int n = m.length;
            int[][] a = new int[n][n];
            
            for( int i = 0 ; i < n ; i ++ )
            for( int j = 0 ; j < n ; j ++ )
                a[i][j] = matrix[i][j];
            for( int i = 0 ; i < n ; i ++ )
            for( int j = 0 ; j < n ; j ++ )
                matrix[j][n - i - 1] = a[i][j];
        }
        catch( Exception e )
        {
            
        }
    }
}
