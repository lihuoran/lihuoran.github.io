/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/super-ugly-number
@Language: Java
@Datetime: 16-03-27 10:26
*/

public class Solution {
    public int nthSuperUglyNumber(int n, int[] primes) {
        // Write your code here
    	if (n == 1) {
    		return 1;
    	}
    	PriorityQueue<Integer> heap = new PriorityQueue<Integer>();
    	HashSet<Integer> set = new HashSet<Integer>();
    	
    	for (int i = 0; i < primes.length; i += 1) {
    		heap.add(primes[i]);
    	}
    	for (int r = 2; r < n; r += 1) {
    		int cur = heap.poll();
    		for (int i = 0; i < primes.length; i += 1) {
    			if ((double)(2147483647) / (double)(cur) < primes[i]) {
    				continue;
    			}
    			
    			int val = cur * primes[i];
    			if (val > 0 && !set.contains(val)) {
    				set.add(val);
    				heap.add(val);
    			}
    		}
    		// System.out.println(cur);
    	}
    	return heap.peek();
    }
}