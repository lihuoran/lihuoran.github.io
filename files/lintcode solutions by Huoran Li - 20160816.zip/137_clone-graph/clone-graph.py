# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/clone-graph
@Language: Python
@Datetime: 15-12-16 08:58
'''

# Definition for a undirected graph node
# class UndirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []
class Solution:
    # @param node, a undirected graph node
    # @return a undirected graph node
    def __init__(self):
        self.dict = {}
        self.pmap = {}
        
    def cloneGraph(self, node):
        # write your code here
        if node == None:
            return None
            
        self.bfs(node)
        
        self.retmap = {}
        for label in self.pmap:
            self.retmap[label] = UndirectedGraphNode(label)
            
        for label in self.pmap:
            for e in self.pmap[label].neighbors:
                self.retmap[label].neighbors.append(self.retmap[e.label])
        
        return self.retmap[node.label]
        
    def bfs(self, node):
        q = []
        q.append(node)
        
        self.pmap[node.label] = node
        while len(q) > 0:
            cur = q[0]
            q = q[1:]
            
            for e in cur.neighbors:
                if not e.label in self.pmap:
                    self.pmap[e.label] = e
                    q.append(e)
        
        
                    