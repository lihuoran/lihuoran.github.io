# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/valid-number
@Language: Python
@Datetime: 15-12-13 14:33
'''

class Solution:
    # @param {string} s the string that represents a number
    # @return {boolean} whether the string is a valid number
    def isNumber(self, s):
        # Write your code here
        try:
            a = float(s)
            return True
        except:
            return False