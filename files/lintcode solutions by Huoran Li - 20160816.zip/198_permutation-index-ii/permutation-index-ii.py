# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/permutation-index-ii
@Language: Python
@Datetime: 15-11-14 14:39
'''

class Solution:
	def permutationIndexII(self, A):
		n = len(A)
		a = A
		
		m = {}
		for e in a:
			m[e] = m.get(e, 0) + 1
		b = m.keys()
		b.sort()

		ret = 1
		for i in range(n):
			e = a[i]
			#print 'e:', e
			for j in range(len(b)):
				t = b[j]
				if m[t] == 0:
					continue
				if t >= e:
					break
				cur = 1
				base = n - i - 1
				for k in range(len(b)):
					val = m[b[k]]
					if b[k] == t:
						val -= 1
					cur *= self.c(base, val)
					base -= val
				ret += cur
				#print t, cur
			m[e] -= 1

		return ret

	def c(self, n, m):
		ret = 1
		for i in range(m):
			ret *= n - i
		for i in range(m):
			ret /= i + 1
		return ret