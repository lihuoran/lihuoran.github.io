/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-common-substring
@Language: Java
@Datetime: 15-05-09 13:46
*/

public class Solution
{
    /**
     * @param A, B: Two string.
     * @return: the length of the longest common substring.
     */
    public int longestCommonSubstring( String A , String B )
    {
        // write your code here
        String a = A;
        String b = B;
        int m = a.length();
        int n = b.length();
        if( m == 0 || n == 0 ) return 0;
        
        int[][] f = new int[m][n];
        int ans = 0;
        
        for( int i = 0 ; i < m ; i ++ )
        for( int j = 0 ; j < n ; j ++ )
        {
            if( a.charAt( i ) == b.charAt( j ) )
            {
                if( i == 0 || j == 0 ) f[i][j] = 1;
                else f[i][j] = f[i - 1][j - 1] + 1;
            }
            else
            {
                f[i][j] = 0;
            }
            
            ans = max( ans , f[i][j] );
        }
        
        return ans;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
