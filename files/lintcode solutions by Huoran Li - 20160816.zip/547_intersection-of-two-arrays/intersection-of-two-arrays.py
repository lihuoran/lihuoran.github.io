# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/intersection-of-two-arrays
@Language: Python
@Datetime: 16-06-20 15:15
'''

class Solution:
    # @param {int[]} nums1 an integer array
    # @param {int[]} nums2 an integer array
    # @return {int[]} an integer array
    def intersection(self, nums1, nums2):
        # Write your code here
        a = set(nums1)
        b = set(nums2)
        c = a & b
        return list(c)