/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/add-two-numbers
@Language: Java
@Datetime: 15-09-26 17:03
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;      
 *     }
 * }
 */
public class Solution {
    /**
     * @param l1: the first list
     * @param l2: the second list
     * @return: the sum list of l1 and l2 
     */
    public ListNode addLists(ListNode l1, ListNode l2) {
        // write your code here
        if( l1 == null || l2 == null ) return null;
        
        ArrayList<Integer> alist = node2list( l1 );
        ArrayList<Integer> blist = node2list( l2 );
        int la = alist.size();
        int lb = blist.size();
        ArrayList<Integer> clist = new ArrayList<Integer>();
        ArrayList<Integer> dlist = new ArrayList<Integer>();
        for( int i = la - 1 ; i >= 0 ; i -- )
            clist.add( alist.get( i ) );
        for( int i = lb - 1 ; i >= 0 ; i -- )
            dlist.add( blist.get( i ) );
        alist = clist;
        blist = dlist;
        
        int l = ( la > lb ? la : lb );
        int[] v = new int[l + 1];
        for( int i = 0 ; i < l ; i ++ )
        {
            if( i < la ) v[i] += alist.get( i );
            if( i < lb ) v[i] += blist.get( i );
        }
        for( int i = 0 ; i < l ; i ++ )
        {
            v[i + 1] += v[i] / 10;
            v[i] %= 10;
        }
        
        ListNode ret = null;
        boolean mark = false;
        for( int i = l ; i >= 0 ; i -- )
        {
            if( mark == false && v[i] == 0 )
                continue;
            mark = true;
            ListNode temp = ret;
            ret = new ListNode( v[i] );
            ret.next = temp;
        }
        if( ret == null )
        {
            ret = new ListNode( 0 );
        }
        
        return ret;
    }
    
    private ArrayList<Integer> node2list( ListNode node )
    {
        if( node == null ) return new ArrayList<Integer>();
        
        ArrayList<Integer> ret = node2list( node.next );
        ret.add( node.val );
        return ret;
    }
}
