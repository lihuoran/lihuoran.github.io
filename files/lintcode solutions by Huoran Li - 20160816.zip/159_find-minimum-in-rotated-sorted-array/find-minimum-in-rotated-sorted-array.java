/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-minimum-in-rotated-sorted-array
@Language: Java
@Datetime: 15-06-07 06:48
*/

public class Solution
{
    /**
     * @param num: a rotated sorted array
     * @return: the minimum number in the array
     */
    public int findMin( int[] num )
    {
        // write your code here
        int[] a = num;
        int n = a.length;
        int l = 0 , r = n - 1;
        
        if( a[l] < a[r] ) return a[0];
        while( l < r - 1 )
        {
            int m = ( l + r ) / 2;
            if( a[m] < a[r] )
            {
                r = m;
            }
            else
            {
                l = m;
            }
        }
        
        return a[r];
    }
}
