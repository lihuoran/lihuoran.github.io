/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/first-missing-positive
@Language: Java
@Datetime: 15-05-09 14:11
*/

public class Solution
{
    /**    
     * @param A: an array of integers
     * @return: an integer
     */
    public int firstMissingPositive( int[] a )
    {
        // write your code here    
        int n = a.length;
        if( n == 0 ) return 1;
        
        for( int t = 0 ; t < n ; )
        {
            if( a[t] <= 0 || a[t] > n || a[t] == t + 1 || a[t] == a[a[t] - 1] ) t ++;
            else
            {
                //int temp = a[t] ; a[t] = a[a[t] - 1] ; a[a[t] - 1] = temp ;
                int temp = a[a[t] - 1] ; a[a[t] - 1] = a[t] ; a[t] = temp ;
            }
        }
        for( int i = 0 ; i < n ; i ++ )
            if( a[i] != i + 1 ) return i + 1;
        return n + 1;
    }
}
