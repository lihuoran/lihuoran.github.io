# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/4sum
@Language: Python
@Datetime: 15-12-12 05:22
'''

class Solution:
	def fourSum(self, numbers, target):
		if len(numbers) < 4:
			return []

		self.m = {}
		for e in numbers:
			self.m[e] = self.m.get(e, 0) + 1

		self.nlist = self.m.keys()
		self.nlist.sort()
		self.nlist.reverse()
		self.n = len(self.nlist)

		self.ret = []
		self.target = target
		self.dfs(0, [])

		self.ret.reverse()
		return self.ret

	def dfs(self, idx, curlist):
		if idx == self.n:
			if len(curlist) == 4 and sum(curlist) == self.target:
				ans = list(curlist)
				ans.reverse()
				self.ret.append(ans)
			return

		self.dfs(idx + 1, curlist)

		next = list(curlist)
		val = self.nlist[idx]
		cnt = self.m[val]
		for i in range(cnt):
			next.append(val)
			if len(next) > 4:
				return
			self.dfs(idx + 1, next)