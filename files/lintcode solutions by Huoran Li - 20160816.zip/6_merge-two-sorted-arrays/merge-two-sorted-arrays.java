/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/merge-two-sorted-arrays
@Language: Java
@Datetime: 16-02-06 12:41
*/

class Solution {
    /**
     * @param A and B: sorted integer array A and B.
     * @return: A new sorted integer array
     */
    public int[] mergeSortedArray(int[] A, int[] B) {
        // Write your code here
        int na = A.length;
        int nb = B.length;
        int[] retArray = new int[na + nb];

        int nr = 0;
        int pa = 0, pb = 0;
        while (pa < na || pb < nb) {
        	if (pa == na) {	// A is already empty
        		retArray[nr++] = B[pb++];
        	} else if (pb == nb) {	// B is already empty
        		retArray[nr++] = A[pa++];
        	} else {
        		if (A[pa] < B[pb]) {
        			retArray[nr++] = A[pa++];
        		} else {
        			retArray[nr++] = B[pb++];
        		}
        	}
        }

        return retArray;
    }
}
