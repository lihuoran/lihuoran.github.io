# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/median-of-two-sorted-arrays
@Language: Python
@Datetime: 15-12-16 09:13
'''

class Solution:
	"""
	@param A: An integer array.
	@param B: An integer array.
	@return: a double whose format is *.5 or *.0
	"""
	def findMedianSortedArrays(self, A, B):
		# write your code here
		a = A
		b = B
		m = len(a)
		n = len(b)
		k = m + n

		if k % 2 == 1:
			return float(self.findk(a, m, b, n, k / 2 + 1))
		else:
			x = float(self.findk(a, m, b, n, k / 2))
			y = float(self.findk(a, m, b, n, k / 2 + 1))
			return (x + y) / 2

	def findk(self, a, m, b, n, k):
		if m > n:
			return self.findk(b, n, a, m, k)
		if m == 0:
			return b[k - 1]
		if k <= 1:
			return min(a[0], b[0])

		pa = min(k / 2, m)
		pb = k - pa
		if a[pa - 1] < b[pb - 1]:
			return self.findk(a[pa:], m - pa, b, n, k - pa)
		elif a[pa - 1] > b[pb - 1]:
			return self.findk(a, m, b[pb:], n - pb, k - pb)
		else:
			return a[pa - 1]