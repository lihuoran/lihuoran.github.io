/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/max-tree
@Language: Java
@Datetime: 15-10-01 14:54
*/


/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param A: Given an integer array with no duplicates.
     * @return: The root of max tree.
     */
    private int[] a;
    private int n;
    private TreeNode ret;
    
	public TreeNode maxTree( int[] A )
    {
        // write your code here
		a = A;
		n = a.length;
		ret = null;

		for( int i = 0 ; i < n ; i ++ )
		{
			ret = deal( ret , a[i] );
		}
		
		return ret;
    }
	
	private TreeNode deal( TreeNode root , int val )
	{
		if( root == null ) return new TreeNode( val );
		if( val > root.val )
		{
			TreeNode ret = new TreeNode( val );
			ret.left = root;
			return ret;
		}
		else
		{
			root.right = deal( root.right , val );
			return root;
		}
	}
}
