/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/3sum-closest
@Language: Java
@Datetime: 15-06-07 06:16
*/

public class Solution
{
    /**
     * @param numbers: Give an array numbers of n integer
     * @param target : An integer
     * @return : return the sum of the three integers, the sum closest target.
     */
    private int[] a;
    private int n;
    
    public int threeSumClosest( int[] numbers , int target )
    {
        // write your code here
        a = numbers;
        n = a.length;
        
        qsort();
        
        int m = -1;
        int ans = -1;
        for( int i = 0 ; i < n ; i ++ )
        for( int j = i + 1 ; j < n ; j ++ )
        {
            int t = target - a[i] - a[j];
            int p = find( t );
            int temp , idx;
            int c , d;
            if( p == -1 )
            {
            	c = 0;
            	while( c == i || c == j ) c ++;
                temp = abs( t - a[c] );
                idx = c;
            }
            else if( p == n - 1 )
            {
            	c = n - 1;
            	while( c == i || c == j ) c --;
                temp = abs( t - a[c] );
                idx = c;
            }
            else
            {
            	c = p;
            	d = p + 1;
            	while( c > -1 && ( c == i || c == j ) ) c --;
            	while( d < n && ( d == i || d == j ) ) d ++;
                if( d == n )
                {
                    temp = abs( t - a[c] );
                    idx = c;
                }
                else if( c == -1 )
                {
                	temp = abs( t - a[d] );
                    idx = d;
                }
                else if( d == n || abs( t - a[c] ) < abs( t - a[d] ) )
                {
                    temp = abs( t - a[c] );
                    idx = c;
                }
                else
                {
                    temp = abs( t - a[d] );
                    idx = d;
                }
            }
            
       //     System.out.printf( "%d\t%d\t%d\t%d\t%d\n" , a[i] , a[j] , p , temp , idx );
            
            if( m == -1 || temp < m )
            {
                m = temp;
                ans = a[i] + a[j] + a[idx];
            }
        }
        
        return ans;
    }
    
    private int abs( int x )
    {
        return ( x < 0 ? x * -1 : x );
    }
    
    private int find( int t )
    {
        if( t < a[0] ) return -1;
        if( t >= a[n - 1] ) return n - 1;
        int l = 0 , r = n - 1;
        while( ( r - l ) >= 5 )
        {
            int m = ( l + r ) / 2;
            if( a[m] == t ) return m;
            
            if( a[m] < t ) l = m;
            else r = m;
        }
        
        for( int i = l ; i < r ; i ++ )
            if( a[i] <= t && a[i + 1] > t ) return i;
        return -1;
    }
    
    private void qsort()
    {
    	for( int i = 0 ; i < n ; i ++ )
    	for( int j = i + 1 ; j < n ; j ++ )
    		if( a[i] > a[j] ) swap( i , j );
    }

    
    private void swap( int x , int y )
    {
        int temp = a[x] ; a[x] = a[y] ; a[y] = temp ;
    }
}