/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/unique-binary-search-trees
@Language: Java
@Datetime: 15-05-11 13:25
*/

public class Solution
{
    /**
     * @paramn n: An integer
     * @return: An integer
     */
    public int numTrees( int n )
    {
        // write your code here
        int ret = 1;
        int[] a = new int[2 * n + 1];
        for( int i = 1 ; i <= 2 * n ; i ++ )
            a[i] = i;
            
        for( int i = 2 ; i <= n ; i ++ )
        {
        	int val = i;
        	for( int j = 1 ; j <= 2 * n && val != 1 ; j ++ )
        	{
        		int temp = gcd( val , a[j] );
        		if( temp > 1 )
        		{
        			val /= temp;
        			a[j] /= temp;
        		}
        	}
        }
        for( int i = 2 ; i <= n ; i ++ )
        {
        	int val = i;
        	for( int j = 1 ; j <= 2 * n && val != 1 ; j ++ )
        	{
        		int temp = gcd( val , a[j] );
        		if( temp > 1 )
        		{
        			val /= temp;
        			a[j] /= temp;
        		}
        	}
        }
        int val = n + 1;
    	for( int j = 1 ; j <= 2 * n && val != 1 ; j ++ )
    	{
    		int temp = gcd( val , a[j] );
    		if( temp > 1 )
    		{
    			val /= temp;
    			a[j] /= temp;
    		}
    	}
       
       
            
        for( int i = 1 ; i <= 2 * n ; i ++ )
        {
            ret *= a[i];
        }
            
        return ret;
    }
    
    private int gcd( int a , int b )
    {
    	if( a > b ) return gcd( b , a );
    	if( a == 0 ) return b;
    	return gcd( a , b % a );
    }
}
