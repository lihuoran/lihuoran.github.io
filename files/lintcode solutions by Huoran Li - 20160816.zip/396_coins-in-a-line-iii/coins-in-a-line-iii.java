/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-iii
@Language: Java
@Datetime: 15-11-22 07:10
*/

public class Solution {
    /**
     * @param values: an array of integers
     * @return: a boolean which equals to true if the first player will win
     */
    public boolean firstWillWin(int[] values) {
        // write your code here
        if (values.length == 0) {
            return false;
        } else if (values.length == 1) {
            return true;
        }
        
        int n = values.length;
        int[] v = new int[n + 1];
        int[] s = new int[n + 1];
        
        for (int i = 1; i <= n; i += 1) {
            v[i] = values[i - 1];
        }
        
        s[0] = 0;
        for (int i = 1; i <= n; i += 1) {
            s[i] = s[i - 1] + v[i];
        }
        
        int[][] f = new int[n + 1][n + 1];
        for (int d = 0; d < n; d += 1) {
            for (int i = 1, j = i + d; j <= n; i += 1, j += 1) {
                if (i == j) {
                    f[i][j] = v[i];
                    continue;
                }
                
                int a = v[i] + (s[j] - s[i] - f[i + 1][j]);
                int b = v[j] + (s[j - 1] - s[i - 1] - f[i][j - 1]);
                f[i][j] = (a > b ? a : b);
            }
        }
        
        int x = f[1][n];
        int y = s[n] - s[0] - x;
        return (x > y);
    }
}
