/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-words
@Language: Java
@Datetime: 15-06-09 05:25
*/

class Solution
{
    /**
     * @param dictionary: an array of strings
     * @return: an arraylist of strings
     */
    ArrayList<String> longestWords( String[] dictionary )
    {
        // write your code here
        ArrayList<String> ret = new ArrayList<String>();
        for( String s : dictionary )
        {
            if( ret.isEmpty() || s.length() == ret.get( 0 ).length() )
                ret.add( s );
            else if( s.length() > ret.get( 0 ).length() )
            {
                ret.clear();
                ret.add( s );
            }
        }
        return ret;
    }
};
