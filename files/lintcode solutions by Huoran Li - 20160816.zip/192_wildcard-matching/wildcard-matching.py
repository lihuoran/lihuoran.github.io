# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/wildcard-matching
@Language: Python
@Datetime: 15-09-06 07:43
'''

import re

class Solution:
    """
    @param s: A string 
    @param p: A string includes "?" and "*"
    @return: A boolean
    """
    def isMatch( self , s , p ):
        p = re.sub( '\*+' , '*' , p )

        self.ansmap = {}
        self.s = s
        self.p = p
        self.ls = len( s )
        self.lp = len( p )

        return self.match( 0 , 0 )

    def match( self , x , y ):
        if ( x , y ) in self.ansmap:
            return self.ansmap[( x , y )]

        s = self.s[x:]
        p = self.p[y:]
        if p == '*':
            ans = True
        elif len( s ) == 0 and len( p ) == 0:
            ans = True
        elif len( s ) == 0 or len( p ) == 0:
            ans = False
        else:
            if p[0] == '?':
                ans = self.match( x + 1 , y + 1 )
            elif p[0] == '*':
                ans = False
                for i in range( x , self.ls ):
                    if self.match( i + 1 , y + 1 ) == True:
                        ans = True
                        break
            else:
                if s[0] == p[0]:
                    ans = self.match( x + 1 , y + 1 )
                else:
                    ans = False

        self.ansmap[( x , y )] = ans;
        return ans