/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/3sum
@Language: Java
@Datetime: 15-05-17 07:15
*/

public class Solution
{
    /**
     * @param numbers : Give an array numbers of n integer
     * @return : Find all unique triplets in the array which gives the sum of zero.
     */
    
    
    public ArrayList<ArrayList<Integer>> threeSum( int[] numbers )
    {
        // write your code here
        int[] a = numbers;
        int n = a.length;
        
        qsort( a , 0 , n - 1 );
        
        ArrayList<ArrayList<Integer>> ret = new ArrayList<ArrayList<Integer>>();
        boolean first = true;
        int li = -1 , lj = -1;
        for( int i = 0 ; i < n ; i ++ )
        {
            if( i != 0 && a[i] == a[i - 1] ) continue;
            
            for( int j = i + 1 ; j < n ; j ++ )
            {
                if( j != i + 1 && a[j] == a[j - 1] ) continue;
                
                int x = a[i] , y = a[j] , z = 0 - x - y;
                if( z < y ) break;
                
                if( find( a , z , j + 1 , n - 1 ) == true )
                {
                    ArrayList<Integer> temp = new ArrayList<Integer>();
                    temp.add( x );
                    temp.add( y );
                    temp.add( z );
                    ret.add( temp );
                }
            }
        }
        
        return ret;
    }
    
    private boolean find( int[] a , int val , int x , int y )
    {
        int l = x , r = y;
        while( l <= r )
        {
            int m = ( l + r ) / 2;
            if( a[m] == val ) return true;
            else if( a[m] > val ) r = m - 1;
            else l = m + 1;
        }
        return false;
    }
    
    private void qsort( int[] a , int l , int r )
    {
        if( l >= r ) return ;
        int x = partition( a , l , r );
        qsort( a , l , x - 1 );
        qsort( a , x + 1 , r );
    }
    
    private int partition( int[] a , int l , int r )
    {
        int t = l;
        int temp;
        for( int i = l + 1 ; i <= r ; i ++ )
            if( a[i] < a[l] )
            {
                t ++;
                temp = a[t] ; a[t] = a[i] ; a[i] = temp ;
            }
        temp = a[t] ; a[t] = a[l] ; a[l] = temp ;
        return t;
    }
}
