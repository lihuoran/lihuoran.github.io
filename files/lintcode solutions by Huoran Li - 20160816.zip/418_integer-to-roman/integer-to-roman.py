# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/integer-to-roman
@Language: Python
@Datetime: 15-11-30 01:50
'''

class Solution:
	def intToRoman(self, n):
		m = {1: 'I', 10: 'x', 100: 'C', 1000: 'M', 5: 'V', 50: 'L', 500: 'D'}
		
		a = []
		base = 1
		while n >= base:
			a.append(n % (base * 10) - n % base)
			base *= 10
		a.reverse()

		ret = ''
		for e in a:
			if self.size(e) >= 4:
				for i in range(e / 1000):
					ret += 'M'
			elif self.size(e) == 3:
				if e < 400:
					for i in range(e / 100):
						ret += 'C'
				elif e == 400:
					ret += 'CD'
				elif e < 900:
					ret += 'D'
					for i in range((e - 500) / 100):
						ret += 'C'
				else:
					ret += 'CM'
			elif self.size(e) == 2:
				if e < 40:
					for i in range(e / 10):
						ret += 'X'
				elif e == 40:
					ret += 'XL'
				elif e < 90:
					ret += 'L'
					for i in range((e - 50) / 10):
						ret += 'X'
				else:
					ret += 'XC'
			else:
				if e < 4:
					for i in range(e / 1):
						ret += 'I'
				elif e == 4:
					ret += 'IV'
				elif e < 9:
					ret += 'V'
					for i in range((e - 5) / 1):
						ret += 'I'
				else:
					ret += 'IX'
				pass

		return ret
			
	
	def size(self, n):
		ret = 0
		if n == 0:
			return 1
		while n != 0:
			ret += 1
			n /= 10
		return ret