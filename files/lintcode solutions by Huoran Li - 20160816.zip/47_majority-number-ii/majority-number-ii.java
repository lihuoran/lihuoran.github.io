/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/majority-number-ii
@Language: Java
@Datetime: 15-12-02 01:45
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: The majority number that occurs more than 1/3
     */
    public int majorityNumber(ArrayList<Integer> nums) {
        // write your code
        if (nums == null || nums.size() == 0) {
            return -1;
        }
        
        int can1 = 0, can2 = 0;
        int cnt1 = 0, cnt2 = 0;
        for (Integer a: nums) {
            if (cnt1 == 0 || a == can1) {
                can1 = a;
                cnt1 += 1;
            } else if (cnt2 == 0 || a == can2) {
                can2 = a;
                cnt2 += 1;
            } else {
                cnt1 -= 1;
                cnt2 -= 1;
            }
        }
        
        cnt1 = cnt2 = 0;
        for (Integer a: nums) {
            if (a == can1) {
                cnt1 += 1;
            }
            if (a == can2) {
                cnt2 += 1;
            }
        }
        
        if (cnt1 > cnt2) {
            return can1;
        } else {
            return can2;
        }
    }
}

