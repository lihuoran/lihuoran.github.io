/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/rehashing
@Language: Java
@Datetime: 15-10-01 14:41
*/

/**
 * Definition for ListNode
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param hashTable: A list of The first node of linked list
     * @return: A list of The first node of linked list which have twice size
     */    
    public ListNode[] rehashing(ListNode[] hashTable) {
        // write your code here
        ArrayList<Integer> repo = new ArrayList<Integer>();
        int n = hashTable.length;
        for( int i = 0 ; i < n ; i ++ )
        {
            ListNode t = hashTable[i];
            while( t != null )
            {
                repo.add( t.val );
                t = t.next;
            }
        }
        
        n *= 2;
        ListNode[] ret = new ListNode[n];
        for( int i = 0 ; i < n ; i ++ )
            ret[i] = null;
        for( int i = 0 ; i < repo.size() ; i ++ )
        {
            int val = repo.get( i );
            int idx = val % n;
            while( idx < 0 ) idx += n;
            if( ret[idx] == null ) ret[idx] = new ListNode( val );
            else
            {
                ListNode t = ret[idx];
                while( t.next != null ) t = t.next;
                t.next = new ListNode( val );
            }
        }
        
        return ret;
    }
};

