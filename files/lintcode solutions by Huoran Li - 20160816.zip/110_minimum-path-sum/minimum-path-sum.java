/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/minimum-path-sum
@Language: Java
@Datetime: 15-11-15 07:16
*/

public class Solution {
    /**
     * @param grid: a list of lists of integers.
     * @return: An integer, minimizes the sum of all numbers along its path
     */
    public int minPathSum(int[][] grid) {
        // write your code here
        int r = grid.length;
        int c = grid[0].length;
        int[][] f = new int[r][c];
        
        for (int i = 0; i < r; i += 1) {
            for (int j = 0; j < c; j += 1) {
                if (i == 0 && j == 0) {
                    f[i][j] = grid[i][j];
                } else if (i == 0) {
                    f[i][j] = grid[i][j] + f[i][j - 1];
                } else if (j == 0) {
                    f[i][j] = grid[i][j] + f[i - 1][j];
                } else {
                    f[i][j] = grid[i][j] + min(f[i - 1][j], f[i][j - 1]);
                }
            }
        }
        
        return f[r - 1][c - 1];
    }
    
    private int min(int a, int b) {
        return (a < b ? a : b);
    }
}

