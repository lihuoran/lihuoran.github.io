/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/powx-n
@Language: Java
@Datetime: 15-12-06 06:38
*/

public class Solution {
    /**
     * @param x the base number
     * @param n the power number
     * @return the result
     */
    public double myPow(double x, int n) {
        // Write your code here
        if (n == 0) {
            return 1.0;
        } else if (n > 0) {
            return calc(x, n);
        } else {
            return 1.0 / calc(x, n * -1);
        }
    }
    
    private double calc(double x, int n) {
        double[] v = new double[40];
        v[0] = x;
        for (int i = 1; i < 31; i += 1) {
            v[i] = v[i - 1] * v[i - 1];
        }
        
        double ret = 1.0;
        for (int i = 0; i < 31; i += 1) {
            int cur = (1 << i);
            if ((n & cur) != 0) {
                ret *= v[i];
            }
        }
        return ret;
    }
}
