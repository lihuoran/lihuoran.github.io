/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/valid-sudoku
@Language: Java
@Datetime: 15-05-05 06:40
*/

class Solution
{
    private boolean[][] row;
    private boolean[][] col;
    private boolean[][][] block;

    /**
      * @param board: the board
        @return: wether the Sudoku is valid
      */
    public boolean isValidSudoku( char[][] board )
    {
        try
        {
            int[][] map = new int[9][9];
            for( int i = 0 ; i < 9 ; i ++ )
            for( int j = 0 ; j < 9 ; j ++ )
            {
                if( board[i][j] == '.' ) map[i][j] = -1;
                else map[i][j] = board[i][j] - '0' - 1;
            }

            row = new boolean[9][9];
            col = new boolean[9][9];
            block = new boolean[3][3][9];
            for( int i = 0 ; i < 9 ; i ++ )
            for( int j = 0 ; j < 9 ; j ++ )
                row[i][j] = col[i][j] = false;
            for( int i = 0 ; i < 3 ; i ++ )
            for( int j = 0 ; j < 3 ; j ++ )
            for( int k = 0 ; k < 9 ; k ++ )
                block[i][j][k] = false;

            for( int i = 0 ; i < 9 ; i ++ )
            for( int j = 0 ; j < 9 ; j ++ )
            {
                int val = map[i][j];
                if( val == -1 ) continue;
                
                if( row[i][val] == true ) return false;
                if( col[j][val] == true ) return false;
                if( block[i / 3][j / 3][val] == true ) return false;

                row[i][val] = col[j][val] = block[i / 3][j / 3][val] = true;
            }

            return true;
        }
        catch( Exception e )
        {
            return false;
        }
    }
};
