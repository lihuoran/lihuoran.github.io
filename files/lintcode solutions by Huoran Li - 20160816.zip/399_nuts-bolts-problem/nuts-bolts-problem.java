/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/nuts-bolts-problem
@Language: Java
@Datetime: 15-12-17 06:28
*/

/**
 * public class NBCompare {
 *     public int cmp(String a, String b);
 * }
 * You can use compare.cmp(a, b) to compare nuts "a" and bolts "b",
 * if "a" is bigger than "b", it will return 1, else if they are equal,
 * it will return 0, else if "a" is smaller than "b", it will return -1.
 * When "a" is not a nut or "b" is not a bolt, it will return 2, which is not valid.
*/
public class Solution {
    /**
     * @param nuts: an array of integers
     * @param bolts: an array of integers
     * @param compare: a instance of Comparator
     * @return: nothing
     */
    String[] n;
    String[] b;
    NBComparator c;

    public void sortNutsAndBolts(String[] nuts, String[] bolts, NBComparator compare) {
        // write your code here
    	n = nuts;
    	b = bolts;
    	c = compare;

    	sort(0, b.length - 1);
    	sort2(0, n.length - 1);
    }

    private void sort(int l, int r) {
    	if (l >= r) {
    		return;
    	}
    	int x = partition(l, r);
    	sort(l, x - 1);
    	sort(x + 1, r);
    }
    
    private void sort2(int l, int r) {
    	if (l >= r) {
    		return;
    	}
    	int x = partition2(l, r);
    	sort2(l, x - 1);
    	sort2(x + 1, r);
    }

    private int partition(int l, int r) {
    	int idx;
    	for (idx = 0; idx < n.length; idx += 1) {
    		if (c.cmp(n[idx], b[l]) == 0) {
    			break;
    		}
    	}
    	int t = l;
    	for (int i = l + 1; i <= r; i += 1) {
    		if (c.cmp(n[idx], b[i]) == 1) {
    			t += 1;
    			swap(t, i);
    		}
    	}
    	swap(t, l);
    	return t;
    }
    
    private int partition2(int l, int r) {
    	int idx;
    	for (idx = 0; idx < b.length; idx += 1) {
    		if (c.cmp(n[l], b[idx]) == 0) {
    			break;
    		}
    	}
    	int t = l;
    	for (int i = l + 1; i <= r; i += 1) {
    		if (c.cmp(n[i], b[idx]) == -1) {
    			t += 1;
    			swap2(t, i);
    		}
    	}
    	swap2(t, l);
    	return t;
    }

	private void swap(int x, int y) {
		String temp = new String(b[x]);
		b[x] = new String(b[y]);
		b[y] = new String(temp);
	}
	
	private void swap2(int x, int y) {
		String temp = new String(n[x]);
		n[x] = new String(n[y]);
		n[y] = new String(temp);
	}
};