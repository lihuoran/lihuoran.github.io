/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/a-b-problem
@Language: Java
@Datetime: 16-02-06 11:57
*/

class Solution {
	/*
	 * param a: The first integer
	 * param b: The second integer
	 * return: The sum of a and b
	 */
	public int aplusb(int a, int b) {
		// write your code here, try to do it without arithmetic operators.
		if (b == 0) {
			return a;
		} else {
			return aplusb(a ^ b, (a & b) << 1);
		}
	}
};
