/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/a-b-problem
@Language: C++
@Datetime: 15-05-10 16:45
*/

class Solution {
public:
    /*
     * @param a: The first integer
     * @param b: The second integer
     * @return: The sum of a and b
     */
    int aplusb(int a, int b) {
        // write your code here, try to do it without arithmetic operators.
        return a + b;
    }
};
