/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subarray-sum-closest
@Language: C++
@Datetime: 15-12-16 09:21
*/

class Solution {
public:
    /**
     * @param nums: A list of integers
     * @return: A list of integers includes the index of the first number 
     *          and the index of the last number
     */
    vector<int> subarraySumClosest(vector<int> nums){
        // write your code here
        int len=nums.size();
        vector<int> res(2);

        if(len==1){
            res[0]=0;
            res[1]=0;
            return res;
        }

        vector<pair<int,int> > sums_index(len);

        sums_index[0]={nums[0],0};
        for(int i=1;i<len;i++){
            sums_index[i].first=sums_index[i-1].first+nums[i];
            sums_index[i].second=i;
        }

        sort(sums_index.begin(),sums_index.end());

        int min_diff=INT_MAX;
        int left,right;
        for(int i=1;i<len;i++){
            int diff=abs(sums_index[i].first-sums_index[i-1].first);
            if(diff<min_diff){
                min_diff=diff;
                left=min(sums_index[i].second,sums_index[i-1].second)+1;
                right=max(sums_index[i].second,sums_index[i-1].second);
            }
        }


        res[0]=left;
        res[1]=right;
        return res;
    }
};