/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-search-tree-iterator
@Language: Java
@Datetime: 15-11-15 07:36
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 * Example of iterate a tree:
 * BSTIterator iterator = new BSTIterator(root);
 * while (iterator.hasNext()) {
 *    TreeNode node = iterator.next();
 *    do something for node
 * } 
 */
public class BSTIterator {
    //@param root: The root of binary tree.
    private Stack<TreeNode> s;
    
    public BSTIterator(TreeNode root) {
        // write your code here
        s = new Stack<TreeNode>();
        TreeNode cur = root;
        while (cur != null) {
            s.push(cur);
            cur = cur.left;
        }
    }

    //@return: True if there has next node, or false
    public boolean hasNext() {
        // write your code here
        while (!s.isEmpty() && s.peek() == null) {
            s.pop();
        }
        if (s.isEmpty()) {
            return false;
        }
        return true;
    }
    
    //@return: return next node
    public TreeNode next() {
        // write your code here
        if (hasNext() == false) {
            return null;
        }
        
        TreeNode ret = s.pop();
        TreeNode cur = ret.right;
        while (cur != null) {
            s.push(cur);
            cur = cur.left;
        }
        
        return ret;
        
    }
}
