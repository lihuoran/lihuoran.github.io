/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/partition-list
@Language: Java
@Datetime: 15-08-06 03:37
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param head: The first node of linked list.
     * @param x: an integer
     * @return: a ListNode 
     */
    public ListNode partition( ListNode head , int x )
    {
        // write your code here
        ListNode p = new ListNode( -1 ) , ptail = p;
        ListNode q = new ListNode( -1 ) , qtail = q;
        ListNode cur = head;
        ListNode next;
        while( cur != null )
        {
        	next = cur.next;
        	if( cur.val < x )
        	{
        		ptail.next = cur;
        		ptail = cur;
        		ptail.next = null;
        	}
        	else
        	{
        		qtail.next = cur;
        		qtail = cur;
        		qtail.next = null;
        	}
        	cur = next;
        }
        ptail.next = q.next;
        return p.next;
    }
}

