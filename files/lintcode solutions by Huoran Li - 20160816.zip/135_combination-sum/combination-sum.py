# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/combination-sum
@Language: Python
@Datetime: 15-08-09 02:12
'''

class Solution:
    # @param candidates, a list of integers
    # @param target, integer
    # @return a list of lists of integers
    def combinationSum(self, candidates, target):
        # write your code here
        self.ret = []
        self.data = candidates
        self.data.sort()
        
        self.dfs( 0 , [] , target);
        return self.ret
    
    def dfs( self , curidx , curlist , left ):
        if left == 0:
            self.ret.append( curlist )
            return
        if curidx == len( self.data ):
            return
        if self.data[curidx] > left:
            return
        
        m = left / self.data[curidx]
        for i in range( m + 1 ):
            newlist = list( curlist )
            for j in range( i ):
                newlist.append( self.data[curidx] )
            self.dfs( curidx + 1 , newlist , left - self.data[curidx] * i )