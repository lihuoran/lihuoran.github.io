/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/subtree
@Language: Java
@Datetime: 15-06-09 06:02
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     * @param T1, T2: The roots of binary tree.
     * @return: True if T2 is a subtree of T1, or false.
     */
    public boolean isSubtree( TreeNode T1 , TreeNode T2 )
    {
        // write your code here
        if( T2 == null ) return true;
        if( T1 == null ) return false;
        if( same( T1 , T2 ) ) return true;
        if( isSubtree( T1.left , T2 ) ) return true;
        if( isSubtree( T1.right , T2 ) ) return true;
        return false;
    }
    
    private boolean same( TreeNode a , TreeNode b )
    {
        if( a == null && b == null ) return true;
        if( a == null && b != null ) return false;
        if( a != null && b == null ) return false;
        if( a.val != b.val ) return false;
        if( !same( a.left , b.left ) ) return false;
        if( !same( a.right , b.right ) ) return false;
        return true;
    }
}
