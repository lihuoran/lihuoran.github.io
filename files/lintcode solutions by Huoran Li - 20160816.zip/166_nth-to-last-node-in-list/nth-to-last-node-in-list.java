/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/nth-to-last-node-in-list
@Language: Java
@Datetime: 15-09-26 16:53
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The first node of linked list.
     * @param n: An integer.
     * @return: Nth to last node of a singly linked list. 
     */
    ListNode nthToLast(ListNode head, int n) {
        if( head == null ) return null;
        
        // write your code here
        int l = 1;
        ListNode t = head;
        while( t.next != null )
        {
            l ++;
            t = t.next;
        }
        
        int c = 1;
        t = head;
        while( c < ( l - n + 1 ) )
        {
            c ++;
            t = t.next;
        }
        return t;
    }
}

