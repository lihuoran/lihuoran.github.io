/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/segment-tree-modify
@Language: Java
@Datetime: 15-05-09 05:43
*/

/**
 * Definition of SegmentTreeNode:
 * public class SegmentTreeNode {
 *     public int start, end, max;
 *     public SegmentTreeNode left, right;
 *     public SegmentTreeNode(int start, int end, int max) {
 *         this.start = start;
 *         this.end = end;
 *         this.max = max
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution
{
    /**
     *@param root, index, value: The root of segment tree and 
     *@ change the node's value with [index, index] to the new given value
     *@return: void
     */
    public void modify( SegmentTreeNode root , int index , int value )
    {
        // write your code here
        if( index < root.start || index > root.end ) return ;
        if( root.start == root.end )
        {
        	root.max = value;
        }
        else
        {
	        int mid = ( root.start + root.end ) / 2;
	        if( index <= mid ) modify( root.left , index , value );
	        else modify( root.right , index , value );

	        root.max = max( root.left.max , root.right.max );
    	}
    }

    private int max( int a , int b )
    {
    	return ( a > b ? a : b );
    }
}
