/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/hash-function
@Language: Java
@Datetime: 15-05-07 11:35
*/

class Solution
{
    /**
     * @param key: A String you should hash
     * @param HASH_SIZE: An integer
     * @return an integer
     */
    public int hashCode( char[] key ,int HASH_SIZE )
    {
        // write your code here
        long size = HASH_SIZE;
        long cur = 0;
        long n = key.length;
        for( int i = 0 ; i < n ; i ++ )
        {
            cur = cur * 33 + ( long )( key[i] );
            cur %= size;
        }
        return ( int )( cur );
    }
};
