/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/count-of-smaller-number
@Language: Java
@Datetime: 15-05-11 13:15
*/

public class Solution
{
   /**
     * @param A: An integer array
     * @return: The number of element in the array that 
     *          are smaller that the given integer
     */
    public ArrayList<Integer> countOfSmallerNumber( int[] A , int[] queries )
    {
        // write your code here
    	int n = A.length;
    	qsort( A , 0 , n - 1 );
    	
    	ArrayList<Integer> ret = new ArrayList<Integer>();
    	for( int i = 0 ; i < queries.length ; i ++ )
    	{
    		int val = queries[i];
    		ret.add( bisearch( A , val ) );
    	}
    	
    	return ret;
    }
    
    private int bisearch( int[] a , int val )
    {
    	int n = a.length;
    	if( n == 0 ) return 0;
    	if( val <= a[0] ) return 0;
    	if( val > a[n - 1] ) return n;
    	int l = 0 , r = n - 1;
    	while( ( r - l ) > 3 )
    	{
    		int m = ( l + r ) / 2;
    		if( a[m] >= val ) r = m;
    		else l = m;
    	}
    	for( int i = l ; i < r ; i ++ )
    		if( val > a[i] && val <= a[i + 1] ) return i + 1;
    	return -1;
    }
    
    private void qsort( int[] a , int l , int r )
    {
    	if( l >= r ) return ;
    	int x = partition( a , l , r );
    	qsort( a , x + 1 , r );
    	qsort( a , l , x - 1 );
    }
    
    private int partition( int[] a , int l , int r )
    {
    	int t = l;
    	int temp;
    	for( int i = l + 1 ; i <= r ; i ++ )
    		if( a[i] < a[l] )
    		{
    			t ++;
    			temp = a[t] ; a[t] = a[i] ; a[i] = temp ;
    		}
    	temp = a[t] ; a[t] = a[l] ; a[l] = temp ;
    	
    	return t;
    }
}
