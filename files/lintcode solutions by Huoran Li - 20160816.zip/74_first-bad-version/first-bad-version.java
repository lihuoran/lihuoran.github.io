/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/first-bad-version
@Language: Java
@Datetime: 15-06-07 06:28
*/

/**
 * public class VersionControl {
 *     public static boolean isBadVersion(int k);
 * }
 * you can use VersionControl.isBadVersion(k) to judge whether 
 * the kth code version is bad or not.
*/
class Solution
{
    /**
     * @param n: An integers.
     * @return: An integer which is the first bad version.
     */
    public int findFirstBadVersion( int n )
    {
        // write your code here
        if( bad( 1 ) == true ) return 1;
        
        int l = 1 , r = n;
        while( l != r - 1 )
        {
            int m = ( l + r ) / 2;
            if( bad( m ) == true ) r = m;
            else l = m;
        }
        
        return r;
    }
    
    private boolean bad( int x )
    {
        return VersionControl.isBadVersion( x );
    }
}

