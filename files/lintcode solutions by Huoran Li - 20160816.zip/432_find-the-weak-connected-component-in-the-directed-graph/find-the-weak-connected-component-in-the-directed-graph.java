/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/find-the-weak-connected-component-in-the-directed-graph
@Language: Java
@Datetime: 15-11-15 01:59
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) { label = x; neighbors = new ArrayList<DirectedGraphNode>(); }
 * };
 */
public class Solution {
    /**
     * @param nodes a array of Directed graph node
     * @return a connected set of a directed graph
     */
    public List<List<Integer>> connectedSet2(ArrayList<DirectedGraphNode> nodes) {
        // Write your code here
    	int n = nodes.size();
    	Union u = new Union(n);
    	
    	for (int i = 0; i < n; i += 1) {
    		u.init(nodes.get(i).label);
    	}
    	
    	for (int i = 0; i < n; i += 1) {
    		DirectedGraphNode thisnode = nodes.get(i);
    		for (DirectedGraphNode e: thisnode.neighbors) {
    			u.union(thisnode.label, e.label);
    		}
    	}
    	
    	return u.getUnions();
    }
}

class Union {
	private int n;
	private int[] father;
	private HashMap<Integer, Integer> amap;
	private HashMap<Integer, Integer> bmap;
	
	public Union(int size) {
		n = size;
		father = new int[n];
		for (int i = 0; i < n; i += 1) {
			father[i] = i;
		}
		
		amap = new HashMap<Integer, Integer>();
		bmap = new HashMap<Integer, Integer>();
	}
	
	public void init(int a) {
		turn(a);
	}
	
	private int turn(int a) {
		if (amap.containsKey(a) == false) {
			int n = amap.size();
			amap.put(a, n);
			bmap.put(n, a);
		}
		return amap.get(a);
	}
	
	private int back(int b) {
		return bmap.get(b);
	}
	
	public void union(int a, int b) {
		a = turn(a);
		b = turn(b);
		father[root(a)] = root(b);
	}
	
	public boolean query(int a, int b) {
		a = turn(a);
		b = turn(b);
		return (root(a) == root(b));
	}
	
	public ArrayList<List<Integer>> getUnions() {
		HashMap<Integer,ArrayList<Integer>> map = new HashMap<Integer,ArrayList<Integer>>();
		HashSet<Integer> set = new HashSet<Integer>();
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < n; i += 1) {
			int r = root(i);
			if (set.contains(r) == false) {
				set.add(r);
				list.add(r);
				map.put(r, new ArrayList<Integer>());
			}
			map.get(r).add(back(i));
		}
		
		ArrayList<List<Integer>> ret = new ArrayList<List<Integer>>();
		for (int r: list) {
			ret.add(map.get(r));
		}
		return ret;
	}
	
	private int root(int x) {
		if (x == father[x]) {
			return x;
		} else {
			father[x] = root(father[x]);
			return father[x];
		}
	}
}