/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/count-and-say
@Language: Java
@Datetime: 15-06-09 05:18
*/

public class Solution
{
    /**
     * @param n the nth
     * @return the nth sequence
     */
    public String countAndSay( int n )
    {
        // Write your code here
        if( n == 1 ) return "1";
        
        String a = countAndSay( n - 1 );
        int len = a.length();
        String ret = "";
        
        char cur = a.charAt( 0 );
        int cnt = 1;
        for( int i = 1 ; i < len ; i ++ )
        {
            char c = a.charAt( i );
            if( c == cur ) cnt ++;
            else
            {
                ret += cnt;
                ret += cur;
                cur = c;
                cnt = 1;
            }
        }
        ret += cnt;
        ret += cur;
        
        return ret;
    }
}
