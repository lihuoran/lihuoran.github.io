/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/o1-check-power-of-2
@Language: Java
@Datetime: 15-05-05 06:43
*/

class Solution
{
    /*
     * @param n: An integer
     * @return: True or false
     */
    public boolean checkPowerOf2( int n )
    {
        // write your code here
        int cnt = 0;
        for( int i = 0 ; i < 31 ; i ++ )
        {
            if( n % 2 == 1 ) cnt ++;
            n >>= 1;
        }
        return ( cnt == 1 );
    }
};
