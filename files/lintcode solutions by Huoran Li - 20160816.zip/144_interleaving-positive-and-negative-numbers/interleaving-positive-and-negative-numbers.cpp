/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/interleaving-positive-and-negative-numbers
@Language: C++
@Datetime: 15-12-12 05:48
*/

class Solution {
public:
    /**
     * @param A: An integer array.
     * @return: void
     */
    void rerange(vector<int> &A) {
        // write your code here
        int pos = 0;
        for(auto x:A)
            if(x>0)
                pos++;
        int neg = A.size()-pos;
        bool flag = (pos>neg);
        for(int i=0;i<A.size();i++)
        {
            for(int j=i;j<A.size();j++)
            {
                if((flag&&A[j]>0)||(!flag&&A[j]<0))
                {
                    swap(A[i],A[j]);
                    break;
                }
            }
            flag = 1-flag;
        }
    }
};
