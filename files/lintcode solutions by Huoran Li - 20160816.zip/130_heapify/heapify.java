/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/heapify
@Language: Java
@Datetime: 15-10-01 14:35
*/

public class Solution {
    /**
     * @param A: Given an integer array
     * @return: void
     */
    private int[] a;
    private int n;
    
    public void heapify(int[] A) {
        // write your code here
        a = A;
        n = a.length;
        
        for( int i = n - 1 ; i >= 0 ; i -- )
        {
            maintain( i );
        }
    }
    
    private void maintain( int idx )
    {
        int x = idx * 2 + 1;
        int y = x + 1;
        if( x >= n ) return;
        if( y == n )
        {
            if( a[idx] > a[x] )
            {
                int temp = a[idx];
                a[idx] = a[x];
                a[x] = temp;
            }
        }
        else
        {
            int v = ( a[x] < a[y] ? x : y );
            if( a[idx] > a[v] )
            {
                int temp = a[idx];
                a[idx] = a[v];
                a[v] = temp;
                maintain( v );
            }
        }
    }
}
