/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/convert-sorted-array-to-binary-search-tree-with-minimal-height
@Language: Java
@Datetime: 15-07-11 07:54
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */ 
public class Solution
{
    /**
     * @param A: an integer array
     * @return: a tree node
     */
    public TreeNode sortedArrayToBST( int[] A )
    {  
        // write your code here
        return build( A , 0 , A.length - 1 );
    }
    
    private TreeNode build( int[] a , int l , int r )
    {
        if( l > r ) return null;
        if( l == r ) return new TreeNode( a[l] );
        
        int m = ( l + r ) / 2;
        
        TreeNode ret = new TreeNode( a[m] );
        ret.left = build( a , l , m - 1 );
        ret.right = build( a , m + 1 , r );
        
        return ret;
    }
}

