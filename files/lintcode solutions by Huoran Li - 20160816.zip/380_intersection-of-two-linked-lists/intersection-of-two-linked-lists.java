/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/intersection-of-two-linked-lists
@Language: Java
@Datetime: 15-11-14 14:00
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;      
 *     }
 * }
 */
public class Solution {
    /**
     * @param headA: the first list
     * @param headB: the second list
     * @return: a ListNode 
     */
    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        // Write your code here
        if (headA == null || headB == null) {
            return null;
        }
        
        ListNode p , q;
        int la , lb;
        
        // test
        p = headA;
        q = headB;
        la = lb = 0;
        while (p.next != null) {
            p = p.next;
            la += 1;
        }
        while (q.next != null) {
            q = q.next;
            lb += 1;
        }
        
        if (p != q) {
            return null;
        }
        
        p = headA;
        q = headB;
        if (la > lb) {
            for (int i = 0; i < la - lb; i += 1) {
                p = p.next;
            }
        } else if (la < lb) {
            for (int i = 0; i < lb - la; i += 1) {
                q = q.next;
            }
        }
        
        while (p != null && q != null) {
            if (p == q) {
                return p;
            }
            p = p.next;
            q = q.next;
        }
        return null;
    }  
}
