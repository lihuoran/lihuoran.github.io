/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/simplify-path
@Language: Java
@Datetime: 15-06-09 05:47
*/

public class Solution
{
    /**
     * @param path the original path
     * @return the simplified path
     */
    public String simplifyPath( String path )
    {
        // Write your code here
        Stack<String> s = new Stack<String>();
        if( path.charAt( path.length() - 1 ) != '/' ) path += "/";
        while( path.length() > 1 )
        {
            int t = path.substring( 1 ).indexOf( '/' ) + 1;
        //    System.out.println( path + "\t" + t );
                       
            if( t == 1 ) path = path.substring( t );
            else
            {
	            String f = path.substring( 1 , t );
	            path = path.substring( t );
	            if( f.equals( ".." ) )
	            {
	                if( !s.isEmpty() ) s.pop();
	            }
	            else if( f.equals( "." ) )
	            {
	                continue;
	            }
	            else s.push( f );
            }
        }
        
        if( s.isEmpty() ) return "/";
        else
        {
            String ret = "";
            Stack<String> t = new Stack<String>();
            while( !s.isEmpty() ) t.push( s.pop() );
            while( !t.isEmpty() ) ret += "/" + t.pop();
            return ret;
        }
    }
}