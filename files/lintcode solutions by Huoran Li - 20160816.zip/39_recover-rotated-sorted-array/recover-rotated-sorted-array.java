/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/recover-rotated-sorted-array
@Language: Java
@Datetime: 15-05-07 12:06
*/

public class Solution
{
    /**
     * @param nums: The rotated sorted array
     * @return: The recovered sorted array
     */
    public void recoverRotatedSortedArray( ArrayList<Integer> nums )
    {
        // write your code
        int n = nums.size();
        int idx = 0;
        for( int i = 0 ; i < n - 1 ; i ++ )
            if( nums.get( i ) > nums.get( i + 1 ) )
            {
                idx = i + 1;
                break;
            }
        
        if( idx > 0 )
        {
        	int g = gcd( n , idx );
        	for( int i = 0 ; i < g ; i ++ )
        	{
        		int box = nums.get( i );
        		int pos = i;
        		for( int j = 0 ; j < n / g - 1 ; j ++ )
        		{
        			nums.set( pos , nums.get( ( pos + idx ) % n ) );
        			pos = ( pos + idx ) % n;
        		}
        		nums.set( pos , box );
        	}
        }
    }
    
    private int gcd( int a , int b )
    {
    	if( a < b ) return gcd( a , b );
    	if( b == 0 ) return a;
    	return gcd( b , a % b );
    }
}



