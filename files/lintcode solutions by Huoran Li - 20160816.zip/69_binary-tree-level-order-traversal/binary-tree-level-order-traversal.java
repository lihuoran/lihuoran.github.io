/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/binary-tree-level-order-traversal
@Language: Java
@Datetime: 15-08-08 07:27
*/

public class Solution
{
    /**
     * @param root: The root of binary tree.
     * @return: Level order a list of lists of integer
     */
    public ArrayList<ArrayList<Integer>> levelOrder( TreeNode root )
    {
        // write your code here
    	ArrayList<ArrayList<Integer>> ret = new ArrayList<ArrayList<Integer>>();
    	if( root == null ) return ret;
    	
    	ArrayList<Integer> curlist = null;
    	int cnt = 0;
    	LinkedList<Element> q = new LinkedList<Element>();
    	q.add( new Element( root , 1 ) );
    	
    	while( !q.isEmpty() )
    	{
    		Element e = q.poll();
    		if( e.level != cnt )
    		{
    			if( curlist != null ) ret.add( curlist );
    			curlist = new ArrayList<Integer>();
    			cnt ++;
    		}
    		
    		curlist.add( e.node.val );
    		if( e.node.left != null ) q.add( new Element( e.node.left , e.level + 1 ) );
    		if( e.node.right != null ) q.add( new Element( e.node.right , e.level + 1 ) );
    	}
    	
    	if( curlist != null ) ret.add( curlist );
    	return ret;
    }
}

class Element
{
	public TreeNode node;
	public int level;
	
	public Element( TreeNode n , int l )
	{
		this.node = n;
		this.level = l;
	}
}