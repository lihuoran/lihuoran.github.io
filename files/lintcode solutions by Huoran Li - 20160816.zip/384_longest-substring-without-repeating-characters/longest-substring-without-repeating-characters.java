/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/longest-substring-without-repeating-characters
@Language: Java
@Datetime: 15-05-11 15:20
*/

public class Solution
{
    /**
     * @param s: a string
     * @return: an integer 
     */
    public int lengthOfLongestSubstring( String s )
    {
        // write your code here
        if( s.length() == 0 ) return 0;
        
        int n = s.length();
        int ans = 1;
        int[] pos = new int[256];
        for( int i = 0 ; i < 256 ; i ++ )
            pos[i] = -1;
        
        int l = 0;
        pos[s.charAt( 0 )] = 0;
        for( int i = 1 ; i < n ; i ++ )
        {
            l = max( l , pos[s.charAt( i )] + 1 );
            ans = max( ans , ( i - l + 1 ) );
            pos[s.charAt( i )] = i;
        }
        
        return ans;
    }
    
    private int max( int a , int b )
    {
        return ( a > b ? a : b );
    }
}
