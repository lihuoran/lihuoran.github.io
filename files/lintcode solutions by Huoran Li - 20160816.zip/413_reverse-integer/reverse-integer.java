/*
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/reverse-integer
@Language: Java
@Datetime: 15-07-11 07:52
*/

public class Solution
{
    /**
     * @param n the integer to be reversed
     * @return the reversed integer
     */
    public int reverseInteger( int n )
    {
        // Write your code here
        if( n == 0 ) return 0;
        
        int[] a = new int[100];
        int k = 0;
        int s = ( n >= 0 ? 1 : -1 );
        
        n = ( n >= 0 ? n : n * -1 );
        while( n != 0 )
        {
            a[k ++] = n % 10;
            n /= 10;
        }
        
        if( k > 10 ) return 0;
        if( k == 10 )
        {
            while( true )
            {
                if( a[0] > 2 ) return 0;
                if( a[0] < 2 ) break;
                if( a[1] > 1 ) return 0;
                if( a[1] < 1 ) break;
                if( a[2] > 4 ) return 0;
                if( a[2] < 4 ) break;
                if( a[3] > 7 ) return 0;
                if( a[3] < 7 ) break;
                if( a[4] > 4 ) return 0;
                if( a[4] < 4 ) break;
                if( a[5] > 8 ) return 0;
                if( a[5] < 8 ) break;
                if( a[6] > 3 ) return 0;
                if( a[6] < 3 ) break;
                if( a[7] > 6 ) return 0;
                if( a[7] < 6 ) break;
                if( a[8] > 4 ) return 0;
                if( a[8] < 4 ) break;
                if( a[9] > 8 ) return 0;
                if( a[9] == 8 && s == 1 ) return 0;
                break;
            }
        }
        
        int ret = 0;
        for( int i = 0 ; i < k ; i ++ )
            ret = ret * 10 + a[i];
        return ret * s;
    }
}
