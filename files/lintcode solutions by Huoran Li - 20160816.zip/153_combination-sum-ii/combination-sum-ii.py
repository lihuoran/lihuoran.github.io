# coding:utf-8
'''
@Copyright:LintCode
@Author:   huo
@Problem:  http://www.lintcode.com/problem/combination-sum-ii
@Language: Python
@Datetime: 15-09-27 03:42
'''

def cmp( a , b ):
	la = len( a )
	lb = len( b )
	l = min( la , lb )
	for i in range( l ):
		if a[i] < b[i]:
			return -1
		if a[i] > b[i]:
			return 1
	if la < lb:
		return -1
	if la > lb:
		return 1
	return 0 

class Solution:	
	"""
	@param candidates: Given the candidate numbers
	@param target: Given the target number
	@return: All the combinations that sum to target
	"""
	def combinationSum2( self , candidates , target ): 
		# write your code here
		self.data = {}
		for e in candidates:
			self.data[e] = self.data.get( e , 0 ) + 1
		self.klist = self.data.keys()
		self.klist.sort()

		self.ret = []
		self.dfs( 0 , target , [] )

		ans = []
		for e in self.ret:
			temp = []
			for i in range( len( e ) ):
				for j in range( e[i] ):
					temp.append( self.klist[i] )
			temp.sort()

			ans.append( temp )

		ans.sort( cmp )	
		return ans

   	def dfs( self , idx , target , cur ):
   		if idx == len( self.klist ):
   			if target == 0:
   				self.ret.append( cur )
   		else:
   			val = self.klist[idx]

   			for i in range( self.data[val] + 1 ):
   				if i * val > target:
   					break
   				next = list( cur )
   				next.append( i )
   				self.dfs( idx + 1 , target - val * i , next )